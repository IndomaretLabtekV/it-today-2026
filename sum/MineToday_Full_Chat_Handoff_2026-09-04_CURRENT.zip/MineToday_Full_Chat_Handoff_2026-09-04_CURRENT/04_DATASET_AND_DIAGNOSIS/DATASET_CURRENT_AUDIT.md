# Dataset Current Audit

## Core dimensions
- train relevance: 4,000 users × 17 module targets
- test: 1,000 users
- chat history: 14,573 rows, 4,940 unique users observed historically
- assessments: 5,000 users, 10 assessment questions encoded in the assessment record
- module catalog: 17 modules

## Positive-count geometry
Every training user has exactly 4, 5, or 6 positive modules:
- K=4: 1,362
- K=5: 1,285
- K=6: 1,353

This is close to a balanced 3-way distribution. The lower cutoff is inherently conditional. A prior diagnostic found K predictability near majority baseline (~0.3358 vs ~0.3405); treat that exact number as provisional unless rerun.

## Graded relevance structure
Approximate ordered grades:
- rank1 1.00
- rank2 ~0.85
- rank3 ~0.70
- rank4 ~0.55
- rank5 ~0.40
- rank6 ~0.25

Ranks 1–4 exist for every user; rank5 exists only when K≥5; rank6 only when K=6.

## Pairwise learnability
Historical adjacent-pair AUC:
- 1↔2: ~0.668
- 2↔3: ~0.614
- 3↔4: ~0.563
- 4↔5: ~0.530
- 5↔6: ~0.521

Lower boundaries become close to random to learn, even though some have high NDCG leverage.

## Assessment quality
Exactly 251 invalid normalized cells were found among 50,000 assessment cells. Historical invalid values included 99, 12, -1 and -3. Robust pipelines should clean these and preserve invalid indicators.

## Chat structure
- 535 administrative/noise rows identified.
- Chat is highly template-heavy.
- historical exact normalized test-chat overlap with train was high, but exact-template target lookup was not sufficiently reliable.
- latest intent signatures have strong train/test support; no broad unseen-intent crisis.

## Train/test shift
Broad adversarial train-vs-test diagnostics were near chance historically, so there is no strong basis for a large domain-adaptation system. Some individual assessment dimensions do drift, so high-capacity test-sensitive models remain risky.

## Newer structural audit
Ordered Top4 sequences are highly diverse; exact user-path memorization is not a good main strategy. Target SVD is not extremely low-rank: shared structure exists, but a simple low-rank factorization does not explain the full ranking problem.
