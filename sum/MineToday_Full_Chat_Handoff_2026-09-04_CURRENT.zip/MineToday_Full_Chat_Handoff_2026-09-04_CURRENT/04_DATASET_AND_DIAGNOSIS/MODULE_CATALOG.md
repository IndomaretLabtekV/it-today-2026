# Module Catalog

- M001 — Excel, beginner
- M002 — Python, beginner
- M003 — SQL, beginner
- M004 — Web Scraping, intermediate, needs Python
- M005 — Version Control, intermediate
- M006 — Statistics, intermediate
- M007 — EDA, intermediate, needs Python & Statistics
- M008 — Dashboard, intermediate, needs SQL/Excel
- M009 — Machine Learning, advanced, needs EDA & Statistics
- M010 — Computer Vision, advanced, needs ML/DL
- M011 — NLP, advanced, needs ML
- M012 — Generative AI, advanced, needs NLP
- M013 — Prompt Engineering, intermediate
- M014 — AI Automation, intermediate
- M015 — AI No Code, beginner
- M016 — MLOps, expert, needs ML/Python/Version Control
- M017 — Career/portfolio, all levels

Domain logic is useful as a feature/prior, but deterministic prerequisite rules repeatedly failed as a final deployment selector.
