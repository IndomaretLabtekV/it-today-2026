# Recent Result Table

| Experiment | Core hypothesis | Offline result | Public action | Status |
|---|---|---:|---|---|
| V39/V39.1 | trajectory/pair boundary selector | no robust gate | none | closed |
| V39.5 B23 | restore S3 2↔3 | public -0.00022 | submitted causal probe | harmful |
| V39.5 B34 | restore S3 3↔4 | public +0.00006 | submitted causal probe | keep |
| V39.5 B45 | restore S3 4↔5 after B34 | public ~+0.00002 | submitted causal probe | keep |
| V40 | prerequisite membership recovery | no robust gate | none | closed |
| V41 | dense semantic stack | CAL +0.000824, LOCK -0.000136 | none | invalidated by transfer/stacking issue |
| V41.1 | clean ordinal Qwen | ~-0.000029 CAL | none | closed |
| V41.2 | head preference specialist | insufficient | none | closed |
| V42 | generator-state residual | +0.000121 DESIGN, but stress/gate fail | none | informative only |
| V42.1 | generator-exclusive support shrink | +0.000069, 3/5 folds | none | closed |
| V43 TabM | joint user-level residual | -0.003718 | none | closed |
| V43.1 | nested trust path | -0.000047, 1/5 folds | none | closed |
| V44 | V30-S2 causal pruning | no class passes; 0 actions | none | closed |
