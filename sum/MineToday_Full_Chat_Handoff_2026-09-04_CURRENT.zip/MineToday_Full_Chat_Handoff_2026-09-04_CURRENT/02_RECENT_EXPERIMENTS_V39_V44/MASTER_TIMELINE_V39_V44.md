# Master Timeline — V39 through V44

This file extends the archived V1–V38.1 timeline.

## V39 — Direct Intent-Trajectory LTR
Attempted a new residual selector/ranker from intent trajectory structure. It did not produce a robust new public candidate. The branch reinforced the selector bottleneck: feature structure can be meaningful without yielding reliable rare interventions.

## V39.1 — Pairwise Boundary / Trajectory specialist
Focused on boundary-level decisions and trajectory. Validation/gating did not justify deployment. No public improvement.

## V39.5 — S3 Boundary Causal Decomposition
This was one of the most valuable late-stage experiments because it used natural public causal decomposition instead of a new model.

Starting from current 0.66020 and the 27 S3 order-only actions:
- B23: 9 rows → **0.65998**, approximately **-0.00022**.
- B34: 10 rows → **0.66026**, approximately **+0.00006**.
- B45: 8 rows, when added after B34 → **0.66028**, approximately **+0.00002**.

Result: exact current champion **0.66028** with B23 rejected and B34+B45 restored.

## V40 — B34-locked prerequisite membership
Tested whether prerequisite/readiness structure could recover membership changes around the strong anchor. No robust promotion gate. Candidate failed close to anchor. Conclusion: deterministic prerequisite logic is not a reliable final-stage selector.

## V41 — B34-anchored heterogeneous dense semantic stack
Structural + Qwen semantic stack appeared strong on CAL:
- CAL delta about **+0.000824**, 4/4 positive CAL folds.
- untouched LOCK delta about **-0.000136**.
- CAL→LOCK optimism gap about **0.000960**.

A second-level dependency/leakage concern was identified: first-level stack OOF features were not nested correctly relative to the second-level ranker fold. Scientific value: semantic complementarity exists, but the validation setup overstated deployable gain.

## V41.1 — Hierarchical ordinal Qwen residual stack
Fixed the stacking dependency with a single-level cross-fitted ordinal setup. Result approximately flat/slightly negative:
- CAL delta about **-0.000029**.
- 2/5 random folds positive.
- 2/5 contiguous-ID blocks positive.
- LOCK not opened.

Conclusion: Qwen can carry independent information, but full-list semantic calibration does not translate reliably into NDCG residual actions.

## V41.2 — Head4 preference / Top1 specialist
Restricted the action space toward high-leverage head ordering. The branch did not deliver enough stable action quality to justify a submission. This helped motivate looking for structural rather than learned-selector gains.

## V42 — 0.66028-anchored Generator-State Residual YetiRank
Hypothesis: exact conversation-generator/template state contains supervised residual signal beyond broad intent/topic features.

DESIGN results:
- anchor ~0.6596122
- control ~0.6596398
- GENCAT ~0.6597333
- GENCAT-anchor delta **+0.0001211**
- GENCAT-CONTROL representation increment **+0.0000935**
- absolute GENCAT positive 4/5 folds; generator-specific increment positive 5/5.
- 4/5 contiguous blocks positive.
- changed users only 27; Top1 changes 2.

But template-disjoint stress showed the generator-specific increment did not generalize cleanly to unseen exact templates, and implementation had three conceptual mismatches:
1. training anchor geometry was Consensus3 while validation used modern policy anchor;
2. ranker trained on all 17 items but deployment only allowed Top4 changes;
3. deployment used absolute GENCAT-anchor instead of paired GENCAT-CONTROL residual.

Gate failed. This motivated V42.1.

## V42.1 — Champion-Anchored Support-Shrunk Generator-Exclusive Head Ranker
Fixed the three V42 mismatches, added fold-safe empirical-Bayes shrinkage and Top4-only training/deployment.

Result:
- DESIGN anchor 0.65967780
- candidate 0.65974678
- delta **+0.00006898**
- Top1 delta **-0.000294**
- folds positive **3/5**
- blocks positive **4/5**
- 21 changed users, 1 Top1 change
- low-support/cold-template groups intentionally near zero
- gate failed; LOCK not opened
- production primary/candidate fail-closed to exact 0.66028, 0 test changes

Interpretation: generator state is real but too weak after clean isolation. Support shrinkage reduced action supply instead of revealing leaderboard-scale gain. Generator branch closed.

## V43 — Joint User-Level Anchor-Residual TabM + Partial Plackett-Luce
This was a major change of factorization: one user = one sample, whole 17-module state visible jointly, shared user encoder, zero-initialized residual utility decoder, weighted partial PL loss over guaranteed Top4. MLP was a control.

DESIGN:
- anchor 0.66238331
- MLP candidate 0.65096310 → **-0.01142021**, 0/5 folds, 0/5 blocks, 2,009 changed users, 789 Top1 changes
- TabM candidate 0.65866500 → **-0.00371831**, 0/5 folds, 0/5 blocks, 1,475 changed users, 420 Top1 changes
- high-ID TabM delta about **-0.00450**

TabM was much better than MLP, so the backbone did learn something, but direct residual authority was catastrophically too broad. Branch was not submitted.

## V43.1 — Nested Residual Trust-Path TabM
Purpose: distinguish wrong residual direction from excessive authority without tuning hidden size/dropout/L2. Kept architecture fixed, audited checkpoints and log-scale betas under nested inner calibration.

Chosen DESIGN-wide safe path effectively landed around epoch 8, beta 1/32.

DESIGN:
- anchor 0.66238331
- candidate 0.66233585
- delta **-0.00004747**
- folds positive **1/5**
- blocks positive **1/5**
- high-ID delta **-0.0001446**
- 17 changed users, 3 Top1 changes
- Top1 delta **-0.000294**

Outer fold deltas:
- -0.00002885
- +0.00004694
- -0.00006231
- -0.00015810
- -0.00003503

Key diagnostic: inner calibration found positive islands, but they did not transfer to untouched outer folds. The strongest residual-action tail was not the most correct. Conclusion: V43 failure was partly overshoot, but residual direction itself was not reliable. TabM branch closed; no V43.2.

Implementation issue encountered and fixed before this successful run:
- `NameError: V43_MODEL_SEED` in SVD cell; corrected to the V43.1 config seed variable.

## V44 — Frozen-Lineage Causal Pruning of V30-S2
No new predictor. Decomposed V30-only S2 interventions into natural ranking geometry classes and asked whether reverting any whole class to V25 improves OOF NDCG.

Test state S2 has 43 users. Natural classes: TOP1, MEMBERSHIP, B23, B34, B45, COMPLEX_ORDER.

DESIGN class-level prune results:
- TOP1: 33 OOF actions, prune delta **+0.0000611**, 2/5 folds, 3/5 blocks, CI crosses zero, Top1 delta -0.000882 → fail.
- MEMBERSHIP: 101 actions, **-0.0000436**, 2/5 folds, 3/5 blocks → keep.
- B23: 50 actions, **+0.0000307**, 3/5 folds, 2/5 blocks → too small/unstable.
- B34: 52 actions, **-0.0000334** → pruning tends to hurt.
- B45: 88 actions, **-0.0000051** → no pruning case.
- COMPLEX_ORDER: 4 actions, **+0.0000154** → too small.

No class passed the preregistered gate. `selected_classes=[]`, DESIGN candidate equals anchor, LOCK not opened, production test changes = 0. Conclusion: V30 S2 is more internally efficient than expected at coarse natural-class resolution.

Implementation issue encountered and fixed before successful run:
- `NameError: ALL_INTENT` inside `build_v44_val_split`; compatibility alias/state was restored from the lineage helpers.
