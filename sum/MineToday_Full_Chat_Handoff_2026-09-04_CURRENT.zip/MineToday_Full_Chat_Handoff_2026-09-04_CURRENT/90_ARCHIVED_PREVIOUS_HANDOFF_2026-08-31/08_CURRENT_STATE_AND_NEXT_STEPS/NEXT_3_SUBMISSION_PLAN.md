# Next 3 Submission Plan — Current Recommendation

Daily slots available: **3**.

## Slot 1 — boundary 2↔3 probe
Current 0.66020 + 9 S3 order-only 2↔3 actions.

Goal: measure whether the highest internal-order boundary contains positive signal.

## Slot 2 — boundary 3↔4 probe
Current 0.66020 + 10 S3 order-only 3↔4 actions.

Goal: isolate the second family.

## Infer boundary 4↔5
8 actions remain. Use total package effect:
`C45 ≈ -0.00014 - C23 - C34`.

If inference is near zero relative to leaderboard rounding, treat it as uncertain.

## Slot 3 — adaptive best rule-level combination
Add back only clearly positive group(s). Examples:
- if C23 positive, C34/C45 negative → current + 2↔3;
- if C23 and C34 positive → current + both;
- if inferred C45 strongly positive → include 4↔5 too;
- if none positive → preserve current and use slot 3 for a natural membership subgroup probe instead of duplicating anchor.

## Why this is preferred over training another model now
- V32–V38.1 repeatedly failed to transfer leader-scale residual selectors.
- Public decomposition has already produced a new best with very high information efficiency.
- Boundary groups are natural, reproducible, and large enough (8–10 users) to avoid one-user leaderboard mining.
