# After Boundary Decomposition

## Scenario A — one or more order boundary families positive
Keep positive family/families and subdivide only the winner using generic features:
- module-pair direction;
- foundation/advanced category;
- intent alignment;
- readiness mismatch;
- V30 margin bucket;
- V31 intent-state support.

Use public slots sparingly. A subgroup should have enough support to be a plausible rule, not an individual row.

## Scenario B — all order families negative
S3 internal order is exhausted. Current 0.66020 stays anchor.

Next best public decomposition target: 4 membership actions, but split by natural module/direction/intent class rather than user ID.

## Scenario C — boundary cleanup reaches ~0.6608+
Now gap to leader becomes much smaller. At that point a small validated S0 residual branch might be worth revisiting, but only if expected incremental gain is comparable to remaining gap.

## Scenario D — still stuck around 0.6602
Do not immediately scale model size. Candidate next research directions, in order:
1. cross-model consensus only on **high-leverage** Top1/membership regimes, combining current anchor geometry with curriculum semantic signals;
2. module-transition-conditioned state rules;
3. new truly orthogonal structured signal if discoverable.

XLM-R Large is lower priority unless new evidence changes the capacity diagnosis.
