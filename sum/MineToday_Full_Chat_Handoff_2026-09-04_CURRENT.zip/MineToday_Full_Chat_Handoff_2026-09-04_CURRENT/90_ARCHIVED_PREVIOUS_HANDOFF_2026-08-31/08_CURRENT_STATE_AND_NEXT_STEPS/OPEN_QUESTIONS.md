# Open Questions

1. Which of 2↔3, 3↔4, 4↔5 S3 order-only families is positive, if any?
2. Are the four S3 membership actions internally cancelling, and can a generic property separate them?
3. Can current 0.66020 be reproduced exactly end-to-end under a clean final notebook/environment?
4. What is the public/private leaderboard split behavior? TM text reviewed did not specify a split; avoid assumptions.
5. If S3 is fully exhausted, is there any S0 high-leverage subgroup where curriculum-XLM-R, V30/V31 disagreement, and structured geometry agree with enough precision?
6. Is a leader-scale +0.00122 still feasible without overfitting public LB? Need realistic evidence, not promise.
7. Which fresh validation salts remain genuinely unburned for any future new architecture?
