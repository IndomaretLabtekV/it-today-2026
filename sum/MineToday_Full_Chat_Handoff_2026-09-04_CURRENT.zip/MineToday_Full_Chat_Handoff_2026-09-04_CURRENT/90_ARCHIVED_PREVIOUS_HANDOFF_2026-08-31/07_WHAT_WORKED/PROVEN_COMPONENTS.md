# Proven Components

## Model/data components with real public evidence
- Word+char TF-IDF lexical representation.
- Recent/current/older trajectory tags.
- Assessment cleaning + invalid flags.
- Per-module binary relevance calibration.
- Small module-specific blend weights.
- Strong immutable anchor mindset.
- V30 residual LambdaRank Base, alpha 0.16.
- Strict nested/fold-pure validation.
- Public-proven surgical correction packages.
- Deterministic model-disagreement state machine.
- Fail-close behavior.
- Natural geometry-level public ablations.

## Process components that worked
- Fresh multi-world validation rather than one lucky split.
- Sealed rejection-only split.
- Exact action ledgers and ranking-geometry assertions.
- Decomposing a worse whole model into useful disagreement subregions.
- Keeping one action per user for residual corrections.
- Protecting public-proven rows/geometry until evidence says otherwise.
