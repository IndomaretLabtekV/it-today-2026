# Public-Proven Rules

These are stronger than purely offline hypotheses.

1. V30 > V25 by +0.00044 displayed public.
2. V31 whole < V30, but V31 overlap-S3 changes are highly useful.
3. V31-new-only/S1 is strongly toxic.
4. Adding two extra weak corrections to Hybrid34 loses ~0.00030.
5. Within S3, the 3 Top1-changing actions are **collectively very valuable**.
6. Within S3, 4 membership-changing actions are approximately net-neutral displayed.
7. Within S3, 27 internal order-only actions are collectively negative.
8. Therefore current best 0.66020 keeps only Top1 + membership S3 actions.

Do not generalize Rule 5 into “all Top1 corrections are good.” It is specific to the S3 geometry selected by V30/V31 disagreement.
