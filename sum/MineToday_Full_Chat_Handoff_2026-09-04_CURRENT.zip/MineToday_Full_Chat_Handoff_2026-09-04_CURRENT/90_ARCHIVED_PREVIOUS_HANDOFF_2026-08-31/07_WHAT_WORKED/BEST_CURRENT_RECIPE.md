# Best Current Recipe — Conceptual

1. Build the sparse/calibrated historical anchor.
2. Reconstruct V25 protections/surgical package.
3. Train exact V30 Base residual LambdaRank with fixed alpha 0.16.
4. Train exact V31 Intent-State sibling using same residual geometry.
5. Compare V25/V30/V31 Top-5 geometry and assign S0–S3.
6. Start with V30 scores.
7. For S3 only, inspect the V31-vs-V30 change category:
   - if Top1 changes: keep V31 change;
   - if Top5 membership changes: keep V31 change for current champion;
   - if only internal ordering changes: reject and keep V30.
8. Preserve score multiset by score-level swap/ranking output conventions used in lineage.
9. Output 17 scores.

Current public: **0.66020**.

This recipe must eventually be consolidated into one clean Kaggle notebook with deterministic hashes.
