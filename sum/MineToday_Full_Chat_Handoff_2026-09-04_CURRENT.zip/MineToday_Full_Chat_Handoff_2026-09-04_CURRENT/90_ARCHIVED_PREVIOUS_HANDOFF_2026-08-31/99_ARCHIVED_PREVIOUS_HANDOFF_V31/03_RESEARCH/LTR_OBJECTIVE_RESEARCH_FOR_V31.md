# LTR Objective Research for V31

V30 already uses LightGBM LambdaRank, so “try listwise objective” is not a new idea by itself.

Potential objective diversity:

1. **LightGBM rank_xendcg / XE-NDCG-MART**
   - same basic tree family but different ranking objective/gradient behavior;
   - useful only if positive standalone and error/delta pattern differs from LambdaRank.

2. **CatBoost YetiRank / YetiRankPairwise residual retest**
   - older V5/V6 ranking attempts failed as primary model;
   - justified once as residual expert because architecture context changed, analogous to LambdaRank becoming useful only after anchor-conditioning.

3. **Tiny neural set/list ranker**
   - optional third diversity source.

Do not run many objective/hyperparameter combinations. Research goal = identify complementary residual expert, not tune leaderboard proxy endlessly.
