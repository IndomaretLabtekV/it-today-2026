# Deep Learning Evaluation for V31

Suggested generic Two-Tower/DeepFM/TabNet was audited.

## Why not primary
- only 17 items; no retrieval problem requiring Two-Tower;
- only 4,000 independent labeled users;
- previous high-capacity semantic models repeatedly failed public;
- “neural = lower correlation” is not enough evidence.

## Neural idea that remains worth one controlled test
**Tiny joint-list / set-wise residual ranker**:
- 17 module tokens for one user;
- per-module V30 feature vector;
- shared MLP + tiny self-attention/set interaction;
- joint 17 output scores;
- trained as residual / listwise expert, never replacing V30 anchor;
- only kept if fresh G/H/I standalone residual positive and delta correlation sufficiently different from V30.

This architecture is genuinely orthogonal because V30 LightGBM scores user-module rows independently except for engineered anchor rank geometry; set model can learn cross-module configuration jointly.
