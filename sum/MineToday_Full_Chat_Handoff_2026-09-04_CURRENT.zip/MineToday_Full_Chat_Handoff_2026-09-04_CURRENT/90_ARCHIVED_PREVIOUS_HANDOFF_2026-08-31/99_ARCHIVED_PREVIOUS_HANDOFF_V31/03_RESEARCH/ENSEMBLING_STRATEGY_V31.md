# Ensembling Strategy for V31

Do not build high-degree meta-stacker. Use low-dimensional residual ensemble around immutable V30.

For every new expert, save honest OOF residual predictions and measure:

1. standalone NDCG delta vs V30;
2. worst-salt delta;
3. per-user delta correlation with V30/Lambda residual;
4. harm overlap: does expert fix users V30 harms?
5. transition-family overlap/complementarity;
6. test geometry coverage.

Only blend experts that are individually defensible and meaningfully complementary. Feature/seed diversity alone is not enough if predictions correlate ~1.
