# Feature Engineering Direction for V31

## High priority: hierarchical intent → module target encoding
V30 DirectCurr only encoded explicit intent to direct-prerequisite relations. Generalize empirically:

- P(module positive | latest intent topic)
- mean graded relevance(module | latest intent)
- smoothed lift vs module prevalence
- support/confidence

Must be nested/fold-safe. No validation label may contribute to its own encoding.

## Optional: intent trajectory encoding
Capture previousTopic → latestTopic and estimate module relevance conditional on trajectory, with heavy smoothing/min support. Current V30 has topic counts/recency/latest but not explicit transition conditional statistics.

## Low priority / already saturated
- more generic time decay: already current/recent/older + recency numeric;
- more direct curriculum distance: multi-hop failed;
- generic template target encoding: memorization risk;
- broad semantic similarity: already explored deeply.
