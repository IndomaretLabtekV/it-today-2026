# Methods Tried and Current Verdict

## Sparse lexical / structured
Word+char TF-IDF, current/recent/older tags, template features, assessment cleaning/readiness, sparse Ridge. **Keep: core backbone.**

## Binary module relevance calibration
Per-module LightGBM binary relevance / blending. **Keep: public-proven anchor component.**

## Semantic embeddings
Qwen 0.6B, multilingual encoders, Qwen3-Embedding-8B, BGE, F2LLM-v2-4B. **Global replacement not worth.** Possible future use only as orthogonal teacher/expert with strong gate, not default.

## QLoRA / supervised semantic residual
Technically feasible, poor public transfer. **Do not repeat broad.**

## Pairwise / routers
Upper pair learnability exists but lower boundaries near random; routers overfit. **Do not use generic user-level router.**

## LambdaRank
Tried earlier unsuccessfully as broad/global model. Became successful when conditioned on strong anchor and used as small residual expert in V29/V30. **Current main public-proven residual family.**

## Curriculum
Hard prerequisite rules negative. Transitive distance2/3 weak. Direct explicit-intent prerequisite pair conditional signal exists but V30 incremental modest. **Research feature only, not core.**

## Cooccurrence
Strict contribution in V29; V30 fresh C/D/E incremental negative all 3. **Not V31 core unless new evidence.**

## Residual covariance graph
Tiny marginal gain and added instability. **Drop.**

## Generic uncertainty / bagging stability
Failed monotonicity. **Drop as gate.**

## Neural architectures
No evidence yet that generic Two-Tower/DeepFM/TabNet are appropriate. A tiny set-wise/listwise residual network remains potentially interesting because it jointly sees all 17 modules and could provide diversity relative to trees.
