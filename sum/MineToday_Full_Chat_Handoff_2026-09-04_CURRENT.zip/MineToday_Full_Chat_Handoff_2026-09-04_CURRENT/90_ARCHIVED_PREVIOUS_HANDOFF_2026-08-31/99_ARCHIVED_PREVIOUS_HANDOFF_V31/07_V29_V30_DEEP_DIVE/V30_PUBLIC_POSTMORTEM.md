# V30 Public Postmortem

## Result
V30 primary public = **0.65963**, naik dari 0.65919 sebesar **+0.00044**. Rank user kembali sekitar #5. Leader saat ini 0.66141, gap 0.00178.

## Interpretation
Ini public evidence pertama yang cukup jelas bahwa **anchor-conditioned residual LambdaRank Base** benar-benar generalize. Offline pooled mean +0.000732 terealisasi sekitar +0.00044 public; jangan berharap 1:1 transfer.

Public result juga membantah narasi bahwa V30 gain berasal dari DirectCurr. Development winner by precommitment adalah Base; submission berasal dari Base.

## Why V30 matters
- Survived three fresh development salts.
- Survived sealed F/chronology rejection gate.
- Public actually improved.
- Changes were moderate (77 order changes), not broad replacement.
- Protected prior public-tested V25 rows.

## Remaining problem
+0.00044 masih jauh dari gap +0.00178. Pure cleanup/tuning alpha likely insufficient. V31 needs new orthogonal residual information that affects users V30 currently leaves untouched.

## Transition clue
V30 audit shows some exact swap families repeatedly beneficial across C/D/E and some repeatedly harmful. This suggests transition-family stability can be a safety diagnostic. But C/D/E are now historical; do not hardcode families into test until replicated on fresh G/H/I.
