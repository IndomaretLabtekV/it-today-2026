# V29 Deep Analysis

Selected `ltr_gap_cooc_resid`, alpha .16:
- strict template-group +0.001116;
- 5/5 fold positive;
- fresh LOCK +0.000806;
- chronology +0.000122;
- pseudo-public 35% mean +0.000816, positive 75%, but p10 -0.000795.

Predeploy gate failed solely at lower-tail pseudo-public criterion, so primary was exact V25 anchor and diagnostic not submitted.

Ablations:
- Base .10 +0.000650, 5/5, positive CI: proves anchor-conditioned long-format LambdaRank signal existed without new curriculum graph.
- Gap often worse than Base; skill-gap not strongest.
- Gap+Cooc .16 +0.001075, showing cooc contributed on that strict world.
- Residual graph added only +0.000041.

Oracle worst100:
- missed relevance mass 267.19;
- direct cooc oracle captured only ~0.4%; prerequisite coverage ~35.8%; union ~36%.
This was coverage/headroom, not precision proof.
