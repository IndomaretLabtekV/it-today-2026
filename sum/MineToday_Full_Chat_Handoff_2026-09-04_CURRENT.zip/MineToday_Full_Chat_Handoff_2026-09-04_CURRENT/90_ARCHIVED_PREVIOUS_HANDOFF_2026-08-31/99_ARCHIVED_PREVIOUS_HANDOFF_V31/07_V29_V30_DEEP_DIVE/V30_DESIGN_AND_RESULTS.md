# V30 Design and Results

## Research design
Name conceptually: 3-Fresh-Salt Split-Robust Pair-Conditional Curriculum Residual LTR.

Historical V29/V29.5 splits A/B were demoted to research history because they had already influenced architecture decisions. Fresh salts C/D/E were generated for development. Each salt = 5-fold nested template-group OOF, total 15 outer folds.

Precommitted:
- alpha = 0.16;
- A `ltr_base`;
- B `ltr_direct` = Base + fold-safe explicit latest-intent direct-prerequisite empirical priors;
- C `ltr_direct_cooc` = B + fold-safe cooccurrence;
- winner selected by worst-salt robustness;
- F sealed lock + chronology rejection-only;
- residual covariance, generic uncertainty, distance2/3 curriculum removed.

## Results
Base:
C +.000890, D +.000449, E +.000855, 13/15 folds, pooled +.000732 CI [.000337,.001145], worst salt +.000449.

Direct:
C +.001127, D +.000374, E +.000944, 14/15, pooled +.000815, but worst +.000374. Increment vs Base positive C/E, negative D; pooled only +.000084.

Direct+Cooc:
pooled +.000579; cooc incremental C/D/E all negative; failed incremental gate.

Max-min winner = Base.

Sealed:
- F +.000969, CI crosses zero;
- chronology +.000042, CI crosses zero.
Both non-negative mean → final gate pass.

Test geometry:
- 77/1000 users Top5 order changed;
- 8 Top1 changes;
- 7 Top5 membership changes;
- all 8 public-tested V25 rows protected exact.
