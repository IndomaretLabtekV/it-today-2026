# V29.5 Kill-Test Analysis

## Purpose
Test whether V29 should become Variance-Controlled Curriculum Residual LTR.

## Findings

### Uncertainty failed
Honest outer-fold replica ranking stability did not correlate with realized benefit/harm:
- Base Spearman ~0.0027
- Gap+Cooc ~0.015
Quintiles also non-monotonic; ties near stability=1 made qcut bins even less meaningful. Generic alpha_user = alpha_max × stability rejected.

### Curriculum narrowed to direct pair signal
Explicit latest intent → upstream direct prerequisite distance1:
- support ~9,193 user-module pairs
- positive rate ~39.5%
- baseline ~29.4%
- lift ~1.344
Distance2/3 not consistently > baseline. Anchor Top1 seed direct prerequisite lift ~0.93, so anchor-based curriculum seed is not strong.

Direct edge heterogeneity examples:
- WebScraping→Python ~89% positive
- Dashboard→SQL ~75%
- CV→ML ~51%
- GenAI→NLP ~16%
- MLOps→VersionControl ~19%
Catalog prerequisite status cannot be treated equally.

### Cooc interpretation
Fresh-world relative gains mixed. It can make bad model “less bad” but did not guarantee absolute positive transfer.

### Split/regime instability
V29.5 fresh salted LOCK had negative deltas for all candidates while chronology stayed positive. This invalidated confidence from one earlier LOCK and led to V30 fresh multi-salt protocol.

### Operational incident
Initial notebook error: `build_anchor_split_full` undefined. Fixed version added helper and passed run.
