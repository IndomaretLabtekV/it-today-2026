# Module Catalog

| ID | Modul | Level / known prerequisite |
|---|---|---|
| M001 | Excel | beginner |
| M002 | Python | beginner |
| M003 | SQL | beginner |
| M004 | Web Scraping | medium; Python |
| M005 | Version Control | medium |
| M006 | Statistics | medium |
| M007 | EDA | medium; Python + Statistics |
| M008 | Dashboard | medium; SQL + Excel |
| M009 | Machine Learning | advanced; EDA + Statistics |
| M010 | Computer Vision | advanced; ML/DL |
| M011 | NLP | advanced; ML |
| M012 | Generative AI | advanced; NLP |
| M013 | Prompt Engineering | medium |
| M014 | AI Automation | medium |
| M015 | AI No Code | beginner |
| M016 | MLOps | expert; ML + Python + Version Control |
| M017 | Career & Portfolio | all levels |

Important: organizer relevance **tidak deterministic mengikuti prerequisite graph**. V29.5 menemukan direct prerequisite pair rates sangat heterogeneous.
