# Rules and Compliance

Aturan relevan yang sudah diaudit dari TM:

- maksimal 3 Kaggle submissions per hari;
- hanya dataset organizer, external data tidak boleh;
- multiple machine-learning models boleh;
- Python/R/dll boleh;
- open-source pretrained model boleh;
- paid pretrained model tidak boleh;
- LLM/Generative AI tidak boleh diminta secara langsung untuk menebak nilai test/submission;
- AI coding assistant boleh;
- notebook + seed wajib untuk reproduksi;
- top-5 finalist harus bisa mereproduksi output sesuai toleransi sekitar 0.001;
- jangan gunakan leaderboard response sebagai label/feature training.

Semua research V29–V30 tetap menggunakan organizer data dan pretrained/modeling secara ML, bukan meminta LLM menebak test answer.
