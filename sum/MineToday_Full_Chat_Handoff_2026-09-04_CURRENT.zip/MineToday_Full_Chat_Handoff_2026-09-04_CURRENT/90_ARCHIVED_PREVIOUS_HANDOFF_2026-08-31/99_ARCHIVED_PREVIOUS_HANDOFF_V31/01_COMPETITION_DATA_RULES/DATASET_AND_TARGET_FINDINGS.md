# Dataset and Target Findings

## Files / shapes
- `train_relevance.csv`: 4,000 × 18 (`user_id` + 17 module scores).
- `test.csv`: 1,000 × 1, U_4001–U_5000.
- `sample_submission.csv`: 1,000 × 18.
- `user_assessments.csv`: 5,000 × 2, JSON berisi 10 skill scores.
- `chat_history.csv`: 14,573 rows, 4,940 users.
- `modules_catalog.csv`: 17 rows.
- 90 extra unlabeled organizer users U_5001–U_5090 muncul di chat.
- 117 train users tanpa chat; 33 test users tanpa chat.

## Assessment
10 skills: Python, SQL, Statistics, EDA, ML, ML evaluation, DL, GenAI, business-to-DS, research/troubleshooting.
Ada 251 invalid/outlier cells, termasuk string angka Indonesia dan outlier seperti -3/99. Pipeline kuat selalu cleaning + invalid flags.

## Target structure
Setiap train user punya tepat 4, 5, atau 6 positive modules.
Approx graded rank bands:
- rank 1: 1.00
- rank 2: 0.80–0.90
- rank 3: 0.65–0.75
- rank 4: 0.50–0.60
- rank 5: 0.35–0.45
- rank 6: 0.20–0.30

Karena metric NDCG@5, order di Top5 jauh lebih penting daripada score calibration absolut.

## Chat structure
Dataset sangat template-heavy: raw duplicates tinggi dan normalized duplicates lebih tinggi. Namun exact-template target lookup tidak cukup reliable. Banyak template sama memiliki target variations.

## Explicit vs latent relevance
Explicit latest/current intent adalah strong feature, tetapi bukan keseluruhan target. Audit Consensus3 menunjukkan ~95.6% missed positive relevance mass berasal dari modules yang tidak explicit disebut. Maka latent association/curriculum/order adalah real headroom, tetapi graph rule deterministic juga gagal.

## Train/test shift
Adversarial train/test classifier sekitar chance (~0.49–0.53; V20 ~0.5099). Tidak ada broad distribution shift yang cukup kuat untuk membenarkan domain adaptation besar.
