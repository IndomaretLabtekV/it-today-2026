# Competition Overview

MineToday — Data Mining Competition IT Today 2026 bertema Intelligent Learning Path / personalisasi edukasi berbasis multi-modal AI. Peserta membangun AI Course Advisor yang memprediksi modul paling relevan bagi setiap siswa berdasarkan karakteristik, assessment, dan riwayat chat.

Output praktis adalah ranking 17 modul dan rekomendasi Top-5. Evaluation menggunakan NDCG@5 sehingga membership dan posisi ranking sama-sama penting.
