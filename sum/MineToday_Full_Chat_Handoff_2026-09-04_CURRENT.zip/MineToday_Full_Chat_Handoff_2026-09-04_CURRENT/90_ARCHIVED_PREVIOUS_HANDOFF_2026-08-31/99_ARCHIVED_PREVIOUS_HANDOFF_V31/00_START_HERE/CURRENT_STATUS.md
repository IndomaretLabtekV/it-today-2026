# Current Status — 28 Aug 2026

## Leaderboard sekarang

| Anchor / kandidat | Public NDCG@5 | Status |
|---|---:|---|
| V12.2 Consensus3 | 0.65856 | historical model anchor |
| V22.3 pair winner | 0.65912 | public-proven surgical correction |
| V25 core6 | 0.65919 | prior public best |
| V26 prune U4491 | 0.65919 | displayed flat |
| **V30 residual LambdaRank Base** | **0.65963** | **current public best** |
| Current leader | **0.66141** | target |

Current gap: `0.66141 - 0.65963 = 0.00178`.

## Apa yang baru terbukti oleh V30

V30 naik **+0.00044** public dari V25/V26. Ini penting karena branch yang dipakai bukan micro-swap manual, semantic embedding besar, atau curriculum-heavy model. Winner development V30 adalah `ltr_base`, yaitu residual LambdaRank di atas anchor yang sudah kuat.

Development evidence V30 winner:

- Salt C: `+0.000890`
- Salt D: `+0.000449`
- Salt E: `+0.000855`
- 3/3 salt means positif
- total fold wins: `13/15`
- pooled user delta: `+0.000732`
- template-cluster bootstrap CI: `[+0.000337, +0.001145]`
- sealed Salt F: `+0.000969`
- chronology U3001–U4000: `+0.000042`

Public realized lift `+0.00044`, sekitar 60% dari offline pooled mean, jadi offline gain tidak boleh diasumsikan transfer 1:1.

## Komponen V30 yang kalah

- DirectCurr mean C/D/E sedikit lebih tinggi (`+0.000815`) tetapi worst-salt lebih rendah (`+0.000374`) daripada Base (`+0.000449`). Karena objective preregistered adalah max-min robustness, Base menang.
- DirectCurr incremental vs Base cuma `+0.000084` pooled dan negatif di Salt D.
- Co-occurrence incremental vs DirectCurr negatif di seluruh C/D/E (`0/3` positive salts), mean sekitar `-0.000236`. Untuk primary V31, jangan anggap cooc core signal.

## Yang sedang dikerjakan sekarang

Belum implement V31. Research direction baru sedang dikunci berdasarkan public confirmation V30:

1. V30 jadi **immutable anchor**, bukan sekadar eksperimen sementara.
2. Cari residual expert yang **orthogonal** terhadap V30, bukan mengganti anchor.
3. Kandidat objective/model: LightGBM `rank_xendcg`, residual CatBoost YetiRank, optional tiny joint-list/set neural ranker.
4. Tambah fold-safe **hierarchical intent→module target encoding** dan optional trajectory `(previous intent → latest intent) → module` dengan heavy smoothing.
5. Ukur diversity menggunakan per-user delta correlation, harm overlap, dan transition-family complementarity.
6. Transition-family stability dipakai sebagai **safety veto / diagnostic**, bukan generic user router.
7. V31 validation harus memakai **fresh G/H/I**, lalu sealed J + chronology. Jangan reuse C/D/E/F sebagai selection surface lagi.

## Submission state

V30 sudah disubmit dan menghasilkan 0.65963. Dalam sequence chat ini V30 diperlakukan sebagai submission kedua. Kalau memang tidak ada submission lain setelah itu pada hari yang sama, secara logika masih mungkin ada satu daily slot, tetapi chat baru harus cek keadaan aktual sebelum submit apa pun.
