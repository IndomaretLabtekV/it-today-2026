# MineToday IT Today 2026 — Full Chat Handoff (28 Aug 2026)

Paket ini dibuat untuk memindahkan seluruh konteks kerja MineToday ke chat baru tanpa perlu mengunggah notebook/results mentah. Isinya menggabungkan handoff historis sampai V25 dengan seluruh progress lanjutan V26–V30 dan arah research V31 yang baru saja dikunci secara konseptual.

## Status paling terbaru

- Kompetisi: **MineToday — Data Mining Competition IT Today 2026**.
- Task: AI Course Advisor, ranking 17 modul dan rekomendasi Top-5 per user.
- Metric: **user-level NDCG@5**.
- Train: 4,000 users; test: 1,000 users.
- Current public best milik user: **V30 = 0.65963**.
- Public sebelumnya: V25/V26 = **0.65919**.
- Public lift V30: **+0.00044**.
- Rank setelah V30: kembali sekitar **#5**.
- Current leader terakhir disebut user: **0.66141**.
- Gap ke leader: **0.00178**.
- V30 adalah public confirmation pertama bahwa branch **anchor-conditioned residual LambdaRank** benar-benar transfer ke leaderboard.
- V31 belum dibuat. Research thesis terbaru: **Objective-Diverse Transition-Calibrated Residual Ensemble** dengan V30 sebagai immutable public-proven anchor.

## Baca urutan ini di chat baru

1. `00_START_HERE/CURRENT_STATUS.md`
2. `00_START_HERE/ONE_PAGE_CHEATSHEET.md`
3. `02_EXPERIMENT_HISTORY/MASTER_TIMELINE_V1_V30.md`
4. `04_DEEP_DIAGNOSIS/ROOT_CAUSE_SYNTHESIS_CURRENT.md`
5. `07_V29_V30_DEEP_DIVE/V30_PUBLIC_POSTMORTEM.md`
6. `08_V31_RESEARCH_PLAN/CURRENT_V31_THESIS.md`
7. `10_CHAT_HANDOFF/READY_TO_PASTE_NEXT_CHAT.txt`

## Isi yang sengaja TIDAK dimasukkan

- notebook `.ipynb`;
- results zip/csv/npy/model cache;
- submission CSV mentah;
- dataset mentah.

Nama dan fungsi artefak penting tetap dicatat di `09_REFERENCE/ARTIFACT_REFERENCE.md` agar chat baru tahu apa yang pernah ada.
