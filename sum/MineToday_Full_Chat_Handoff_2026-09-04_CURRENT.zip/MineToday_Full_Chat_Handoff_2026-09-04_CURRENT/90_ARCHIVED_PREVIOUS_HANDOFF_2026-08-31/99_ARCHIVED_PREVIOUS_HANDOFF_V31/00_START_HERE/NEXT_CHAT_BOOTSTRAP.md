# Next Chat Bootstrap

Berikan file zip ini ke chat baru, lalu minta model:

1. baca `00_START_HERE`, `02_EXPERIMENT_HISTORY`, `04_DEEP_DIAGNOSIS`, `07_V29_V30_DEEP_DIVE`, dan `08_V31_RESEARCH_PLAN`;
2. jangan mulai eksperimen baru sebelum memahami kenapa V30 public naik;
3. anggap V30 score 0.65963 sebagai current public anchor;
4. jangan reuse C/D/E/F sebagai fresh selection surface;
5. jangan menghidupkan kembali generic uncertainty, residual covariance, multi-hop curriculum, global semantic replacement, atau broad threshold search tanpa alasan baru;
6. fokus research V31 pada orthogonal residual experts + empirical context priors + transition-family diagnostics;
7. semua notebook baru Kaggle-ready T4x2, reproducible, organizer-data-only, dan harus fail-closed bila gate gagal.
