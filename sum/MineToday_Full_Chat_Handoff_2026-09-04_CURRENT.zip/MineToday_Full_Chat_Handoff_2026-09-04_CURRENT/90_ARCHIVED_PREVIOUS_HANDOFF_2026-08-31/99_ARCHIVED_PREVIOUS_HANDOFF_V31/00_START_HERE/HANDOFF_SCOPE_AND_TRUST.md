# Scope and Trust Notes

This package is a **documentation handoff**, not a raw artifact dump.

Source hierarchy used when consolidating:
1. latest executed V30 metrics and current chat decisions;
2. V29/V29.5 analyses from this chat;
3. prior 27 Aug full handoff for V1–V25 history;
4. earlier archived handoff summaries where needed.

Where old and new status conflict, newer evidence wins. Old archive is preserved for history but may mention outdated leader/gap/current champion.

No claim should be interpreted as guarantee of private/public leaderboard behavior. All “worth / failed / survived” terms refer to evidence available in this project history.
