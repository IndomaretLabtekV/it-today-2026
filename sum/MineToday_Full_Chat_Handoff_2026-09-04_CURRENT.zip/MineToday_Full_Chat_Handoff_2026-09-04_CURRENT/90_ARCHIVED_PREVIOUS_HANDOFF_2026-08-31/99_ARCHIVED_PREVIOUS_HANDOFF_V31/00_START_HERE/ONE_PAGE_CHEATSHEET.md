# One-Page Cheatsheet

## Task
- 4,000 train / 1,000 test users.
- 17 course modules.
- Features: chat history + 10-skill assessment + module catalog/prerequisites.
- Output 17 scores; metric user-level NDCG@5.
- Each train user has exactly 4/5/6 positive modules dengan graded relevance bands.

## Dataset facts
- chat_history: 14,573 rows, 4,940 users.
- modules_catalog: 17 rows.
- assessments: 5,000 users; 251 invalid/outlier cells.
- 117 train no-chat, 33 test no-chat.
- template-heavy chat; raw duplicates tinggi.
- ~95.6% missed positive relevance mass dari Consensus3 berada pada modules yang tidak explicit disebut; headroom utama latent curriculum/association/order, bukan literal mention.

## Current public
- V30: **0.65963**.
- leader: **0.66141**.
- gap: **0.00178**.

## Public-proven lineage
`V3.1 sparse → binary calibration → V12.2 Consensus3 → V22.3 surgical → V25 → V30 residual LambdaRank`.

## Biggest lessons
- Better embeddings ≠ better leaderboard.
- NDCG objective alone ≠ transfer; architecture/anchor/validation matter.
- Global free reranking sering gagal.
- Small public-proven anchor wajib dipertahankan.
- Exact-template memorization tidak reliable.
- #5/#6 boundary hampir random.
- Generic uncertainty/stability gating gagal (Spearman ~0).
- Multi-hop curriculum distance2/3 tidak terbukti.
- Direct prerequisite signal pair-dependent, bukan deterministic.
- Cooc membantu beberapa split lama tetapi V30 C/D/E incremental 0/3; bukan core.
- Residual covariance graph marginal dan dibuang.
- **V30 Base public +0.00044 membuktikan anchor-conditioned residual LambdaRank transfer.**

## V31 thesis
**Objective-Diverse Transition-Calibrated Residual Ensemble**.

Keep V30 immutable. Research fresh residual experts with different objective/model/feature view, only blend if standalone positive + low error correlation + useful harm complementarity. Use fresh G/H/I and sealed J+chronology.
