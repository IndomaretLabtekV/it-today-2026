# What Worked

- Sparse word+char lexical representation with trajectory tags.
- Assessment cleaning + structured features.
- Per-module binary relevance calibration.
- Tiny module-specific mixing weights (Consensus3).
- Exact surgical public decomposition when evidence is strong.
- Fail-closed primary behavior.
- Nested template-aware validation.
- Protecting public-proven rows/geometry.
- Residual rather than replacement modeling.
- V30 three-fresh-salt max-min selection.
- **Residual LambdaRank Base public lift +0.00044.**
