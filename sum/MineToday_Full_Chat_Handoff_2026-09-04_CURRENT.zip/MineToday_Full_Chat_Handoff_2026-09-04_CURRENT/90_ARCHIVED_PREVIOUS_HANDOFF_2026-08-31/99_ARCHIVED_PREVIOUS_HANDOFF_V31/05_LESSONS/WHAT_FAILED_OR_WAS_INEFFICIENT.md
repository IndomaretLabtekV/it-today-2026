# What Failed / Was Inefficient

- Bigger embeddings as automatic improvement.
- Broad semantic model training without faithful anchor surface.
- Generic router/regime classifier.
- #5/#6 pair decisions.
- Broad prerequisite/next-step hard rules.
- Multi-hop curriculum assumptions.
- Cooccurrence as universal relation signal.
- Residual covariance graph complexity.
- Generic uncertainty gating.
- Repeated/foldbag averaging without geometry checks.
- HMC broad calibration.
- Micro-probes when mathematical upside is too small.
- Submission packages containing many actions without attribution plan.
- Treating same displayed LB score as proof private-only.
- Reusing holdouts after seeing them.
- Optimizing tiny OOF digits and expecting 0.002 public jumps.
