# Do Not Repeat

1. Jangan replace V30 anchor dengan model baru tanpa proof luar biasa.
2. Jangan tune alpha V30 berdasarkan public response 0.65963.
3. Jangan reuse C/D/E/F untuk memilih V31.
4. Jangan aktifkan uncertainty router lagi kecuali metric baru benar-benar predicts harm on fresh data.
5. Jangan anggap curriculum graph deterministic.
6. Jangan bawa residual covariance ke primary.
7. Jangan bawa cooc hanya karena V29 pernah membantu; V30 fresh incremental 0/3.
8. Jangan pakai deep model hanya demi diversity claim.
9. Jangan buat high-dimensional stacking meta-model dari 4k users.
10. Jangan buka sealed J lalu terus retune kalau gagal.
11. Jangan menyimpulkan private/public membership dari flat score.
12. Jangan lupa exact package versions/seed/hash; near-tie geometry sensitif environment.
