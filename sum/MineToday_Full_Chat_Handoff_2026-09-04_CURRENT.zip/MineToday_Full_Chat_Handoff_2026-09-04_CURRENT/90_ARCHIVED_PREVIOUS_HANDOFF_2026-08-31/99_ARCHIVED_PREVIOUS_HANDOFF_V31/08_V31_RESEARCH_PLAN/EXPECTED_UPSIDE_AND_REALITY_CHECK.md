# V31 Upside Reality Check

Current gap = 0.00178. V30 public gain was 0.00044 despite offline pooled +0.000732.

Therefore:
- a +0.0002 cleanup is useful but unlikely to reach leader;
- transition veto alone probably insufficient;
- V31 needs a new expert that changes additional users correctly or provides stronger correction where V30 is weak;
- target should be fresh offline signal materially above V30-scale, while retaining robustness.

Do not promise a guaranteed 0.66141+. Public subset remains unknown.
