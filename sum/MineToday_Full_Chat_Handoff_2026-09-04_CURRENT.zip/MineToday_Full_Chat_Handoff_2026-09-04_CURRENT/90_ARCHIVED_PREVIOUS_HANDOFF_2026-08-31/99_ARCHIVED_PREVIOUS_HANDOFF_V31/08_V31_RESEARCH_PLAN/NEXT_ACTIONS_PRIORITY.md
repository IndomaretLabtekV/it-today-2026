# Next Actions — Priority Order

1. **Freeze V30** score/predictions/OOF as current public anchor asset.
2. Build fresh G/H/I research protocol; no reuse C/D/E/F.
3. Implement XENDCG residual with same deployment geometry.
4. Implement fold-safe hierarchical latest-intent→module target encoding.
5. Controlled YetiRank residual retest.
6. Measure OOF delta diversity/harm overlap, not just mean NDCG.
7. Only if still useful, implement tiny set/list neural residual.
8. Audit transition families on G/H/I; test whether safety veto is reproducible.
9. Freeze one V31 candidate/ensemble.
10. Open sealed J + chronology.
11. Only submit if offline evidence has enough magnitude/robustness to justify scarce slot.

Do not spend next submission on V30 alpha retune or small threshold tweak.
