# Proposed Fresh G/H/I Cross-Objective Audit

Before final V31 submission notebook, recommended research experiment:

### Fixed candidates
1. LambdaRank V30 reference.
2. XENDCG residual.
3. YetiRank residual.
4. Optional SetRanker only if implementation remains low-capacity and deterministic enough.

### Fixed feature blocks
- Base V30 features.
- Base + hierarchical latest-intent→module TE.
Avoid combinatorial feature search.

### Fresh worlds
G/H/I = three new template-group repeated nested partitions. Do not inspect old C/D/E for selection.

### Outputs
- per-world / per-fold NDCG deltas;
- pooled cluster bootstrap;
- per-user delta matrices;
- correlation matrix among experts;
- harm-overlap table;
- transition-family audit;
- coverage/order/membership changes;
- candidate ensemble simulation with very low-dimensional fixed weight grid, ideally preregistered.

### Promotion logic
A new expert must be positive enough by itself OR provide clear complementary harm reduction. If all expert deltas correlate strongly and no fresh gain, stop rather than stack them.
