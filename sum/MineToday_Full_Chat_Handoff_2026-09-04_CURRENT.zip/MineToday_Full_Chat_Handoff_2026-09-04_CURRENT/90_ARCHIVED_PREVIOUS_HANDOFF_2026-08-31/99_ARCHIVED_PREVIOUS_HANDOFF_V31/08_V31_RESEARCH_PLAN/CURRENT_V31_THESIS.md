# Current V31 Thesis

## Proposed name
**V31 — Objective-Diverse Transition-Calibrated Residual Ensemble**

This is a research thesis, not yet implemented/frozen.

## Core principle
V30 public 0.65963 becomes **immutable anchor**. V31 must add orthogonal residual information, not replace V30 or simply increase alpha.

## Candidate experts
A. V30/LambdaRank residual reference.
B. LightGBM `rank_xendcg` residual with comparable feature surface.
C. CatBoost YetiRank residual retest.
D. Optional tiny joint-list SetRanker if compute/time permits and only as diversity expert.

## Feature additions to test
- fold-safe hierarchical latest-intent→module empirical priors;
- optional heavily-smoothed previous→latest intent trajectory→module priors.

## Diversity evaluation
- standalone fresh delta;
- worst-salt delta;
- delta correlation;
- harm overlap;
- transition-family overlap;
- test coverage.

## Transition calibration
Do not hardcode C/D/E good/bad families. On fresh G/H/I, log exact crossings and estimate whether transition family stability predicts realized NDCG delta. If reproducible, use only as safety veto/trust-region; not a generic router.

## Validation
- fresh G/H/I development;
- freeze architecture/weights;
- sealed J + chronology rejection-only;
- C/D/E/F are historical and forbidden as fresh selectors.

## Why this direction
V30 already proved “more robust residual ranking” can move public. Remaining +0.00178 requires new orthogonal signal and coverage, not just pruning a few bad crossings.
