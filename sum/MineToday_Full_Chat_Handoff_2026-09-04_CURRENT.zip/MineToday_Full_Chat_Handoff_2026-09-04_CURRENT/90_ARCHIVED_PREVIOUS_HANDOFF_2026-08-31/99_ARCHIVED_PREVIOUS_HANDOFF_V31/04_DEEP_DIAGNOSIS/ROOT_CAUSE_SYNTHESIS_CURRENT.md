# Root Cause Synthesis — Current

## 1. Task bukan semantic retrieval sederhana
Literal intent hanya menjelaskan sebagian target. Banyak positive modules bersifat latent, overlapping, prerequisite/foundation, career progression, atau organizer-specific association. Karena itu stronger sentence embedding tidak otomatis membantu.

## 2. Dataset kecil di unit independen
68k user-item rows bukan 68k independent examples; hanya 4,000 labeled users. High-capacity model cepat mempelajari artifacts/template families yang tidak transfer.

## 3. NDCG@5 membuat local boundary mistakes mahal
Score absolute tidak penting jika ranking tidak berubah. Sebaliknya tiny crossing di Top1/Top5 bisa mengubah NDCG. Model harus dianalisis dalam ranking geometry, bukan hanya AUC/RMSE.

## 4. Validation mining adalah risiko besar
Berulang kali model local naik tetapi public turun karena:
- reused folds/LOCK;
- second-level non-nested leakage;
- OOF/full-fit geometry mismatch;
- selecting thresholds after seeing holdout;
- comparing non-faithful anchor surfaces.
V30 memperbaiki ini dengan fresh C/D/E + sealed F.

## 5. Anchor kuat adalah aset utama
Consensus3/V25 menyimpan sparse lexical, calibrated binary relevance, assessment, template/trajectory signals yang sangat public-proven. Replacement model hampir selalu kalah. Residual expert yang kecil adalah pattern paling sukses.

## 6. Direction > coverage
V27 terlalu sedikit coverage; V28 punya banyak coverage tetapi negative direction. V30 menemukan broad residual direction yang positive rata-rata dan public. V31 perlu expand direction **orthogonally**, bukan hanya increase alpha.

## 7. Generic uncertainty tidak predict correctness
V29.5 honest replica stability Spearman hampir nol. Jadi per-user scalar confidence router tidak punya evidence.

## 8. Curriculum relationship tidak deterministic
Direct latest-intent prerequisite distance1 punya aggregate lift, tetapi edge rates sangat pair-dependent. Multi-hop graph tidak robust. V30 pair-conditional DirectCurr hanya marginal dan bukan public winner.

## 9. Split/regime instability tetap nyata
V29 LOCK A positive dan V29.5 LOCK B negative. V30 mengurangi concern melalui 3 fresh salts + sealed F; public result akhirnya positive. Tetapi public realized +0.00044 lebih kecil daripada offline pooled +0.00073, sehingga transfer shrinkage masih harus diasumsikan.

## 10. Current bottleneck menuju leader
Gap 0.00178 jauh lebih besar daripada V30 gain. Cleanup transition atau alpha tweak kemungkinan hanya menghasilkan 1e-4 scale. Dibutuhkan new orthogonal residual signal yang memperbaiki users di luar 77 test rankings yang V30 ubah.
