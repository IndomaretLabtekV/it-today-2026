# Validation Evolution and Guardrails

## Failure stages
1. Ordinary OOF/repeated CV tampak tinggi tetapi public tidak transfer.
2. Routers menggunakan second-level information tidak fully nested.
3. Anchor surface mismatch (mis. residual evaluated on ADAPT but deployed on Consensus3).
4. LOCK dipakai terlalu sering sehingga berubah menjadi development set.

## Current protocol yang lebih sehat
- Template-aware grouping untuk mengurangi duplicate-family leakage.
- Entire user query group = 17 modules untuk LTR.
- Nested outer fold untuk label-derived features.
- Historical folds yang sudah dilihat researcher tidak lagi dianggap fresh.
- Development candidates harus preregistered terbatas.
- Selection by worst-salt / robustness, bukan highest single CV.
- Sealed rejection-only world + chronology.
- Primary fail-close ke public anchor jika gates gagal.

## V30 specific
Fresh C/D/E = development. F = sealed template lock. Chronology U3001–U4000 = second rejector. Setelah hasil V30 dilihat dan public submitted, C/D/E/F sekarang **historical research data** dan tidak boleh dipakai lagi sebagai fresh V31 selector.

## V31 proposed
Fresh G/H/I development repeated nested group folds. Sealed J + chronology rejection-only. Jangan run endless salts; 3 fresh partitions lalu stop agar tidak validation-mine.
