# Failure Catalog / Do Not Repeat Blindly

- Larger semantic embedding as global scorer (Qwen3 8B, BGE branch): failed transfer.
- QLoRA broad residual without faithful deployment anchor: failed.
- Semantic LambdaRank as broad replacement: failed.
- Exact-template/family lookup as target memorizer: not robust.
- Repeated averaging/foldbag as automatic improvement: can destroy score geometry.
- Generic selective router: second-level overfit / routing error.
- Generic #5/#6 pair correction: AUC ~0.52.
- Broad prerequisite hard rules: strongly negative.
- Multi-hop transitive curriculum: unsupported by V29.5.
- Generic stability/uncertainty alpha gating: Spearman ~0.
- Residual covariance graph: marginal +~0.000041, complexity not justified.
- Co-occurrence as core assumption: V30 incremental 0/3 salts, negative mean.
- Pure calibration HMC broad correction: coverage high, direction negative.
- Tiny micro-probes as main strategy: insufficient mathematical upside.
- Leaderboard equality → “private user”: invalid inference.
- Raise alpha because public V30 worked: leaderboard fitting risk.
- Reuse C/D/E/F to choose V31: researcher leakage.
- Generic deep architectures (Two-Tower/DeepFM/TabNet) just because “neural”: not justified with 17-item full ranking and 4k independent users.
