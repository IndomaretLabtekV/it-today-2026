# Corrections to Prior Hypotheses

1. **“Co-occurrence failed total”** — too strong after V29 strict ablation. Later V30 shows cooc is not core and incremental negative on C/D/E, so current status = optional/historical, not primary.
2. **“Skill-gap/curriculum is strongest signal”** — false. V29 Base already strong; gap mixed. V29.5 direct prerequisite distance1 strong only in specific context. V30 Base public winner.
3. **“V29 is classic overfit”** — too simple. It had positive strict/LOCK/chrono but heterogeneous/split-sensitive corrections.
4. **“Variance-control will save V29”** — killed by V29.5; generic stability did not predict harm.
5. **“Transitive graph is key”** — false; distance2/3 weak. Direct pair-specific relationship only.
6. **“V30 improvement comes from curriculum”** — false. Public submission is `ltr_base` winner; DirectCurr only small incremental development signal.
7. **“Sealed positive proves no overfit”** — too strong. F/chronology CIs cross zero; correct statement: no fresh-world evidence strong enough to reject development winner, and public later confirmed positive transfer.
8. **“LambdaRank itself is new breakthrough”** — false; LambdaRank existed early. Breakthrough = public-proven anchor + residual LambdaRank + robust validation/deployment geometry.
