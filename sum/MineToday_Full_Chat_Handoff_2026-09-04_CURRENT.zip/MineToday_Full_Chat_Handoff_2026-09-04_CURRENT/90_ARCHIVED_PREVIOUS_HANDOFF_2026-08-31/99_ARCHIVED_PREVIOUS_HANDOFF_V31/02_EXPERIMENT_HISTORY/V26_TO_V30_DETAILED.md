# V26–V30 Detailed Continuation

## V26 — Core Attribution Counterfactual Pruning
V25 core6 di-audit per action family. U4491 merupakan strict prune paling jelas: family delta sekitar -0.00964, confidence interval negatif, positive/harm ~14.3%/71.4%, 0/5 fold wins. U4074 dan U4567 punya positive evidence lebih kuat. Primary V26 = V25 minus U4491. Public tetap 0.65919. Kesimpulan: micro-attribution informative tetapi display LB tidak cukup untuk bridge gap.

## V27 / V27.1 — Head12 branch
Motivasi: adjacent pair learnability paling kuat ada #1/#2. V27 awal raw 30 test swaps terlalu agresif; probability calibration salah karena class_weight balanced probabilities dianggap posterior. V27.1 memperbaiki calibration/support gates. Namun hanya empat diagnostic test swaps; maximum possible public boost dari 4 #1/#2 swaps ~0.000717. Bahkan perfect outcome belum menutup gap saat itu. Branch closed by precommitment.

## V28 — HMC
Broad graded calibration. Ini penting karena menguji hypothesis “butuh coverage lebih besar”. Coverage memang besar (251 users berubah), tetapi ordinary dan LOCK negatif. Maka problem bukan coverage melainkan direction/generalization.

## V29 — Curriculum-Aware Residual LTR
Pertama kali recent architecture menemukan positive signal di strict+LOCK+chronology. Namun pseudo-public lower tail gagal. Detailed ablation menunjukkan LambdaRank Base itself sudah useful; current gap features bukan strongest signal; cooc punya strict contribution; residual graph expendable.

## V29.5 — Kill Test
Menguji apakah V29 tail risk bisa dijelaskan oleh uncertainty. Jawaban: tidak. Generic ranking-space stability hampir tidak berkorelasi dengan realized delta. Direct prerequisite distance1 dari explicit latest intent punya signal, tetapi transitive distance2/3 tidak. Fresh salted LOCK sign flip mengungkap regime instability. Ini memotivasi V30 multi-salt protocol.

## V30 — Split-Robust Residual LTR
Three fresh salts C/D/E dibuat setelah A/B historical sudah “terpakai oleh researcher”. Candidates dibatasi tiga dan alpha fixed .16 untuk mengurangi degrees of freedom. Winner dipilih max-min, bukan mean. Base menang worst-salt. Sealed F dan chronology non-negative. Public naik +0.00044. Ini validasi paling penting sejak Consensus3/V25.
