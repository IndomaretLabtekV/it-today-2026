# Master Timeline V1–V30

## V1–V2 — semantic-heavy start

### V1 — 0.63629
Hybrid semantic Qwen 0.6B, reranker, TF-IDF, LambdaRank/template memory. Terlalu banyak moving parts; calibration dan anchor belum matang.

### V2 — 0.64413
Semantic model multilingual lebih besar. Public naik, tetapi masih jauh di bawah sparse pipeline berikutnya. Lesson: scale embedding bukan bottleneck utama.

## V3–V7 — sparse + calibration breakthrough

### V3 cross-encoder
Training attempt crash dengan FP16 gradient unscale issue; branch tidak menjadi winner.

### V3.1 sparse — 0.65036
Word+char TF-IDF, typo robustness, current/recent/older trajectory tags, template tokens, assessment + invalid flags, sparse multi-output Ridge. Backbone ini bertahan sampai model-model terbaru.

### Calibration family
- cal035 0.65540
- Borda 0.65489
- cal045 0.65639
Per-module binary relevance LightGBM calibration menjadi gain besar. Probability-like calibration lebih berguna daripada pure rank fusion.

## V8–V12.2 — stability & module weights

### V8
Repeated seed 0.65577; foldbag 0.65140. Broad averaging mengubah score geometry dan mengencerkan strong calibration.

### V9/V9.1
Nested/residual/adaptive branch tampak menarik local tetapi V9.1 public 0.65432. Lesson utama: local residual learnability tidak otomatis transfer.

### V12 Leader6 — 0.65792
Small module-specific mixing weight corrections.

### V12.2 Consensus3 — 0.65856
Frozen module-specific weights:
M002 .44, M006 .55, M007 .60, M010 .40, M011 .55, M012 .55, M015 .44, M017 .53, lainnya .45. OOF sekitar 0.664368. Menjadi immutable reference anchor untuk banyak versi berikutnya.

## V13–V15 — router/pairwise/abstention

### V13.1 — 0.65754
Selective dual-expert router local +~0.00064 tapi public -0.00102. Ditemukan second-level non-nested leakage + OOF/full-fit geometry mismatch. Router error lebih mahal dari benefit lokal.

### V14
Fully nested Top6 pairwise. Learnability by adjacent rank:
#1/#2 AUC ~0.668; #2/#3 .614; #3/#4 .563; #4/#5 .530; #5/#6 .521. Boundary bawah hampir random.

### V15
Fully nested surgical utility menerima zero actions. Fail-closed yang benar: jangan memaksa coverage.

## V16–V20 — large semantic exploration

### V16
Frozen Qwen3-Embedding-8B global semantic; tidak lolos gate.

### V17
Top5-aware semantic representation; tiny gains, tidak stabil.

### V18 — 0.65829
Multi-intent prototype/metric semantic, dekat tetapi di bawah anchor.

### V19 — 0.65791
Stable semantic ordinary-first; public turun.

### V20
Qwen+BGE late interaction / distribution diagnostics. Adversarial shift near chance, broad semantic complementarity tidak cukup.

## V21 family — QLoRA / residual semantic ranking

### V21 — 0.65786
Qwen3-Embedding-8B 4-bit QLoRA. Technically successful, tapi anchor transport mismatch: residual dinilai pada weaker surface lalu dipasang pada full Consensus3.

### V21.1 — 0.65869
Bagged lower-capacity stable-module calibration, hanya puluhan test users berubah. Menjadi sumber action family untuk V22/V25.

### V21.2 — 0.65776
Anchor-initialized semantic LambdaRank trust-region. Metric-aware objective tidak menyelamatkan weak semantic residual.

## V22 — exact public decomposition

### V22.1 — 0.65846
M003/M014 bulk behavior ternyata bukan gain.

### V22.2 — 0.65878
4 changes: U4047,U4498,U4876,U4953.

### V22.3 — 0.65912
Hanya U4047 M007>M009 + U4953 M005>M016. Ini pair public winner.

## V23 — F2LLM local-action utility
Frozen F2LLM-v2-4B, local Top7 score-swap candidates, structured + hybrid utility. Conservative OOF delta hanya +1.21e-6, worst fold negatif; balanced/confirmed negatif; prerequisite rules negatif. Primary fail-closed exact PB. Stronger embedding again not bottleneck.

## V24 — causal micro-probes
Exact single-hypothesis public probes. PB+U4498 tetap 0.65912. Same display score tidak membuktikan “private-only”; bisa rounding/tie/zero/cancellation.

## V25 — action distillation — 0.65919
PB + core6:
U4074 M003>M014; U4176 M017>M003; U4491 M002>M003; U4567 M012>M014; U4836 M002>M003; U4929 M002>M003.
Relaxed3 tambahan U4030/U4650/U4731. Core6 naik +0.00007, aggressive9 displayed flat.

## V26 — attribution pruning — 0.65919
OOF attribution menunjukkan U4491 paling buruk: mean family delta ~-0.00964, CI below zero, 0/5 wins. V26 remove U4491 tapi public tetap 0.65919. Micro-probe scale tidak cukup mengejar ~0.002 gap.

## V27 — upper-rank reranking diagnostics
Mengincar #1/#2 karena pair learnability tertinggi. Raw Head12 30 swaps terlalu agresif dan class_weight-balanced probabilities salah diperlakukan seperti posterior calibrated.

### V27.1
Calibrated support-aware head12: AUC group .6864, ordinary .6842, LOCK .6535, chrono .6996. Strict candidate hanya 4 test swaps; mathematical max #1/#2 gain sekitar +0.000717, tidak cukup menutup leaderboard gap. Branch ditutup.

## V28 — hierarchical graded module calibration
HMC broad correction punya coverage 251 users tetapi direction salah. Selected plain20 ordinary -0.001189, fresh LOCK -0.002248. Semua pre-registered variants infeasible. Lesson: coverage bukan bottleneck; direction adalah bottleneck.

## V29 — curriculum-aware residual LTR
Residual LightGBM LambdaRank on top of V25/Consensus3. Ablations Base/Gap/Cooc/Residual graph. Selected full alpha .16:
strict +0.001116, 5/5 positive; fresh LOCK +0.000806; chrono +0.000122. Tetapi pseudo-public 35% p10 -0.000795 gagal preregistered lower-tail gate. Primary fail-closed exact anchor; diagnostic tidak disubmit.

Important ablation:
- LTR Base .10 +0.000650 5/5;
- gap block mixed, bukan strongest signal;
- cooc pada alpha .16 gap +0.000694 → gap+cooc +0.001075;
- residual graph hanya tambah ~+0.000041.

## V29.5 — reliability/curriculum kill-test diagnostics
Tujuan: test uncertainty monotonicity, transitive curriculum precision, fresh-world cooc, cluster-aware pseudo-public.

Findings:
- generic ranking stability gagal predict harm; Spearman ~0.003–0.015;
- direct explicit-intent prerequisite distance1 strong aggregate lift ~1.344;
- distance2/3 tidak kuat;
- prerequisite pair sangat heterogeneous;
- cooc fresh transfer hanya relative/mixed, bukan absolute guarantee;
- fresh LOCK baru sign-flip negatif sementara chronology positif → split/regime instability;
- residual graph tetap tidak worth.

Implementation incident: initial notebook error missing `build_anchor_split_full`; fixed notebook kemudian run.

## V30 — 3-fresh-salt split-robust residual LTR — public 0.65963
Architecture candidates precommitted alpha .16:
A `ltr_base`; B `ltr_direct`; C `ltr_direct_cooc`.
Fresh C/D/E each 5-fold nested group OOF; winner by worst-salt robustness; sealed F + chronology rejection-only.

Results:
Base C +.000890 / D +.000449 / E +.000855; 13/15 fold wins; pooled +.000732 CI [.000337,.001145]. Direct mean +.000815 but lower worst salt; Cooc incremental negative 0/3 salts. Winner Base. Sealed F +.000969; chrono +.000042. FINAL_GATE passed.

Public submission V30 primary: **0.65963 (+0.00044)**, rank kembali sekitar #5. Ini first public confirmation residual LambdaRank branch.

Implementation incident: first V30 run error `GEOMETRY_ATOL` undefined during frozen V25 promotion; fixed v2 kemudian berhasil.
