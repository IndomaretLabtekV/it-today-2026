# Public Scoreboard — Canonical Snapshot

| Version / candidate | Public NDCG@5 | Main lesson |
|---|---:|---|
| V1 | 0.63629 | semantic-heavy starting point lemah |
| V2 | 0.64413 | larger semantic helps sedikit, belum bottleneck |
| V3.1 sparse | 0.65036 | sparse TF-IDF + trajectory + assessment breakthrough |
| cal035 | 0.65540 | binary relevance calibration sangat efektif |
| Borda | 0.65489 | rank fusion lebih buruk |
| cal045 | 0.65639 | stronger calibration |
| V8 repeated | 0.65577 | averaging tidak gratis |
| V8 foldbag | 0.65140 | geometry rusak |
| V9.1 | 0.65432 | residual local gain tidak transfer |
| V12 Leader6 | 0.65792 | tiny module calibration works |
| V12.2 Consensus3 | 0.65856 | long-lived anchor |
| V13.1 | 0.65754 | selective router local→public failure |
| V18 | 0.65829 | multi-intent semantic near but below anchor |
| V19 | 0.65791 | semantic branch fails public |
| V21 | 0.65786 | QLoRA/anchor mismatch |
| V21.1 | 0.65869 | stable-module low-capacity correction tiny win |
| V21.2 | 0.65776 | semantic LambdaRank fails |
| V22.1 | 0.65846 | M003/M014 bulk negative |
| V22.2 | 0.65878 | four exact actions |
| V22.3 | 0.65912 | U4047+U4953 pair winner |
| V24 PB+U4498 | 0.65912 | displayed zero delta |
| V25 core6 | 0.65919 | +0.00007 surgical package |
| V25 aggressive9 | 0.65919 | added actions no displayed gain |
| V26 remove U4491 | 0.65919 | prune no displayed gain |
| V27/V27.1 | not recommended/submitted as winner | head12 math upside too small / unstable |
| V28 | no submit | broad HMC negative fresh LOCK |
| V29 | no submit | promising strict but pseudo-public tail failed gate |
| V29.5 | diagnostics only | exposed split/regime instability, uncertainty failure |
| **V30** | **0.65963** | **public-confirmed residual LambdaRank branch** |

Leader terakhir user: **0.66141**. Gap current: **0.00178**.

Catatan: angka leaderboard adalah displayed values; jangan melakukan micro-algebra seolah precision tak terbatas.
