# Open Questions

1. Apakah XENDCG menghasilkan residual positive yang less correlated dengan LambdaRank?
2. Apakah YetiRank sebagai residual expert (bukan primary) akhirnya transfer?
3. Apakah latest-intent→module TE meng-capture latent relevance tanpa template overfit?
4. Apakah trajectory pair TE punya support cukup setelah heavy smoothing?
5. Apakah transition-family sign stability replicate di fresh G/H/I?
6. Bisakah safety veto improve worst-salt tanpa collapse coverage?
7. Berapa low-dimensional blend weight yang bisa pre-register tanpa validation mining?
8. Apakah tiny set-wise neural model memberi genuine diversity atau hanya noise karena 4k users?
9. Apakah V31 offline uplift cukup besar sehingga, setelah realistic transfer shrinkage, masih bisa menutup 0.00178?
