# Current Champion

Current public champion milik user adalah **V30 ltr_base residual LambdaRank**, score **0.65963**.

Conceptual score lineage:
`Consensus3/V25 public-proven anchor + small LambdaRank residual (alpha .16)`, dengan V25 public rows protected.

V30 development winner was Base, not DirectCurr. Therefore future chat must not call current champion “curriculum model”.

Current leader 0.66141; gap 0.00178.
