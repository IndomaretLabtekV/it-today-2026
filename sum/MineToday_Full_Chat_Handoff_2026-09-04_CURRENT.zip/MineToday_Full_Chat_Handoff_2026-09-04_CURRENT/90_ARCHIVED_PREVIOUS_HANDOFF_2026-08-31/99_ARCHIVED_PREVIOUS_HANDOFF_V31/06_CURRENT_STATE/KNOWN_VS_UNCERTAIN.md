# Known vs Uncertain

## High confidence
- V30 branch transfers public positively.
- anchor-conditioned residual ranking is worth continuing.
- generic uncertainty gating failed.
- residual covariance not worth primary.
- distance2/3 curriculum not justified.
- cooc was not additive in V30 C/D/E.
- direct curriculum only marginal vs Base.
- validation robustness matters more than single best mean.

## Medium confidence
- transition-family stability may identify harmful crossings.
- hierarchical intent→module target encoding may capture latent organizer associations.
- objective-diverse rankers may provide useful low-correlation residuals.

## Unknown
- whether XENDCG/YetiRank/tiny SetRanker gives positive fresh worst-salt improvement;
- whether transition stability replicates on G/H/I;
- whether a residual ensemble can create enough coverage/scale to close +0.00178;
- exact private leaderboard behavior.
