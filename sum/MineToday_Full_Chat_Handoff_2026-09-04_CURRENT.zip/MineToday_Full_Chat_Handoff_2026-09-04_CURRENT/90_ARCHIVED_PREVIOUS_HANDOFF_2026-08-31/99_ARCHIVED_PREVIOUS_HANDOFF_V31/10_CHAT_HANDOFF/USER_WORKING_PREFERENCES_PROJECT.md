# Working Preferences / Collaboration Style for This Project

- Bahasa santai Indonesia, user nyaman dengan gua/lu.
- User mau deep analysis sebelum menghabiskan scarce Kaggle slot.
- Notebook harus Kaggle-ready, biasanya T4x2, reproducible, dan tidak perlu menampilkan proses Python pembuat notebook.
- Setelah run, user biasanya upload executed notebook + results zip; assistant harus audit detail sebelum merekomendasikan submit.
- User ingin target kompetitif, bukan sekadar improvement kosmetik; jangan fake certainty bahwa suatu versi pasti mengalahkan leader.
- Public leaderboard outcome harus dipakai sebagai evidence secara hati-hati, bukan target leakage.
- Jangan mengatakan score sama berarti pasti private.
- Prefer fail-closed candidates daripada memaksa eksperimen jelek.
