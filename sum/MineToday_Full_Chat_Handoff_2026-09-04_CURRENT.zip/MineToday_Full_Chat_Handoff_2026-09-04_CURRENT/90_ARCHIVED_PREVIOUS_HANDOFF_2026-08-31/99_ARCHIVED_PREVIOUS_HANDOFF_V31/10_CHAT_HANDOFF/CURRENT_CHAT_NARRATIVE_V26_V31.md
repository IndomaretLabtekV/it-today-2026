# Current Chat Narrative — V26 through V31 Research

This chat continued from a prior full handoff around V25 score 0.65919.

## V26
User wanted deeper attribution. Analysis showed U4491 was the only strict prune; notebook V26 removed it. Public remained 0.65919. Conclusion: surgical micro-actions cannot by themselves bridge large leaderboard gap.

## V27 / V27.1
Research moved to upper rank #1/#2 because pair AUC strongest. Initial V27 probability economics were miscalibrated due class_weight. V27.1 fixed calibration/support; only four test swaps remained, giving max theoretical +~0.000717. Not enough to beat leader, so branch was closed.

## V28
Tried hierarchical graded module calibration to get coverage. It changed many users but fresh LOCK strongly negative. Key conclusion: coverage was not the problem; correction direction was.

## V29
User shared idea around skill-gap, IndoBERT, co-occurrence, long-format LTR. Deep audit rejected IndoBERT as core because bigger semantic models already failed. Proposed Curriculum-Aware Residual LTR. V29 run produced strict +0.001116 5/5, positive LOCK/chrono, but pseudo-public p10 negative enough to fail gate. Recommendation: do not submit diagnostic yet.

## V29.5
Before V30, user asked whether variance-controlled curriculum architecture was actually justified. A diagnostics-only kill-test was designed. First notebook crashed because helper `build_anchor_split_full` missing; fixed version supplied. Results killed generic uncertainty, narrowed curriculum to direct pair-specific distance1, and exposed fresh split/regime instability. This caused another architecture pivot.

## V30 design
User approved exact design: 3 fresh salts C/D/E, 5-fold nested each, Base/Direct/Direct+Cooc only, alpha .16 fixed, max-min selection, sealed F+chronology. First run crashed with `GEOMETRY_ATOL` undefined; fixed v2 supplied.

## V30 result
All research gates relevant to Base passed. Base won by worst-salt. Direct small marginal; cooc failed incremental. User submitted V30 primary. Public rose to **0.65963**, rank around #5, leader **0.66141**.

## Current V31 discussion
User asked what can be adapted for V31 and supplied generic suggestions: deep learning, advanced LTR, feature engineering, ensembling. Audit concluded:
- generic Two-Tower/DeepFM/TabNet not primary;
- V30 already LambdaRank;
- rank_xendcg is promising objective-diversity candidate;
- YetiRank worth one residual retest;
- tiny set-wise neural residual can be optional orthogonal expert;
- hierarchical intent→module target encoding is more promising than generic extra time decay;
- low-degree OOF residual ensemble is preferred over generic stacker;
- transition-family stability is a new safety hypothesis;
- use fresh G/H/I + sealed J.

No V31 notebook has been built yet.
