# Decision Log — Important Locks

- Consensus3 became immutable model anchor after V12.2.
- V22.3 two-user pair became public-proven surgery.
- V25 became 0.65919 anchor.
- V26 prune did not change public display.
- V27.1 closed because max mathematical upside insufficient.
- V28 broad calibration rejected due negative fresh LOCK.
- V29 diagnostic not submitted because pseudo-public lower tail failed gate.
- V29.5 killed generic uncertainty and multi-hop curriculum thesis.
- V30 fresh C/D/E designed because old A/B had researcher leakage.
- V30 alpha .16 and candidate set precommitted.
- V30 Base selected by worst-salt max-min despite Direct having higher mean.
- V30 passed sealed F+chronology and was submitted.
- V30 public 0.65963 confirmed residual-LTR branch.
- V31 must use new G/H/I and sealed J; do not reuse C/D/E/F as selectors.
- V31 goal is orthogonal residual ensemble, not V30 alpha tuning.
