# Key Numbers

- train users: 4000
- test users: 1000
- modules: 17
- chat rows: 14573
- assessment invalid cells: 251 / 50000
- no-chat: 117 train, 33 test
- Consensus3 OOF: ~0.664368
- Consensus3 public: 0.65856
- V25 public: 0.65919
- V30 public: 0.65963
- leader: 0.66141
- gap: 0.00178

V30 Base C/D/E: +.000890 / +.000449 / +.000855
V30 pooled: +.000732, CI [.000337,.001145]
V30 sealed F: +.000969
V30 chronology: +.000042
V30 public realized: +.00044
V30 test geometry: 77 order / 8 top1 / 7 membership changes.
