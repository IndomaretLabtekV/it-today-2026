# V30 Transition Findings — Historical Hypothesis Only

These came from C/D/E and are **not allowed as hardcoded V31 rules** without fresh replication.

Examples repeatedly strong in historical audit include:
- M003 > M007
- M005 > M002
- M002 > M001
- M005 > M007
- M011 > M005
- M001 > M015
- M005 > M004

Examples harmful/negative historical families include:
- M015 > M001
- M006 > M004
- M003 > M006
- M014 > M004
- M008 > M006

Use only to motivate the hypothesis “transition family may be predictable”. Re-estimate on fresh G/H/I before any deployment veto.
