# Glossary

- **Anchor**: public-proven score matrix kept mostly immutable.
- **Consensus3**: V12.2 sparse+calibrated anchor with tiny module weights.
- **V25 anchor**: Consensus3 plus public-tested surgical actions, score 0.65919.
- **V30 anchor/champion**: V25-derived anchor plus residual LambdaRank Base, public 0.65963.
- **Residual expert**: model that proposes small correction relative to anchor, not full replacement.
- **Strict/template-group OOF**: folds separating template families.
- **LOCK**: fresh holdout used as external/rejection audit, not selector.
- **Chronology**: later user block U3001–U4000 as alternate generalization world.
- **Fail-closed**: if gates fail, primary output reverts exactly to anchor.
- **Transition family**: ordered rank crossing such as M003>M007.
- **Delta correlation**: correlation of per-user NDCG improvements/harm between experts.
- **DirectCurr**: pair-conditional latest explicit intent → direct prerequisite feature block.
- **Cooc**: fold-safe label co-occurrence feature block.
- **Researcher leakage**: holdout becomes indirectly optimized because researcher repeatedly sees it, even with no code target leakage.
