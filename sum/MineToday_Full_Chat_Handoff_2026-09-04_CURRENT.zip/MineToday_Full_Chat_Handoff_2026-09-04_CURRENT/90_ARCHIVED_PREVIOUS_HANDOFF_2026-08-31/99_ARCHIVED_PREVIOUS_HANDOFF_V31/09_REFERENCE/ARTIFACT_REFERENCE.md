# Artifact Reference (Descriptions Only)

No notebook/results files are included in this handoff.

Important historical artifacts mentioned in chat:
- organizer dataset zip: `mine-today-data-mining-competition-it-today-2026.zip`
- TM rules PDF: `TM MINETODAY.pdf`
- notebook/results collections V1–V22
- V23 artifacts / F2LLM cache
- V24 results
- V25 notebook/results
- V26 attribution notebook/results
- V27 / V27.1 head12 diagnostics
- V28 HMC notebook/results
- V29 `MineToday_v29_Curriculum_Aware_Residual_LTR.ipynb` + results
- V29.5 `MineToday_v29_5_Reliability_Curriculum_Kill_Test_FIXED.ipynb` + results
- V30 `MineToday_v30_3FreshSalt_SplitRobust_DirectCurriculum_Residual_LTR_FIXED_v2.ipynb` + results
- V30 primary submission produced public 0.65963.

If chat baru perlu exact CSV values, user can upload corresponding results zip. This handoff contains the important interpreted numbers already.
