# Archive Note

Folder ini adalah snapshot explanation-only handoff 27 Aug 2026 (state sekitar V25). Dipertahankan agar detail sejarah lama tidak hilang. Beberapa angka status/leader di dalam archive sudah outdated; untuk state terbaru selalu prioritaskan `00_START_HERE` dan dokumen V26–V31 di root handoff ini.
