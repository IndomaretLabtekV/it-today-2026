# Hybrid34 Public Decomposition

This is the most important recent empirical result.

## Stage 1: V31 changes vs V30

V31 changed 60 users vs V30:
- 34 in S3 overlap with V30 changes;
- 26 new-only S1 changes.

Public tests:
- V30 + newonly26 → `0.65906`.
- V30 + overlap34 → `0.66006`.

Therefore:
- S1 is public-toxic;
- S3 is public-positive as a package.

## Stage 2: decompose S3 by ranking geometry

S3 34 actions split into three mutually exclusive categories:
- **3 Top1-changing**;
- **4 Top5-membership-changing**;
- **27 pure order-only**.

Public ablations:

### Remove Top1 group
Hybrid34 0.66006 → 0.65950.
Approx Top1 package contribution:
`+0.00056`.

This overturned prior generic assumption that Top1 interventions should always be locked. In this **specific S3 public-proven region**, the 3 Top1 changes are highly valuable.

### Remove Membership group
Hybrid34 0.66006 → 0.66006.
Displayed contribution ~0. Membership actions may individually cancel; aggregate is approximately neutral at leaderboard precision.

### Remove OrderOnly group
Hybrid34 0.66006 → **0.66020**.
Approx order-only contribution:
`-0.00014`.

Thus 27 internal-order changes were collectively harmful.

## Current rule
Within deterministic S3:
- keep Top1-changing actions;
- keep membership-changing actions for now;
- reject pure order-only actions.

This rule is generic geometry, not user-ID hardcoding.

## Next decomposition
27 order-only actions consist of:
- 2↔3: 9
- 3↔4: 10
- 4↔5: 8

Probe first two, infer third, then re-add only positive boundary family/families.
