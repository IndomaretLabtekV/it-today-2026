# Aug 30–31 Submission Experiment Log

## V31 public decomposition period
1. `V30 + V31-newonly26` → **0.65906**.
2. `V30 + V31-overlap34` → **0.66006** = Hybrid34.
3. `Hybrid34 + 2 additional corrections` → **0.65976**.

Main evidence: tail false positives are expensive; S3 overlap is special.

## Expiring-slot public decomposition
No V38/V38.1 candidate was worth a slot because both fail-closed to exact Hybrid34.
Three slots were instead used for S3 ablation:

1. `Hybrid34 - Top1Changing3` → **0.65950**.
2. `Hybrid34 - MembershipChanging4` → **0.66006**.
3. `Hybrid34 - OrderOnly27` → **0.66020**.

This was high-information because groups are mutually exclusive and natural ranking-geometry categories.

## Current daily state
After reset, 3 fresh slots are available. Planned use: boundary-level decomposition of the 27 order-only actions.
