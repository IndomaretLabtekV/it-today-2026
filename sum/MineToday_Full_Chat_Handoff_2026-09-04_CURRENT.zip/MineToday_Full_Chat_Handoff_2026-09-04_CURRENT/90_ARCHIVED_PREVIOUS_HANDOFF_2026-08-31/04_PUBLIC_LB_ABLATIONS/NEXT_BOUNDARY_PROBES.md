# Next Boundary Probes

Starting anchor: 0.66020.

## Probe A — 2↔3 order-only
Re-add the 9 S3 order-only actions whose changed adjacent boundary is 2↔3.

Interpretation:
`C23 ≈ LB_A - 0.66020`.

## Probe B — 3↔4 order-only
Re-add the 10 S3 order-only actions whose boundary is 3↔4.

Interpretation:
`C34 ≈ LB_B - 0.66020`.

## Infer 4↔5
Since the full 27 order-only package lowered score from 0.66020 to 0.66006:
`C23 + C34 + C45 ≈ -0.00014`.

Thus:
`C45 ≈ -0.00014 - C23 - C34`.

Use rounding tolerance. If inferred value is very close to zero, do not act as though sign is certain.

## Adaptive third submission
Build one candidate that adds every clearly positive boundary group to 0.66020. Do not re-add a group with near-zero/ambiguous estimated contribution just to use the slot.

## If one group is strongly positive
Future split should use generic properties inside that boundary:
- module pair/direction;
- intent alignment;
- readiness regime;
- anchor margin band;
- foundation→advanced vs advanced→foundation.

Do not split by individual user ID.
