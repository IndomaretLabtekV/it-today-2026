# User Working Preferences — MineToday Project

- Bahasa: casual Indonesian, `gua/lu` style is preferred.
- User wants deep technical evaluation before a new notebook/architecture.
- When asking for a Kaggle notebook: make it ready to run, usually T4x2, do not show the Python used to construct the notebook, and do not run expensive training locally unless explicitly asked.
- Be direct about uncertainty; do not promise a leaderboard score.
- Preserve reproducibility and competition constraints.
- Scarce daily submissions should be treated as experiments with high information value.
- User is strongly focused on beating current leader while staying valid under TM rules.
- When an experiment fails, diagnose root cause rather than just tweak thresholds/epochs blindly.
