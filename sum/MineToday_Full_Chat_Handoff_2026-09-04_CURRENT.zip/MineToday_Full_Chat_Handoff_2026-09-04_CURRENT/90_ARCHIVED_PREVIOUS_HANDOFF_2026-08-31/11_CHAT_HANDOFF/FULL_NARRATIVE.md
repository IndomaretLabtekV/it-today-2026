# Full Narrative — Current Chat Continuity

The project began as a MineToday / IT Today 2026 recommendation competition with 4,000 labeled users, 1,000 test users, 17 course modules, chat history, assessments, and user-level NDCG@5. Early attempts were semantic-heavy and weak. The first large leap came from sparse word/char representations and per-module calibration, culminating in Consensus3 around 0.65856.

A long period of experimentation tested routers, pairwise models, semantic embeddings, Qwen, QLoRA, curriculum/prerequisite graphs, retrieval memory, and surgical corrections. The most reliable philosophy gradually became: **never replace a strong public anchor unless evidence is overwhelming; learn residuals and abstain aggressively.**

Surgical public experiments V22–V25 moved the score to 0.65919 but did not have enough scale. V29/V29.5 showed how dangerous validation mining and regime instability were. V30 then introduced a disciplined three-fresh-salt, max-min robust residual LambdaRank experiment and finally produced a genuine broad public lift to 0.65963.

V31 added strict Intent-State target encoding. Whole V31 was slightly worse at 0.65949, but its disagreement geometry was extremely informative. Of 60 V31 changes vs V30, 26 were new-only and 34 overlapped V30-changed users. Public decomposition showed new-only26 destroyed score (0.65906), whereas overlap34 lifted score to 0.66006. This created Hybrid34 and the four-state S0/S1/S2/S3 model.

From there, the project focused on trying to improve Hybrid34 without damaging its proven region. V32 changed ranking objective; V33 used retrieval residual memory; V34 used frozen BGE cross-encoder; V35/V35.1 used task-adaptive IndoBERT; V36/V36.1 used XE proposal/pressure competence; V37 fixed the validation overlap problem and built disjoint S0 crossing selection; V38 used directly fine-tuned XLM-R Base; V38.1 used a curriculum XLM-R Base architecture. None produced a robust new submission.

The most important meta-finding from V36 onward was that **oracle correction supply is often large but the selector cannot identify the good actions reliably**. XLM-R confirmed that even genuine semantic learning does not automatically solve this residual competence problem. V38.1 spent multiple hours on T4x2 and learned relevance/pair signals, but fresh-world action utility remained inconsistent.

Because no V38.1 candidate passed its gate, the remaining daily Kaggle slots were used for high-information public ablation of Hybrid34 itself. The 34 S3 actions were split naturally by ranking geometry. Removing 3 Top1 actions dropped score from 0.66006 to 0.65950, proving those specific S3 Top1 changes were highly valuable. Removing 4 membership actions left score 0.66006. Removing all 27 order-only actions improved score to 0.66020. The team returned to Top-5.

The current best rule is therefore simple and surprising: V30 + only S3 changes that alter Top1 or Top5 membership. The next three daily slots should decompose the 27 harmful order-only actions by boundary (2↔3, 3↔4, 4↔5) to see whether one positive family is hidden inside the negative aggregate. Two direct probes are enough to infer the third, then a third adaptive submission can combine only positive groups.

The competition rules require organizer-only data, maximum three submissions/day, reproducible seeded notebook, and prohibit direct LLM generation of test labels. The current rule can remain compliant if final notebook reconstructs V30/V31/S3 and categories algorithmically. Do not hardcode test user IDs or load historical submission CSVs.

The strategic mindset for the next chat should be: **evidence before complexity**. The score is 0.66020, Top4 is 0.66080, leader 0.66142. The next immediate objective is not a new neural architecture; it is extracting the remaining public-positive geometry from S3 without overfitting at individual-row level. If S3 is exhausted, only then return to tightly targeted S0 high-leverage consensus research.
