# Hashes and Lineage References

## Hybrid34
Known Top-5 signature SHA256:
`47f7db52ce8f782b8b393fd120140f1b6f51aeac452a9fabb5794cc9d8ba5e6e`

## V38 / V38.1 fail-close
Both historical primary and anchor CSV serialization had SHA256:
`c240d036ad4042cb1cee95bdc42a908f4e1a6046f3d00a2a1ac24cc3c7cf1273`
meaning they were exact Hybrid34 outputs when gates failed.

## Current 0.66020 historical artifact
File SHA256:
`d3b6f2e97b090d2fbc21b5dc862f511b004ae10f50095b5a402f33c57f4512cc`

Top-5 signature SHA256:
`c70ce570ec311e3f7391cec324e566a3a0e27da99ffc210afc3a8f102daf0191`

Use these only as regression checks. The notebook must construct outputs from organizer data rather than loading these historical files.
