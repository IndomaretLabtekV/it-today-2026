# Algorithmic Rules vs Hardcoding

## Acceptable final rule example
“Among users in S3, use the V31 correction only when the correction changes Top1 or Top5 membership; otherwise retain V30.”

Why acceptable:
- S3 is derived from V25/V30/V31 predictions;
- change category is computed from ranking geometry;
- no test label is used;
- no literal user list is necessary.

## Dangerous rule example
“If user_id in {U4043, U4274, ...}, use V31.”

Even if this recreates public score, it turns the public-ablation outcome into row-level memorization and makes reproducibility/compliance justification weak.

## Boundary decomposition rule
Similarly, probing “S3 pure-order boundary 2↔3” is a natural algorithmic category. If later adopted, final notebook should detect that category dynamically.

## Public feedback caveat
Leaderboard feedback has been used to select rule categories. Keep dimensionality low and categories semantically/ranking-geometrically natural to reduce public overfit and preserve a defensible method.
