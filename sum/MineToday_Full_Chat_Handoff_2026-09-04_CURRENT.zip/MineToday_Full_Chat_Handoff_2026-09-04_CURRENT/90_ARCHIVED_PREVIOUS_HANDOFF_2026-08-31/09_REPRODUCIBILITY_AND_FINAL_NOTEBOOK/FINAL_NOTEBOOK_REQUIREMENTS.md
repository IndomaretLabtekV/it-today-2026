# Final Notebook Requirements

A final notebook is mandatory if the team remains Top-5.

## Required conceptual pipeline
`organizer data → preprocessing → Consensus3/V25 lineage → V30 → V31 → state machine → final generic S3 policy → submission`.

## Must not
- read a prior `submission_*.csv` as model input;
- hardcode current winning user IDs;
- use external data;
- ask an LLM for test values;
- depend on hidden local caches that Kaggle cannot reproduce.

## Must include
- seed setup;
- deterministic folds/salts;
- dependency versions;
- feature and module order assertions;
- V30 geometry assertions;
- V31 change-count/state assertions;
- Hybrid34 known signature hash;
- final 0.66020-style signature hash if that remains final rule;
- generated submission shape/ID/finite checks.

## Recommended verification
Before submission deadline:
1. run from a clean Kaggle session;
2. confirm no manual files except organizer dataset and allowed open-source pretrained model weights if required;
3. compare final Top5 hash and output score geometry to historical selected submission;
4. document expected tolerance under TM (~0.001).
