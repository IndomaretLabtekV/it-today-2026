# Dataset, Task, and Metric

## Core files
- `train_relevance.csv`: 4,000 rows × (`user_id` + 17 relevance scores).
- `test.csv`: 1,000 user IDs.
- `sample_submission.csv`: 1,000 × 18.
- `chat_history.csv`: 14,573 rows.
- `user_assessments.csv`: 5,000 user rows, JSON-like 10-skill assessment.
- `modules_catalog.csv`: 17 module rows.

## ID ranges
- train: U0001–U4000;
- test: U4001–U5000;
- chat includes extra organizer users U5001–U5090.

## Metric
User-level **NDCG@5**. Only ranking geometry matters for score; absolute score calibration is secondary unless it changes ordering.

## Positive count distribution
- 4 positives/user: 1362
- 5 positives/user: 1285
- 6 positives/user: 1353

## Major implication
The task is not simple “retrieve explicitly mentioned course.” Much relevant mass is latent curriculum/career/foundation association. At the same time, deterministic prerequisite graph rules also fail because pair relationships are heterogeneous.
