# TM Rules and Competition Constraints

Authoritative source discussed in chat: `TM MINETODAY.pdf`.

## Written rules relevant to modeling

- Kaggle account/email/team must match competition registration and team merge must be correct.
- **Maximum 3 Kaggle submissions per team per day.**
- **External data is prohibited**; only organizer-provided dataset may be used.
- More than one ML model is allowed.
- Python, R, or similar programming languages are allowed.
- Cross-team collaboration is prohibited.
- Open-source pretrained models are allowed; paid pretrained models are not.
- LLM/Generative AI may **not be used to directly request predictions/values for the test dataset**.
- AI coding assistants are allowed.
- Participants must submit the notebook used to make predictions at the end of preliminaries and include randomness seeds.
- Top 5 qualify subject to submitted notebook matching output and respecting rules; stated tolerance around **0.001**.

## What this means for our pipeline

Allowed:
- TF-IDF, Ridge, LightGBM, CatBoost, IndoBERT, XLM-R, BGE, Qwen open-source pretrained encoders/rerankers, provided no external labeled data is added.
- Public leaderboard feedback to compare legal Kaggle submissions; TM text reviewed in chat does not state a ban on using leaderboard score for model/rule selection.
- Deterministic rule-level ablations of predictions generated from organizer-data pipelines.

Not allowed / must avoid:
- adding internet/external training corpora or external labels;
- asking ChatGPT/Qwen/another LLM “predict the test labels for these users” and submitting those values;
- final notebook that merely loads a prior hand-edited submission CSV rather than reproducing predictions;
- user-ID hardcoding derived from public response if the final model cannot derive the same rule algorithmically.

## Compliance status of current 0.66020 idea

Conceptually compliant **if** implemented as an algorithmic rule:
1. reconstruct V25/V30/V31 from organizer data;
2. identify S3 from model disagreement geometry;
3. classify each S3 action by whether it changes Top1, Top5 membership, or only internal order;
4. keep generic categories chosen by the final rule.

Do **not** encode a literal list of test users as the final algorithm.
