# Reproducibility Requirements

## Final artifact standard

The competition notebook should reproduce the selected submission end-to-end from organizer data. It should include:
- seeds for Python, NumPy, LightGBM/CatBoost/PyTorch as applicable;
- package/version logging;
- deterministic split salts;
- explicit feature order;
- output schema assertions;
- score/top5 signature hashes for key anchors;
- finite-value checks;
- no hidden dependency on prior result ZIPs or Kaggle submission files.

## Known reproducibility-sensitive points

1. Near-tie ranking geometry is sensitive to library versions and numeric precision.
2. V30/V31 protection actions and state geometry must be asserted.
3. `GEOMETRY_ATOL = 2.5e-4` has been used historically to guard promotion margin drift.
4. Hybrid34 known Top-5 SHA256 from deterministic reconstruction:
   `47f7db52ce8f782b8b393fd120140f1b6f51aeac452a9fabb5794cc9d8ba5e6e`.
5. The current 0.66020 historical CSV had:
   - file SHA256: `d3b6f2e97b090d2fbc21b5dc862f511b004ae10f50095b5a402f33c57f4512cc`
   - Top-5 signature SHA256: `c70ce570ec311e3f7391cec324e566a3a0e27da99ffc210afc3a8f102daf0191`
   These are verification references only; final notebook should regenerate the same geometry without loading that CSV.

## Why public decomposition is still reproducible

“Use only S3 actions that alter Top1 or membership” is a deterministic geometry rule. The rule does not require knowledge of test labels. It was selected using legal leaderboard experiments, but every action can be regenerated from organizer-data model outputs.

This is materially different from hardcoding `U_xxxx` rows because their score happened to improve public LB.
