# Module Catalog

Canonical module meanings used throughout the analysis:

| ID | Module |
|---|---|
| M001 | Excel / spreadsheet foundation |
| M002 | Python |
| M003 | SQL |
| M004 | Web Scraping |
| M005 | Version Control |
| M006 | Statistics |
| M007 | Exploratory Data Analysis |
| M008 | Dashboard / visualization |
| M009 | Machine Learning |
| M010 | Computer Vision |
| M011 | NLP |
| M012 | Generative AI |
| M013 | Prompt Engineering |
| M014 | AI Automation |
| M015 | No-code AI |
| M016 | MLOps |
| M017 | Career / Portfolio |

Historical prevalence was high for M003/M002/M006 and low for modules such as M004/M011. Sparse and calibrated models needed explicit attention so high-frequency Python/SQL did not dominate every user.
