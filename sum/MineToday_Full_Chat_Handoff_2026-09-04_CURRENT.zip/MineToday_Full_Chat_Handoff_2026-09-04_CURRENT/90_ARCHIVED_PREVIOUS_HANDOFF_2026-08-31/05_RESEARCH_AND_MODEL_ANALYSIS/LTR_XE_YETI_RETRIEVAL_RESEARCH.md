# LTR, XE, YetiRank, Retrieval Research

## LambdaRank
The strongest broad model-side public gain came from V30 Base residual LambdaRank. Its success pattern:
- strong existing anchor;
- residual rather than replacement;
- fixed alpha;
- multiple fresh worlds;
- max-min robust selection;
- sealed confirmation.

This is the single most important learned architecture pattern.

## XE-NDCG / YetiRank
V32 tested objective diversity. Neither standalone cross-objective ranker transferred robustly enough. V36/V36.1 reused XE as proposal/pressure source rather than whole ranker.

XE-specific discovery:
- actual crossing votes more meaningful than raw pressure magnitude;
- stable proposal supply contains valuable actions;
- selector cannot reliably identify them.

## Retrieval residual memory
V33 showed train-only residual neighbor retrieval does not solve the competence problem. Similar users/templates do not guarantee same residual correction.

## Co-occurrence / curriculum graph
- Cooc occasionally helped historical splits but V30 fresh incremental result was negative 0/3.
- Direct prerequisite/curriculum relationships are pair-dependent; multi-hop deterministic graph assumptions were rejected.

## Current verdict
Do not build another free global reranker. Any future model should preserve current anchor and target a narrowly justified subgroup with fresh evidence.
