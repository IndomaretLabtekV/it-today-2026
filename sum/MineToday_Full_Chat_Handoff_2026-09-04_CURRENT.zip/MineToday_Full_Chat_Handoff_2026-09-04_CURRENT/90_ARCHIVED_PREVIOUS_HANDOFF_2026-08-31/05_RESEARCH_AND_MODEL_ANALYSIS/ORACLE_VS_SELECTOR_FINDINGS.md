# Oracle Supply vs Selector Competence

This is one of the deepest findings from V36.1/V37.

## V36.1 oracle supply
Stable XE candidates had huge oracle gains in E/F/G, often orders of magnitude larger than actual selected policy. Even broad S0 candidate pools had enough theoretical headroom to close leader gap if correctly selected.

## Actual selector
Actual pressure/stability-based policies were negative or tiny. Feature correlations showed:
- `reference_margin_z`: negative correlation with true utility;
- median pressure, SNR, stability score: often negative;
- `xe_cross_votes`: positive ~0.25–0.28;
- pressure-to-margin: mildly positive.

## State-specific
- S2 cross candidates: negative 3/3 and oracle too small → exclude.
- S0 cross candidates: naive pool positive 3/3 in one audit and oracle large → potential information exists.
- Top1 XE candidate pool was strongly toxic.

## V37 confirmation
Even after fixing overlapping fresh worlds with disjoint H/I/J, low-capacity expected-utility selector failed to transfer reliably.

## Conclusion
The competition is not primarily “we cannot generate plausible alternatives.” We repeatedly **can**. The hard problem is predicting which alternative is correct for unseen test users. This is why public-proven natural subgroup rules are currently high-value.
