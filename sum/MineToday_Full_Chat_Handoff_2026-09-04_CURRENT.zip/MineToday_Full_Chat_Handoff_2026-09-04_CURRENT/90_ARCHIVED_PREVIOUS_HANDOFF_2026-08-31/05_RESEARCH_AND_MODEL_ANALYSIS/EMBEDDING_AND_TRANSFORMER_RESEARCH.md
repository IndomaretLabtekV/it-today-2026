# Embedding and Transformer Research — Consolidated Verdict

## What has been tried
- Qwen semantic models from small to 8B, frozen and QLoRA variants.
- GTE multilingual supervised stack in V2.
- BGE reranker frozen cross-encoder in V34.
- IndoBERT task-adaptive/full fine-tuning in V35/V35.1.
- XLM-R Base direct residual and curriculum training in V38/V38.1.

## Repeated finding
Embedding strength does not translate monotonically to NDCG public score. Main reasons:
1. relevance contains organizer-specific latent curriculum structure, not only text similarity;
2. only 4,000 independent labeled users, despite many generated pair/item rows;
3. high-capacity models can learn template artifacts;
4. scoring the right semantic relation does not solve the **action selection** problem after a very strong anchor.

## Correct usage pattern
If a semantic model is revisited, use it as a **narrow residual information source**, not a global replacement recommender. But it must prove fresh transferable action utility rather than just AUC.

## Current verdict
Do not prioritize another generic embedding branch now. Public rule-level decomposition is giving more actionable information per submission.
