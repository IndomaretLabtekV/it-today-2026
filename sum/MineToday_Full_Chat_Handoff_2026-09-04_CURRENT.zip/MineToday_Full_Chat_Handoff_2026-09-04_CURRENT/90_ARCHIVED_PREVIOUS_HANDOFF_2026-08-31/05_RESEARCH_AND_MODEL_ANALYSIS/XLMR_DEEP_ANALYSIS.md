# XLM-R Deep Analysis

## Base vs Large reasoning before V38
XLM-R Large is a stronger generic multilingual encoder than Base, including on Indonesian benchmarks. However Base was chosen first because:
- only 4k independent users;
- T4x2 does not pool VRAM into one giant GPU;
- Base supports honest repeated fits/bagging more practically;
- prior failures pointed to variance/transfer rather than obvious capacity shortage.

## V34 nuance
`BAAI/bge-reranker-v2-m3` is XLM-R-family (24 layers/1024 hidden) but was **frozen**. Its failure did not test task-specific XLM-R adaptation.

## V38
Used full supervised XLM-R Base as joint contextual user+A+B cross-encoder, not static cosine embedding.
Result: zero calibrated actions in K/L/M. NLL improved only weakly over random. Root cause: rare residual learning from scratch was too difficult.

## V38.1
Changed formulation instead of simply increasing model size:
- Stage A broad 17-module relevance learning;
- Stage B hard pairwise curriculum;
- Stage C frozen residual calibrators.

This improved semantic diagnostics:
- relevance AUC ~0.70–0.718;
- pair AUC ~0.568–0.612;
- two fresh worlds produced +~0.00025 order SAFE action sets.

But AA had zero actions and membership was unstable. Development gates failed.

## Why “Large + 4 epochs + threshold 0.5” was rejected
- V38 did not show a capacity-limited pattern; it showed poor calibrated tail supply.
- More epochs would likely overfit some worlds; M already worsened epoch1→2.
- A hard 0.5 probability threshold would be arbitrary and post-hoc after seeing zero-action result.
- Larger model increases runtime/variance and makes honest replication harder.

## Current verdict
Do **not** spend scarce Kaggle slots on XLM-R Large now. Large only becomes justified if a Base formulation already shows stable 3/3 residual utility but appears slightly capacity-limited. V38.1 did not reach that state.
