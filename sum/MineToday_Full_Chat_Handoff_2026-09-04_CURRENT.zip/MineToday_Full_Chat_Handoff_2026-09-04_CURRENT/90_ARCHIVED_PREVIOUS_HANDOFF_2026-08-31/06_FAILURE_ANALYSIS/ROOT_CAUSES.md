# Root Cause Synthesis — Current

## 1. Strong anchor leaves only hard residual errors
By V30/Hybrid34/current 0.66020, easy lexical/assessment/calibration signal is already captured. Remaining mistakes are subtle and noisy.

## 2. Only 4,000 independent labeled users
Generating 68k user-module rows or 100k pairs does not create 100k independent users. Complex selectors and deep models overfit template/user regimes easily.

## 3. NDCG action errors are asymmetric and expensive
A few wrong Top1/membership actions can wipe out many small internal-order wins.

## 4. Selector competence is the bottleneck
V36/V36.1/V37 showed large oracle headroom but inability to select beneficial actions. V38/V38.1 showed semantic models can learn moderate broad relevance yet still cannot consistently select residual corrections.

## 5. Validation mining has repeatedly misled us
Problems seen:
- reused folds/LOCK surfaces;
- second-level non-nested leakage;
- OOF/full-fit geometry mismatch;
- overlapping “fresh” cohorts;
- post-hoc threshold temptation;
- transductive TAPT isolation concern.

Every strong-looking local result must be discounted unless it survives fresh truly independent confirmation.

## 6. Replacement models erase public-proven structure
Consensus3/V25/V30/current anchor contains many complementary sparse/calibration signals. Rebuilding 17 rankings globally with a new model usually loses more than it gains.

## 7. Semantic strength is not the missing single variable
Bigger embeddings, QLoRA, BGE, IndoBERT, XLM-R all failed to produce a reliable leader-scale residual policy.

## 8. Natural disagreement geometry can be more informative
V31 whole model was worse than V30, yet its overlap34 disagreement region was highly beneficial. This is the strongest evidence that **where models disagree** matters more than which model has globally higher score.

## 9. Coverage is not the target
V28 broad coverage hurt. Current best comes from retaining only 7 S3 actions. Precision beats action count.

## 10. Current public gap remains nontrivial
0.00122 to leader is much larger than typical safe model incremental gains. Be realistic: likely requires one or more high-leverage subgroups, not a tiny calibration tweak.
