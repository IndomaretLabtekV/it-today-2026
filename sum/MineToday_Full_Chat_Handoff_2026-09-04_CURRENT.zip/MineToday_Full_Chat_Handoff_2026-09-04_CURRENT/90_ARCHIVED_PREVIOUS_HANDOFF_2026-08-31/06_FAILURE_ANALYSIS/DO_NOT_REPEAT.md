# Do Not Repeat

1. Do not rebuild current 0.66020 ranking globally without extraordinary evidence.
2. Do not tune V30 alpha from public leaderboard response.
3. Do not resurrect S1; public test showed it is strongly harmful.
4. Do not assume S2 is promising; XE audit showed poor direction and weak oracle.
5. Do not use generic uncertainty/stability router unless a new metric proves correlation on fresh data.
6. Do not make XLM-R Large the default next step.
7. Do not lower neural thresholds post-hoc because current policy abstained.
8. Do not reuse burned validation worlds as if they were fresh.
9. Do not hardcode individual test user IDs in the final notebook.
10. Do not use previous submission CSV as input to final prediction notebook.
11. Do not infer hidden test labels with LLM/GenAI.
12. Do not add external datasets/corpora.
13. Do not treat displayed leaderboard decimals as infinite-precision additive ground truth.
14. Do not spend a scarce slot on a candidate identical to current anchor.
15. Do not spend multi-hour GPU runtime unless the experiment changes the information source/learning problem materially.
