# What Failed / Was Inefficient

- Large semantic model as global recommender.
- Generic embedding cosine / frozen semantic reranking as sole decision source.
- Broad foldbag/averaging that changes score geometry.
- High-dimensional second-level routers on only 4k users.
- Reusing validation surfaces after looking at them.
- Generic uncertainty/stability as action correctness proxy.
- Multi-hop prerequisite/curriculum graph as deterministic rule.
- Co-occurrence as core signal.
- Retrieval-neighbor residual memorization.
- Whole XE/Yeti objective replacement.
- Exact XE proposal identity consensus.
- Pressure magnitude/stability score as competence metric.
- S2 correction corridor.
- Direct rare-residual XLM-R training.
- Curriculum XLM-R membership specialist: unstable across fresh worlds.
- Arbitrary confidence threshold lowering after a zero-action run.
- Assuming all Top1 changes are dangerous. Public S3 ablation disproved this in the specific S3 context.

Also inefficient operationally:
- V38.1 required many hours on T4x2 and still failed the development gate. Future deep runs need a high expected information value before spending runtime.
