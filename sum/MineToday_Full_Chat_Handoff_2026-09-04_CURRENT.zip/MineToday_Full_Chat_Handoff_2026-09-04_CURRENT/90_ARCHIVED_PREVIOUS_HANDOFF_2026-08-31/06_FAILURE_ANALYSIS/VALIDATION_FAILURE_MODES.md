# Validation Failure Modes and Corrections

## Historical failures

### V13.1
Second-level non-nested leakage / OOF-full geometry mismatch. Local router looked better than public.

### V29/V29.5
One split/regime looked strong while another fresh regime reversed sign. Generic stability failed to predict correctness.

### V35
TAPT initially saw all organizer train chat, including validation text. V35.1 fixed fold-pure isolation.

### V36.1
Fresh E/F/G were generated with independent StratifiedShuffleSplit and overlapped users:
- E∩F ~39
- E∩G ~42
- F∩G ~37
- triple overlap ~5
Therefore not truly independent confirmations.

### V37 onward
Moved to truly disjoint 400-user worlds.

## Current best practice
- architecture fixed before fresh-world labels;
- three disjoint deployment-like cohorts;
- all action-training predictions OOF/fold-pure;
- template-disjoint sealed split only after dev pass;
- chronology rejection-only;
- fail-close anchor if gate fails;
- do not reopen/retune after failed fresh gate.

## Public LB probing discipline
Natural low-dimensional rule-level ablations are acceptable research tools but should not evolve into individual-test-row label inference. Preserve generic reproducible rules.
