# Validation World / Salt Burn Ledger

Approx chronological use:
- C/D/E: V30 fresh development — burned.
- F: V30 sealed — opened/burned.
- G/H/I: V31 development — burned.
- J: historical sealed lineage; later used/retained in branches, treat as burned once opened in relevant experiments.
- K/L/M: V32 and later V38 direct XLM-R — burned.
- N/O/P: V33 retrieval — burned.
- Q/R/S: V34 BGE head12 — burned.
- T: sealed Head12/IndoBERT lineage, eventually confirmation context — treat burned.
- U/V/W: V35 IndoBERT development — burned.
- X: V35.1 confirmation — burned.
- E/F/G names reused in V36.1 with new salts but development labels seen — burned for that architecture.
- H/I/J names reused in V37 with new deterministic disjoint cohorts — labels seen — burned.
- AA/AB/AC: V38.1 curriculum-XLM-R development — burned.

Important: names alone do not uniquely identify a split; actual seed string matters. For any future architecture, create genuinely new deterministic salt strings and preregister before reading outcomes.
