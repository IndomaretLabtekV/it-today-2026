# Historical File Reference Map

Files discussed/used during this chat, **not included in this handoff ZIP**:

- `TM MINETODAY.pdf` — official rule source.
- `mine-today-data-mining-competition-it-today-2026.zip` — organizer dataset.
- `MineToday_V31_IntentState_Residual_LTR.ipynb`.
- `MineToday_V32_CrossObjective_Residual_Consensus.ipynb`.
- `MineToday_V33_V30Locked_Retrieval_Residual_Actions.ipynb`.
- `MineToday_V34_V30Locked_RiskControlled_Head12_CrossEncoder.ipynb`.
- `MineToday_V35_V30Locked_TaskAdaptive_IndoBERT_Pairwise_Utility_Reranker.ipynb`.
- `MineToday_V35_1_FoldPure_Confirmatory_IndoBERT_ATTACK_FIXED.ipynb`.
- `MineToday_V36_Hybrid34Locked_XE_Proposal_Competence_Router.ipynb`.
- `MineToday_V36_1_Hybrid34Locked_XE_Residual_Pressure_Stability.ipynb`.
- `MineToday_V37_Hybrid34Locked_S0_XE_Crossing_ExpectedUtility_Router.ipynb`.
- `MineToday_V38_Hybrid34Locked_XLMR_Pairwise_Residual_Judge_FIXED.ipynb`.
- `MineToday_V38_1_Hybrid34Locked_Curriculum_XLMR_Semantic_Membership_Pairwise_Judge.ipynb`.
- `results-v32.zip` through `results-v38_1.zip`.
- Historical handoff ZIPs dated Aug 23, 24, 26, 27, 28.

This new handoff intentionally contains **descriptions only**, per user request.
