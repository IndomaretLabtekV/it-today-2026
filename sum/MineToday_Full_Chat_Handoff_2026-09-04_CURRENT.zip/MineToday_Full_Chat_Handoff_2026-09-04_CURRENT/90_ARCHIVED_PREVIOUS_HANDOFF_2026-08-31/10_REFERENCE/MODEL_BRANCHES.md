# Model Branch Summary

## Sparse/calibration
Most successful foundational family. Keep.

## LightGBM LambdaRank residual
V30 major success. Keep as core lineage.

## CatBoost YetiRank / XE-NDCG
Useful diversity/proposal diagnostics, not robust whole-model winners.

## Retrieval residual
Closed.

## Qwen / large semantic embedding
Explored extensively; no broad public breakthrough. Closed as default direction.

## BGE frozen cross-encoder
No safe tail. Closed.

## IndoBERT
Task fine-tuning learned signal but confirmation/coverage insufficient. Closed unless new formulation.

## XLM-R Base
Direct residual failed; curriculum learned semantics but residual transfer inconsistent. Large not justified currently.

## Public disagreement-rule branch
Currently strongest incremental direction; produced Hybrid34 and current 0.66020.
