# Source Evidence Note

Key source material used to build this handoff:
- official `TM MINETODAY.pdf` for rules;
- organizer dataset statistics previously audited in chat;
- executed results summaries from V38 and V38.1;
- V31/V33/V34/V35/V35.1/V36/V36.1/V37/V38/V38.1 notebook contracts inspected during the chat;
- public Kaggle scores reported by the user;
- previous full V31-ready handoff dated 28 Aug 2026, archived inside this ZIP.

This package is explanatory only. It intentionally excludes the actual notebooks/result bundles/submission CSVs.
