# State Machine and Glossary

- **Consensus3:** V12.2 long-lived calibrated anchor.
- **V25:** Consensus3 + public-proven surgical package before V30.
- **V30:** residual LambdaRank Base, public 0.65963.
- **V31:** same main architecture plus Intent-State TE, public 0.65949.
- **S0:** V30 stable and V31 stable.
- **S1:** V30 stable, V31 changes; public-toxic.
- **S2:** V30 changed prior anchor, V31 does not further change; poor XE correction region.
- **S3:** V30 changed prior anchor and V31 changes V30; public-positive overlap region.
- **Hybrid34:** V30 everywhere except S3 uses V31.
- **Order-only action:** changes order within existing Top5 without changing Top1 or membership.
- **Membership action:** changes which module is inside Top5, usually boundary 5↔6.
- **Top1 action:** changes module at rank1.
- **Fail-close:** if experimental gate fails, output exact proven anchor rather than forcing changes.
- **Fresh world:** validation cohort not previously used to make architecture/policy decisions.
- **Sealed:** untouched rejection-only split opened after development policy is frozen.
- **Oracle supply:** theoretical gain if one magically selected only beneficial candidates; diagnostic only.
- **Competence selector:** model/rule that decides which proposed actions are likely beneficial.
