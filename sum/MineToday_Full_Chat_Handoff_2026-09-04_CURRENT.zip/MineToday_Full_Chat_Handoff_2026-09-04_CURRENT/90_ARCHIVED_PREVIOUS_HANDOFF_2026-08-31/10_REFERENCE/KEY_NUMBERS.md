# Key Numbers

## Leaderboard
- current best: **0.66020**
- Top4: **0.66080**
- leader: **0.66142**
- gap current→Top4: **0.00060**
- gap current→leader: **0.00122**

## Dataset
- 4,000 train users
- 1,000 test users
- 17 modules
- 14,573 chat rows
- 4,940 chat users
- 251 invalid assessment cells
- 117 train no-chat
- 33 test no-chat

## V30/V31 state
- V30 changed 77 users vs V25
- V31 changed 60 vs V30
- S0 897
- S1 26
- S2 43
- S3 34

## S3 categories
- Top1: 3
- membership: 4
- order-only: 27
- order 2↔3: 9
- order 3↔4: 10
- order 4↔5: 8

## Public S3 effects approx
- Top1: +0.00056
- Membership: ~0
- Order-only: -0.00014

## V38.1 diagnostics
- relevance AUC ~0.701–0.718
- pair AUC ~0.568–0.612
- AB SAFE +0.000248, 9 actions, precision ~0.714
- AC SAFE +0.000251, 8 actions, precision ~0.714
- AA SAFE 0 actions
- AB membership -0.000340
- SAFE dev mean +0.000166, worst 0 → gate fail
