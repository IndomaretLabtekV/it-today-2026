# One-Page Cheatsheet

## Task
- Recommendation / learning-path ranking.
- Train: 4,000 users; test: 1,000 users.
- 17 modules.
- Inputs: chat history, 10-skill assessment, module catalog/prerequisite information.
- Output: 17 scores/user.
- Metric: user-level **NDCG@5**.
- Each train user has exactly 4/5/6 positive modules.

## Dataset numbers
- `chat_history`: 14,573 rows, 4,940 unique users, termasuk 90 extra unlabeled U5001–U5090.
- `user_assessments`: 5,000 users, 10 questions/skills.
- 251 invalid normalized assessment cells.
- 117 train users tanpa chat; 33 test users tanpa chat.
- Train U0001–U4000, test U4001–U5000.
- Target count: 4 positives = 1362 users, 5 = 1285, 6 = 1353.
- Train/test broad adversarial AUC sekitar 0.51–0.53: tidak ada broad shift besar.

## Target geometry
Approx relevance bands:
1. rank1 = 1.00
2. rank2 = 0.80–0.90
3. rank3 = 0.65–0.75
4. rank4 = 0.50–0.60
5. rank5 = 0.35–0.45
6. rank6 = 0.20–0.30

NDCG@5 membuat Top-1 dan Top-5 membership sangat high leverage.

## Public lineage yang benar-benar terbukti
`V3.1 sparse → calibrated binary relevance → V12.2 Consensus3 → V22.3 surgical → V25 → V30 residual LambdaRank → V31 overlap decomposition → Hybrid34 → S3 subgroup ablation → current 0.66020`.

## Key public scores
- V1 0.63629
- V2 0.64413
- V3.1 0.65036
- cal045 0.65639
- V12.2 0.65856
- V21.1 0.65869
- V22.3 0.65912
- V25 0.65919
- V30 0.65963
- V31 0.65949
- V31-newonly26 0.65906
- Hybrid34 / overlap34 0.66006
- Hybrid34 + 2 extra corrections 0.65976
- current S3 Top1+Membership7 0.66020
- Top-4 0.66080
- leader 0.66142

## Hybrid34 state machine
From V25 → V30 → V31:
- S0: V30 stable, V31 stable = 897 test users.
- S1: V30 stable, V31 changes = 26, **public toxic**.
- S2: V30 changed V25, V31 abstained = 43.
- S3: V30 changed V25 and V31 changes V30 = 34, **public-positive as a package**.

Deterministic Hybrid34 rule:
`use V31 only if (V30 != V25) AND (V31 != V30); otherwise use V30`.

Current best refines S3 further:
`within S3, keep only Top1-changing or Top5-membership-changing changes; reject pure order-only changes`.

## Biggest lessons
- Better embeddings / bigger LLM ≠ better leaderboard.
- Global replacement rankers almost always lose to strong anchor.
- Residual modeling is more successful than rebuilding rankings.
- Oracle supply often exists; **selector competence** is the recurring bottleneck.
- Generic uncertainty/stability scores do not predict action correctness reliably.
- Lower boundaries are hard to learn; historical adjacent AUC falls from ~.668 at 1/2 to ~.521 at 5/6.
- Yet 5↔6 has huge NDCG leverage because membership changes.
- Validation mining/reused splits easily creates fake improvements.
- Fresh disjoint worlds + sealed rejection are necessary.
- Public decomposition at natural rule level has recently been more informative than another complex model.

## Current move
Use 3 available daily slots for boundary-level decomposition of the 27 harmful order-only S3 actions, not for XLM-R Large or another broad model yet.
