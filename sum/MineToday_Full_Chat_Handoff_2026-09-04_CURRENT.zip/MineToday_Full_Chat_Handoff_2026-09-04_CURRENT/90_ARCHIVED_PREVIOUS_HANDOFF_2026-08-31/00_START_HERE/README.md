# MineToday / IT Today 2026 — Full Chat Handoff

**Snapshot:** 31 Aug 2026, setelah public best baru `0.66020` dan leaderboard kembali Top-5.

Archive ini dibuat supaya chat/agent berikutnya bisa meneruskan kompetisi tanpa mengulang investigasi dari nol. Isinya sengaja **tidak menyertakan notebook, result ZIP, CSV hasil eksperimen, atau model weights**. Semua artifact tersebut hanya dijelaskan, bersama evidence, score, failure mode, dan keputusan yang sudah diambil.

## Cara membaca tercepat

1. `CURRENT_STATUS.md` — posisi sekarang.
2. `ONE_PAGE_CHEATSHEET.md` — seluruh inti proyek dalam satu halaman.
3. `CURRENT_TASK_QUEUE.md` — apa yang harus dilakukan selanjutnya.
4. `03_EXPERIMENT_HISTORY/MASTER_TIMELINE_V1_V38_1.md` — sejarah eksperimen lengkap.
5. `04_PUBLIC_LB_ABLATIONS/HYBRID34_DECOMPOSITION.md` — breakthrough terbaru yang membawa 0.66020.
6. `06_FAILURE_ANALYSIS/ROOT_CAUSES.md` — kenapa banyak eksperimen offline bagus tetapi public gagal.
7. `08_CURRENT_STATE_AND_NEXT_STEPS/NEXT_3_SUBMISSION_PLAN.md` — rencana tiga slot yang tersedia sekarang.
8. `09_REPRODUCIBILITY_AND_FINAL_NOTEBOOK/FINAL_NOTEBOOK_REQUIREMENTS.md` — agar kandidat akhir sesuai TM.
9. `11_CHAT_HANDOFF/READY_TO_PASTE_NEXT_CHAT.txt` — prompt ringkas namun cukup lengkap untuk memulai chat baru.

## Trust / provenance

Dokumen ini menggabungkan:
- fakta dataset dan eksperimen yang telah dianalisis sepanjang chat;
- public leaderboard scores yang dilaporkan user;
- hasil executed notebooks/result bundles yang telah diaudit;
- aturan dari `TM MINETODAY.pdf`;
- handoff historis sampai V31 yang dibuat pada 28 Aug 2026, disalin lengkap di `99_ARCHIVED_PREVIOUS_HANDOFF_V31/` supaya detail lama tidak hilang.

Jika ada konflik antara dokumen terbaru dan archive lama, **dokumen terbaru di root ini yang authoritative**.
