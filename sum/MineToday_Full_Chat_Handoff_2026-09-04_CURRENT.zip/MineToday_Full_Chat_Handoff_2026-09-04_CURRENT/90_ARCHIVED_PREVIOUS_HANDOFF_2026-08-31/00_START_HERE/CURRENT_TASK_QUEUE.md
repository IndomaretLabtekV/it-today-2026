# Current Task Queue

## P0 — Immediate three-slot public decomposition

Current anchor = `0.66020` = V30 + S3 Top1-changing + Membership-changing actions only.

### Slot 1
Add back only **S3 order-only boundary 2↔3**, 9 actions.

Measure:
`C23 ≈ score_slot1 - 0.66020`.

### Slot 2
Add back only **S3 order-only boundary 3↔4**, 10 actions.

Measure:
`C34 ≈ score_slot2 - 0.66020`.

### Infer 4↔5
Total order-only package is approximately:
`C23 + C34 + C45 ≈ 0.66006 - 0.66020 = -0.00014`.

Thus:
`C45 ≈ -0.00014 - C23 - C34`.

Because public score is rounded, treat inference with a small tolerance; do not pretend micro precision is exact.

### Slot 3
Construct current anchor + **all boundary groups whose estimated contribution is positive**. If both measured groups are negative and inferred C45 is negative, preserve 0.66020 and use the third slot for the next natural rule-level decomposition rather than duplicate submission.

## P1 — After boundary experiment

If a boundary group is strongly positive:
- split by generic rule such as module transition family, direction, intent alignment, readiness, or margin band;
- avoid user-ID-specific probing;
- keep the rule reconstructible from organizer data.

If all order boundary groups are weak/negative:
- declare S3 internal ordering exhausted;
- investigate the 4 membership actions as a natural subgroup using module/direction/intent rule, not one-user-per-slot;
- only after that consider returning to S0 model-based corrections.

## P2 — Final reproducibility notebook

Before final notebook submission:
- build V25/Consensus3 lineage from organizer data;
- reconstruct V30 deterministically;
- reconstruct V31 deterministically;
- derive S0/S1/S2/S3 algorithmically;
- apply final generic S3 geometry rule;
- no loading prior public submission CSV as input;
- fixed seeds, package versions, hashes/assertions;
- verify output is within TM tolerance of selected Kaggle submission.
