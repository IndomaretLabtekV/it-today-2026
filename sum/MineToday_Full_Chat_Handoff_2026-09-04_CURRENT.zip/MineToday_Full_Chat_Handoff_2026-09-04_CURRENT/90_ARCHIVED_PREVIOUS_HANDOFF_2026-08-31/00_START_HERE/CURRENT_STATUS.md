# Current Status — 31 Aug 2026

## Leaderboard

- **Current best / current champion:** `0.66020`
- **Top-4 visible:** `0.66080`
- **Top-1 visible:** `0.66142`
- Gap ke Top-4: `+0.00060`
- Gap ke Top-1: `+0.00122`
- Posisi user kembali **Top-5**.
- Daily submission sudah reset lagi: **3 slot tersedia**.

## Apa sebenarnya kandidat 0.66020?

Kandidat ini berasal dari **Hybrid34 0.66006** tetapi **27 perubahan S3 yang hanya mengubah internal ordering dibuang**. Yang dipertahankan dari 34 S3 actions hanya:

- 3 actions yang mengubah Top-1;
- 4 actions yang mengubah Top-5 membership.

Secara konseptual current champion adalah:

`V30 + S3(top1-changing + membership-changing only)`

atau setara:

`Hybrid34 - S3 order-only 27`.

File historical yang menghasilkan score tersebut saat eksperimen bernama `slot3_adaptive_hybrid34_minus_order27.csv`; jangan jadikan file CSV itu dependency final notebook. Final notebook harus merekonstruksi rule secara algorithmic dari organizer data.

## Public evidence terbaru

Tiga ablation kemarin:

| Submission | Public | Interpretation |
|---|---:|---|
| Hybrid34 baseline | 0.66006 | 34 S3 changes |
| Hybrid34 minus 3 Top-1 actions | **0.65950** | 3 Top-1 actions collectively sangat positif, sekitar +0.00056 |
| Hybrid34 minus 4 membership actions | **0.66006** | 4 membership actions collectively ~netral pada displayed precision |
| Hybrid34 minus 27 order-only actions | **0.66020** | 27 order-only actions collectively harmful sekitar -0.00014 |

Important: leaderboard ditampilkan dengan finite decimal precision, jadi algebra kontribusi adalah approximate, bukan ground-truth exact beyond displayed precision.

## Current pending task

Sebelum handoff ini dibuat, rencana berikutnya telah dikunci:

1. Probe **S3 order-only boundary 2↔3**, 9 actions, dengan menambahkannya kembali ke current 0.66020 anchor.
2. Probe **boundary 3↔4**, 10 actions.
3. Infer kontribusi **boundary 4↔5**, 8 actions, dari total order-only contribution dan dua probe pertama.
4. Slot ketiga hari ini dibuat adaptif: pertahankan current anchor + hanya boundary group yang public contribution-nya positif.

Jangan buat model baru sebelum dua probe boundary pertama selesai kecuali ada alasan baru yang kuat. Information value dari public decomposition sekarang lebih tinggi daripada another large model branch.
