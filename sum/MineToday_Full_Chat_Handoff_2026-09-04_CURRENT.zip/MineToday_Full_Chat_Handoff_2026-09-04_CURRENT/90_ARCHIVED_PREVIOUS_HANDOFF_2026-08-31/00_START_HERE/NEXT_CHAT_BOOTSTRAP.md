# Next Chat Bootstrap

Tell the next assistant to start with these facts:

- Competition: MineToday Data Mining Competition — IT Today 2026.
- Metric: user-level NDCG@5; 4k train, 1k test, 17 modules.
- Current public best: **0.66020**, currently Top-5.
- Visible Top-4: **0.66080**; leader: **0.66142**.
- 3 daily slots available after reset.
- Current best is **not a new model**: it is deterministic Hybrid34 decomposition, keeping only S3 Top1-changing + membership-changing changes and rejecting 27 order-only S3 changes.
- Public ablation proved: Top1 group ≈ +0.00056; membership group ≈ 0; order-only group ≈ -0.00014.
- Next exact plan: probe order-only boundaries 2↔3 (9), 3↔4 (10), infer 4↔5 (8), then combine only positive groups.
- Never hardcode test user IDs in final logic. Natural rule-level grouping must be reconstructed from V25/V30/V31 geometry.
- Do not immediately return to XLM-R Large. V38 and V38.1 showed semantic learning signal but failed transferable promotion gates.

Then read `11_CHAT_HANDOFF/READY_TO_PASTE_NEXT_CHAT.txt` for a detailed paste-ready context.
