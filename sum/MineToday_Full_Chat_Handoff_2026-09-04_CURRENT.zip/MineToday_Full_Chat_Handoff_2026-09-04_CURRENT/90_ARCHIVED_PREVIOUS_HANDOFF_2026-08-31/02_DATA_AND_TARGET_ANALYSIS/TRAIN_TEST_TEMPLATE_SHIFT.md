# Train/Test Template and Shift Findings

- Template overlap is high, so deployment is not a cold-domain problem.
- Exact-template memorization is nevertheless unsafe because templates are not label-deterministic.
- Template-group-disjoint validation is useful as a catastrophic-harm stress test, but pure group-disjoint splits can be harsher than actual test deployment.
- Best validation practice evolved toward:
  1. fresh deployment-like user worlds for selection;
  2. template-disjoint sealed split only after policy freeze;
  3. chronology as rejection-only stress test.
- Reusing fresh worlds after architecture decisions are influenced by them burns those worlds. Maintain a salt ledger.
