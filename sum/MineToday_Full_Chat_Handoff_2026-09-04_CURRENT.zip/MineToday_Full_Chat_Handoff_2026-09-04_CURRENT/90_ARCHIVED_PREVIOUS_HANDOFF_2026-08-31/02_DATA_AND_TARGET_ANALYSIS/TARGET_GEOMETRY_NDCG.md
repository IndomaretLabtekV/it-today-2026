# Target Geometry and NDCG Economics

## Graded relevance structure
Each user has exactly one score 1.0 and then lower ordinal bands. Approx:
- #1 1.00
- #2 0.80–0.90
- #3 0.65–0.75
- #4 0.50–0.60
- #5 0.35–0.45
- #6 0.20–0.30

## Adjacent pair learnability from V14
Historical fully nested pairwise AUC:
- rank1 vs rank2: ~0.668
- rank2 vs rank3: ~0.614
- rank3 vs rank4: ~0.563
- rank4 vs rank5: ~0.530
- rank5 vs rank6: ~0.521

So lower internal ordering becomes close to random to predict.

## NDCG leverage
V38 calibration economics made the asymmetry explicit. Approx single-correction magnitude by boundary:
- 2↔3: gain/harm ~0.032–0.036 user-NDCG
- 3↔4: ~0.017–0.020
- 4↔5: ~0.010–0.012
- 5↔6 membership: ~0.095–0.106

Thus 5↔6 is hard to predict but extremely high leverage because it changes membership. Top1 is also highly leveraged.

## Practical lesson
Optimize **action precision × leverage**, not action count. A few correct high-leverage actions can beat dozens of uncertain order corrections.
