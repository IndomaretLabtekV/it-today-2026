# Dataset Findings

## Assessment quality
There are exactly **251 invalid normalized cells** among 50,000 assessment cells. Historical counts found:
- 66 values `99`
- 66 values `12`
- 61 values `-1`
- 58 values `-3`

Robust pipelines clean these and preserve invalid flags instead of silently treating them as valid skills.

## Chat availability
- 117 train users have no chat.
- 33 test users have no chat.

## Chat duplication/template structure
Chat is strongly template-heavy. Many normalized test messages have exact/near train matches:
- exact normalized test chat overlap roughly 69.9%;
- about 95.8% of test users with chat have at least one exact train message match.

But exact-template target lookup was not reliable enough because the same conversational template can map to different relevance lists.

## Intent/state structure
Latest-intent categories cover train/test similarly. Around 45–46 intent signatures depending normalization, and test signatures were seen in train. Skeleton/template matching also has high seen coverage.

## Distribution shift
Multiple adversarial train-vs-test experiments were near chance:
- broad assessment/chat AUC ~0.5075;
- TF-IDF ~0.5267;
- combined ~0.5241.

Therefore large domain-adaptation schemes were not justified by broad shift evidence.
