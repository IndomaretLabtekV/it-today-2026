# V32–V38.1 Detailed Findings

## V32 — objective diversity
- XE_NDCG, YetiRank, objective median, unanimous Top6.
- Candidate whole rankers were inconsistent across fresh K/L/M.
- One XE world positive but others negative/near zero; Yeti negative.
- Consensus action supply existed but not robust enough.
- Lesson: changing objective alone does not fix transfer.

## V33 — retrieval residual memory
- V30 immutable.
- Train-only local retrieval memory and adjacent corrections.
- Fresh N/O/P.
- Broad N/O/P roughly mixed: one negative, one positive, one flat.
- Protected path almost flat.
- 22 proposed test interventions over-concentrated in M003/M002 type transitions.
- Lesson: nearest residual memory does not provide reliable action utility.

## V34 — frozen BGE/XLM-R-family cross-encoder
- Head12 only.
- BGE standalone benefit AUC roughly ~0.56–0.58; combined action model ~0.65ish but no safe tail.
- 0 actions survived.
- Lesson: generic frozen cross-encoder confidence is not enough.

## V35/V35.1 — IndoBERT
- Full fine-tuning gave a measurable AUC increment over frozen.
- Development ATTACK small positive with only 10 selected actions across U/V/W.
- Fold-pure confirmation was required because initial TAPT had transductive exposure to all train chat.
- Confirmation did not support a robust new submission.
- Lesson: supervised language-model adaptation can learn something, but scarce action count and split instability remain.

## V36 — competence router
- XE proposals and a low-capacity benefit/harm/utility router.
- Policy search unable to find eligible robust thresholds.
- 0 deployment actions.

## V36.1 — pressure stability
- Replaced unstable exact proposal identity with continuous pressure across 4 XE shadows.
- Actual policy was negative; **oracle stable-action supply huge**.
- Strong root-cause finding: candidate generation is not the main problem; selector cannot distinguish beneficial vs harmful actions.
- `xe_cross_votes` was positively correlated with utility; raw pressure/stability scores often anti-correlated.
- S0 had useful oracle headroom; S2 did not.
- E/F/G overlap invalidated independence assumption.

## V37
- Fixed disjoint H/I/J.
- S0-only, rank1 lock, cross>=2, pressure>=3, low-capacity EU selector.
- Still failed. This strengthened selector-bottleneck diagnosis.

## V38
- Direct XLM-R Base rare residual training.
- Weak NLL improvement, zero calibrated actions in K/L/M.
- Threshold `inf` because no calibration tail met utility/precision requirements.
- Not a public failure: the candidate never changed Hybrid34.

## V38.1
- Curriculum reformulation succeeded at learning broad semantics better than V38.
- Stage A relevance AUC ~0.70–0.718.
- Stage B pair AUC ~0.568–0.612.
- AB/AC order SAFE ~+0.00025 each, but AA zero and membership unstable.
- Development robustness gate failed, so no test interventions generated.
- Lesson: Base capacity was not obviously the bottleneck; transfer consistency remains the issue.
