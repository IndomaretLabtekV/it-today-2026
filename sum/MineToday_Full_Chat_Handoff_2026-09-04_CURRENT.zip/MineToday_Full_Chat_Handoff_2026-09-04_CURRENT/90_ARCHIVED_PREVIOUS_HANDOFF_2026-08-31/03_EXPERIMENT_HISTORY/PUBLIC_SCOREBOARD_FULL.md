# Public Scoreboard — Full Canonical Snapshot

| Version / candidate | Public NDCG@5 | Verdict |
|---|---:|---|
| V1 | 0.63629 | semantic-heavy baseline |
| V2 | 0.64413 | multilingual semantic improved but insufficient |
| V3.1 sparse | 0.65036 | sparse breakthrough |
| cal035 | 0.65540 | calibration works |
| Borda | 0.65489 | weaker than calibrated probabilities |
| cal045 | 0.65639 | strong calibration |
| V8 repeated | 0.65577 | averaging can hurt |
| V8 foldbag | 0.65140 | geometry dilution |
| V9.1 | ~0.65432 | local residual did not transfer |
| V12 Leader6 | 0.65792 | module-specific correction |
| V12.2 Consensus3 | 0.65856 | durable anchor |
| V13.1 | 0.65754 | router failure |
| V18 | 0.65829 | semantic near anchor but below |
| V19 | 0.65791 | semantic decline |
| V21 | 0.65786 | QLoRA/anchor mismatch |
| V21.1 | 0.65869 | small stable-module win |
| V21.2 | 0.65776 | semantic LTR fails |
| V22.1 | 0.65846 | bulk actions negative |
| V22.2 | 0.65878 | four-action candidate |
| V22.3 | 0.65912 | surgical pair winner |
| V24 | 0.65912 | displayed flat |
| V25 | 0.65919 | core surgical package |
| V26 | 0.65919 | prune displayed flat |
| V30 | **0.65963** | robust residual LambdaRank breakthrough |
| V31 whole | **0.65949** | weak incremental intent-state |
| V30 + V31 new-only26 | **0.65906** | toxic region |
| Hybrid34 / overlap34 | **0.66006** | public-proven disagreement package |
| Hybrid34 + 2 extra | **0.65976** | false-positive tail costly |
| Hybrid34 minus Top1-3 | **0.65950** | proves Top1 S3 group strongly valuable |
| Hybrid34 minus Membership-4 | **0.66006** | membership package net-neutral displayed |
| **Hybrid34 minus OrderOnly-27** | **0.66020** | **current best** |

Visible leaderboard as of current snapshot:
- user: **0.66020**, Top-5
- Top-4: **0.66080**
- leader: **0.66142**

All micro contribution algebra should account for displayed-score rounding.
