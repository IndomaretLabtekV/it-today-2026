# Master Timeline — V1 through V38.1

This file gives the main experiment lineage. For older fine detail through V31, see `99_ARCHIVED_PREVIOUS_HANDOFF_V31/`.

## V1–V2: semantic-heavy beginning

### V1 — Public 0.63629
Hybrid semantic/Qwen-style embedding, reranking, TF-IDF, template memory, early LTR. Too many moving parts; anchor and calibration immature.

### V2 — Public 0.64413
Supervised multilingual semantic stack including `Alibaba-NLP/gte-multilingual-base`. Improvement over V1 but still far behind later sparse/calibrated family. Early evidence that larger semantic representation was not the main bottleneck.

## V3–V7: sparse/calibration breakthrough

### V3
Cross-encoder training attempt hit FP16 gradient-unscale failure; did not become winner.

### V3.1 — 0.65036
Word+char TF-IDF, typo robustness, trajectory tags, template tokens, assessment features/invalid flags, sparse multi-output Ridge. Became durable backbone.

### Calibration family
- cal035 0.65540
- Borda 0.65489
- cal045 0.65639

Per-module binary relevance calibration was a large win; pure rank fusion was weaker.

## V8–V12.2: module calibration and stable anchor
- V8 repeated 0.65577; foldbag 0.65140. Broad averaging destroyed geometry.
- V9/V9.1 residual looked attractive locally but V9.1 ~0.65432.
- V12 Leader6 0.65792.
- **V12.2 Consensus3 0.65856**, OOF ~0.664368. Long-lived anchor with frozen module-specific weights.

## V13–V15: router and pairwise diagnostics
- V13.1 0.65754: local router gain failed public due second-level leakage / OOF-full geometry mismatch.
- V14 adjacent pair AUC exposed decreasing learnability: .668 → .521 from top to bottom.
- V15 accepted zero actions, correctly fail-closing.

## V16–V20: large semantic exploration
- V16 Qwen3-Embedding-8B frozen global semantic: no gate.
- V17 Top5-aware semantic: tiny unstable gain.
- V18 0.65829.
- V19 0.65791.
- V20 Qwen/BGE late interaction + shift diagnostics: no useful broad distribution shift; semantic complementarity insufficient.

## V21 family
- V21 Qwen3 8B 4-bit QLoRA: 0.65786; anchor transport mismatch.
- V21.1 stable low-capacity module calibration: **0.65869**.
- V21.2 semantic LambdaRank trust-region: 0.65776.

## V22–V26: surgical public corrections
- V22.1 0.65846.
- V22.2 0.65878.
- V22.3 pair winner: **0.65912**, notably U4047 + U4953 action package.
- V24 PB+U4498 displayed flat 0.65912.
- V25 core6: **0.65919**.
- V25 aggressive9 also displayed 0.65919.
- V26 prune U4491: displayed 0.65919.

Lesson: surgical corrections work but micro-action supply alone cannot bridge ~0.002 gap.

## V27–V29.5: head12, hierarchical calibration, curriculum diagnostics
- V27/V27.1 upper-rank pair branch had some theoretical upside but insufficient coverage / calibration issues.
- V28 broad hierarchical graded calibration: many changes but fresh validation strongly negative.
- V29 Curriculum-Aware Residual LTR looked strong on one strict setup but pseudo-public tail failed gate.
- V29.5 kill-test exposed split/regime instability and found generic uncertainty/stability poorly correlated with correctness.

## V30 — major model-side breakthrough, public 0.65963
**3-Fresh-Salt Split-Robust Pair-Conditional Curriculum Residual LTR.**

Winner: `ltr_base`, alpha 0.16, no direct curriculum/cooc in primary.
Fresh C/D/E increments:
- +0.000890
- +0.000449
- +0.000855
13/15 folds positive; pooled +0.000732, CI roughly [+0.000337, +0.001145].
Sealed F +0.000969; chronology ~+0.000042.
Public realized +0.00044 vs V25, about 60% of offline pooled lift.
V30 changed 77 test users vs V25; 8 Top1, 7 membership.

## V31 — Intent-State Residual LTR, public 0.65949
Adds strict nested target encoding for latest intent × module × readiness. Fresh G/H/I mean increment only ~+0.000153 and pooled uncertainty crossed zero. Whole candidate public fell slightly vs V30.

But the **change geometry** became incredibly useful later:
- V31 changed 60 users vs V30;
- 34 overlap with V30-changed users;
- 26 changes are V31-new-only.

## Public V31 decomposition
- V30 + V31 new-only26: **0.65906** → very toxic.
- V30 + V31 overlap34: **0.66006** → large improvement. This became **Hybrid34**.
- Hybrid34 + two extra selected corrections: **0.65976** → tail false positives expensive.

This established S0/S1/S2/S3 state machine and proved that disagreement geometry can be more useful than whole model score.

## V32 — Cross-Objective Residual Consensus
YetiRank / LightGBM XE-NDCG / objective median / unanimous correction. Whole candidates mixed or negative across K/L/M; no robust gate. Branch closed.

## V33 — Retrieval-Augmented Residual Actions
Exact V30 anchor; train-only local residual memory; fresh N/O/P. Broad outcomes mixed/weak; protected near-flat. Proposed interventions collapsed into low-value module-direction patterns such as M003/M002. All submission candidates fail-closed to V30.

## V34 — Frozen BGE Cross-Encoder Head12
`BAAI/bge-reranker-v2-m3`, an XLM-R-family reranker, used frozen as independent semantic evidence for #1↔#2. Benefit AUC moderate but no safe high-precision tail; **0 deployment actions**, exact V30 fallback.

Important: this did **not** prove XLM-R fine-tuning useless; it only showed frozen generic reranker evidence insufficient.

## V35 — Task-Adaptive IndoBERT Pairwise Utility
`indobenchmark/indobert-base-p2`, TAPT + full supervised fine-tuning, pair reversal, benefit/harm/tie and signed utility. Fresh U/V/W ATTACK had small positive increments:
- U +~0.000235, 4 actions (3 beneficial/1 harmful)
- V +~0.000093, 1 action
- W +~0.000347, 5 actions (4/1)
Pooled ~+0.000225, only 10 actions. Fine-tuning improved benefit AUC vs frozen by ~0.010 but not leader-scale.

## V35.1 — fold-pure IndoBERT confirmation
Fixed the concern that TAPT had seen validation text by training TAPT only on train side. Confirmation protocol X + sealed T + chronology. The promising development behavior did not transfer cleanly enough; no new public candidate. IndoBERT branch closed.

## Hybrid34 established — 0.66006
After decomposition, Hybrid34 became immutable anchor for V36 onward.
State counts on test:
- S0 897
- S1 26
- S2 43
- S3 34

## V36 — XE Proposal Competence Router
XE used only to propose alternatives; low-capacity competence router predicts exact ΔNDCG. Whole tuple/atomic proposal identity unstable. Fresh policy search failed; 0 validation/test actions. Primary exact Hybrid34.

## V36.1 — Cross-Shadow XE Residual Pressure Stability
Four 2700-user XE shadows; use continuous pressure rather than exact same proposal. E/F/G policy actual:
- corridor mixed/negative overall;
- ATTACK negative all worlds.
But oracle stable-action supply was huge, revealing **selector failure, not proposal shortage**.

Key audit:
- raw pressure magnitude / stability score were anti-correlated with true utility;
- actual XE boundary crossing (`xe_cross_votes`) was positively correlated;
- Top1 candidates were strongly toxic in this XE branch;
- S2 candidate pool was negative 3/3 with weak oracle;
- **S0** cross>=2, pressure>=3, non-top1 pool had positive broad signal and large oracle headroom.

Validation flaw discovered: E/F/G came from independent ShuffleSplits and overlapped users, so they were not independent confirmation cohorts. This caused V37 redesign.

## V37 — S0 XE Crossing Expected-Utility Router
Fresh H/I/J made truly disjoint. S3 locked, S1/S2 excluded, S0 only, rank1 locked, crossing requirements, low-capacity EU selector. Result again failed promotion: selector could not reliably convert oracle supply into fresh benefit. Primary exact Hybrid34.

## V38 — XLM-R Base Direct Residual Judge
Full supervised `FacebookAI/xlm-roberta-base`, pair reversal, joint user+A+B contextual cross-encoder, no XE/TAPT. Fresh K/L/M.

Result:
- ~1,300 eligible pairs/world;
- model NLL only weakly better than random 3-class reference;
- calibration found **0 usable actions** in all K/L/M;
- SAFE/ATTACK thresholds became `inf`;
- primary exactly Hybrid34.

Root cause: asking pretrained XLM-R to learn rare residual Hybrid34 mistakes directly was too difficult and data-starved.

## V38.1 — Curriculum XLM-R Base
Major reformulation:
1. Stage A: broad user↔module relevance, 17 modules/user, BCE + score regression.
2. Stage B: hard non-tie pairwise curriculum, pair reversal, upper six layers adapted.
3. Stage C: semantic encoder frozen, small grouped Logistic/Ridge residual calibration.
Dual semantic seeds. Fresh AA/AB/AC.

Stage-A relevance AUC roughly 0.701–0.718; standalone NDCG varied ~0.566–0.616. Stage-B pair AUC roughly 0.568–0.612. Semantic learning was real but only moderate.

Fresh action results:
- AA: 0 actions for all policies.
- AB ORDER_SAFE: +0.000248, 9 actions, 5 benefit/2 harm/2 tie, precision 0.714.
- AB MEMBERSHIP: -0.000340, 7 actions, precision 0.4.
- AC ORDER_SAFE: +0.000251, 8 actions, 5/2/1, precision 0.714.
- AC membership: 0 actions.

Development SAFE mean +0.000166 but worst 0; ATTACK mean only +0.000053 with negative worst. Gate failed. Sealed/final skipped. Primary exact Hybrid34.

Conclusion: curriculum improved semantic learnability but still did not create stable leader-scale residual corrections. Do not jump to XLM-R Large without a clearer reason.

## Public rule-level ablation after V38.1 — current breakthrough
Instead of another model, decompose the 34 public-proven S3 actions by ranking geometry:
- remove Top1-changing 3 → **0.65950**;
- remove membership-changing 4 → **0.66006**;
- remove order-only 27 → **0.66020**.

Therefore current champion is Hybrid34 with only 7 S3 actions retained: Top1 + membership. This returned the team to visible Top-5.
