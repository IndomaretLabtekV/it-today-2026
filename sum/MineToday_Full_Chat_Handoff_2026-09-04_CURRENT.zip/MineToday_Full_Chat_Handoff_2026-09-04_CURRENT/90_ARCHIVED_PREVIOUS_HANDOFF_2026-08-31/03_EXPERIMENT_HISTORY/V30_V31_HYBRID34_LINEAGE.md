# V30 → V31 → Hybrid34 Lineage

## V30
V30 is the most important model-side public success after Consensus3/V25.
- Base residual LambdaRank, alpha 0.16.
- Fresh C/D/E robust and sealed F positive.
- Public +0.00044 to 0.65963.
- 77 changed test users vs V25.

## V31
V31 preserved V30 architecture but added strict fold-safe hierarchical Intent-State target encoding. Whole V31 public 0.65949, slightly worse.

But its disagreement pattern vs V30 exposed a useful conditional region.

## Test state machine
Let `A=V25/pre-V30 anchor`, `B=V30`, `C=V31`.

- S0: B=A-like/stable and C=B → 897.
- S1: B stable, C!=B → 26.
- S2: B!=A, C=B → 43.
- S3: B!=A and C!=B → 34.

Public decomposition:
- S1-only changes are catastrophic: 0.65906 when added to V30.
- S3 package improves to 0.66006.

Deterministic Hybrid34:
`Hybrid34 = V31 where (V30 != V25) AND (V31 != V30); else V30.`

No list of 34 user IDs is necessary; state membership is derived from ranking geometry.

## Current refinement
S3 itself is heterogeneous:
- 3 Top1-changing actions: strongly positive package.
- 4 membership-changing actions: net-neutral displayed.
- 27 pure order-only actions: net negative.

Current 0.66020 rule:
`Hybrid34, but within S3 reject pure internal-order changes.`
