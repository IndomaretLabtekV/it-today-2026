# One-Page Current State

## Task
Predict a ranking score over **17 course modules** for each of **1,000 test users**. Metric: **user-level NDCG@5**.

Data:
- 4,000 train users
- 1,000 test users
- 17 modules
- 14,573 chat rows
- 5,000 assessment rows
- positive modules per train user: K=4: 1,362; K=5: 1,285; K=6: 1,353
- 251 invalid assessment cells in 50,000 normalized cells
- 535 administrative/noise chat rows identified

The target head is structurally stable: every user has ordered ranks 1–4; ranks 5/6 are conditional on K.

## Current best
**0.66028**, exact B34+B45 champion.

## Most important public causal evidence
- S3 Top1 3-row package: strongly positive, roughly +0.00056 collectively.
- S3 membership 4-row package: displayed near-neutral.
- S3 B23 9-row package: **-0.00022**.
- S3 B34 10-row package: **+0.00006**.
- S3 B45 8-row package: approximately **+0.00002** on top of B34.

## State geometry
`S0=897, S1=26, S2=43, S3=34`.
- V30 changed 77 users vs V25.
- V31 changed 60 users vs V30.
- S3 is overlap/disagreement region that produced the strongest public gains.

## Strong lessons
1. Sparse lexical + calibration remains foundational.
2. Residual V30 LambdaRank was a genuine model-side breakthrough.
3. Broad reranking/ensembling usually damages a strong anchor.
4. The selector problem is harder than the proposal problem: oracle action supply often exists, but learned confidence rarely identifies good actions.
5. Public-positive progress came increasingly from **causal pruning/decomposition**, not stronger models.
6. Membership and lower-boundary prediction are intrinsically difficult because K is almost uniformly 4/5/6.
7. High-capacity semantic/neural models can learn signal but still fail to convert it into reliable residual NDCG gain.

## Current next step
Audit the V25 surgical package itself. The package improved PB from 0.65912 to 0.65919, but individual attribution inside core-6 was never isolated. Determine whether V25 contains one or more hidden negative/neutral subfamilies that can be removed while preserving all later public-positive lineage.
