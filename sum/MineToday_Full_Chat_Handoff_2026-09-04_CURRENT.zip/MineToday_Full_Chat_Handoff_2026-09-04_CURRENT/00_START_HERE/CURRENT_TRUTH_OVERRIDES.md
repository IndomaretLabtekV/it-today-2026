# Current Truth Overrides

Use this file to override any stale conclusion in older handoffs or research reports.

## Current public best
- **Best public score: 0.66028**.
- Exact champion is the selective Hybrid34 lineage plus the public-positive S3 B34 and B45 boundary packages.
- Reported leaderboard snapshot: rank 5 around **0.66066**, rank 4 **0.66080**, rank 3 **0.66082**, rank 2 **0.66083**, leader **0.66142**.
- Gap to leader: **+0.00114**.
- Gap to rank 5: about **+0.00038**.

## Exact current champion hash
Top-5 ranking hash for B34+B45 champion:
`7c0d29a7309b7283a043b7d37ca5556ba7c0ca2270b0137a6e1e0878a69a5fe7`

Related historical hashes:
- Hybrid34 Top5: `47f7db52ce8f782b8b393fd120140f1b6f51aeac452a9fabb5794cc9d8ba5e6e`
- current066020 Top5: `c70ce570ec311e3f7391cec324e566a3a0e27da99ffc210afc3a8f102daf0191`

## What has happened after the 2026-08-31 handoff
The following branches were run and are now closed for direct deployment:
- V39/V39.1 trajectory/pairwise boundary selector branch: no robust new candidate.
- V39.5 public causal boundary decomposition: B23 harmful, B34 positive, B45 small positive/near-flat; champion advanced to 0.66028.
- V40 prerequisite membership attempt: no robust improvement.
- V41/V41.1 semantic dense/Qwen stack: development optimism did not survive untouched validation.
- V41.2 head preference specialist: insufficient transfer/action quality.
- V42 generator-state residual: small real representation signal, insufficient design gate.
- V42.1 support-shrunk generator-exclusive residual: +0.000069 DESIGN only, 3/5 folds; failed.
- V43 joint user-level TabM residual: strongly harmful broad reranking, -0.003718 DESIGN.
- V43.1 nested trust-path TabM: overshoot mostly removed but direction remained slightly negative, -0.000047 DESIGN; branch closed.
- V44 frozen-lineage V30-S2 causal pruning: no natural S2 class passed gate; 0 test changes; branch closed.

## Current recommended next work
Do **not** build V43.2, V44.1 module-specific pruning, another Qwen/XLM-R reranker, or another broad residual model.

The next justified audit is:
**V25 surgical package decomposition** — causal decomposition of the already public-positive V22.3/V25 surgical action lineage, using algorithmic action families and fold-pure counterfactual replay rather than user-ID whitelists.

## Submission status caution
In this chat, V42.1, V43, V43.1 and V44 were all explicitly judged **NO SUBMIT** because their primary outputs fail-closed to the exact 0.66028 anchor or failed validation. Unless a submission was made independently outside the chat, these experiments should not have consumed a daily slot.
