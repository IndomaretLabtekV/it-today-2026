# MineToday / IT Today 2026 — Full Chat Handoff

Snapshot date: **2026-09-04 (WIB)**

This archive is designed so a new ChatGPT conversation can continue the MineToday competition work without losing the reasoning history. It contains **documentation only**. It intentionally does **not** include notebooks, result CSVs, raw datasets, model weights, or submission files.

## Read order
1. `00_START_HERE/CURRENT_TRUTH_OVERRIDES.md`
2. `00_START_HERE/ONE_PAGE_CURRENT_STATE.md`
3. `01_CURRENT_STATUS/CURRENT_CHAMPION_AND_LEADERBOARD.md`
4. `02_RECENT_EXPERIMENTS_V39_V44/MASTER_TIMELINE_V39_V44.md`
5. `03_PUBLIC_CAUSAL_AND_CHAMPION/CAUSAL_COMPONENT_LEDGER.md`
6. `06_FAILURE_ANALYSIS/WHAT_IS_NOW_CLOSED.md`
7. `07_NEXT_STEP_V25_SURGICAL/V25_SURGICAL_DECOMPOSITION_BLUEPRINT.md`
8. `09_CHAT_HANDOFF/READY_TO_PASTE_NEXT_CHAT.txt`

## Historical coverage
`90_ARCHIVED_PREVIOUS_HANDOFF_2026-08-31/` is the complete prior handoff archive covering the detailed V1–V38.1 history and earlier archived handoffs. Some recommendations inside that historical folder are now outdated. Current truth in folders `00`–`10` always overrides historical notes.

`91_ARCHIVED_RESEARCH_REPORTS/` stores the longer research/post-mortem documents that influenced V41–V44. They are useful context, not current instructions.
