# V25 Historical Action Evidence

This is historical documentation, **not permission to hardcode IDs in the final notebook**.

## PB two-action package
Historically documented actions:
- U4047: M007 > M009
- U4953: M005 > M016

Package public effect: V22.2 0.65878 → V22.3 **0.65912** (+0.00034). Individual contributions unknown.

## Core-6 package
Historically documented actions and analog evidence:
- U4074: M003 > M014; support 81; positive 29; harm 20; margin 0.000682443
- U4176: M017 > M003; support 10; positive 9; harm 1; margin 0.000203669
- U4491: M002 > M003; support 61; positive 25; harm 20; margin 0.001700282
- U4567: M012 > M014; support 56; positive 24; harm 14; margin 0.000054896
- U4836: M002 > M003; support 12; positive 7; harm 3; margin 0.000934988
- U4929: M002 > M003; support 61; positive 25; harm 20; margin 0.000661612

Package public effect: PB 0.65912 → **0.65919** (+0.00007 displayed).

## Relaxed-3
Historically documented:
- U4030: M003 > M007; support 11; positive 6; harm 2; margin 0.002789915
- U4650: M012 > M003; support 9; positive 5; harm 1; margin 0.002036035
- U4731: M006 > M014; support 43; positive 11; harm 6; margin 0.001383066

Package public effect: remained **0.65919** displayed.

## Key interpretation
These IDs/pairs prove only package history. They do not prove which individual test action was correct. A compliant next experiment must reconstruct the action *mechanism* from organizer data and evaluate class-level behavior fold-pure on train.
