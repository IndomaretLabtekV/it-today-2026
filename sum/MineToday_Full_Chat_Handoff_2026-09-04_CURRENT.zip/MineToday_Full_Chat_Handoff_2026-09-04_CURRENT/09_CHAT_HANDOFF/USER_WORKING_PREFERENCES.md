# User Working Preferences for This Project

- Language/style: casual Indonesian, `gua/lu`, direct and technical.
- Do not promise a leaderboard score or say a candidate will definitely win.
- User prefers deep analysis/design **before** notebook creation.
- Once notebook is requested, create a ready-to-run Kaggle notebook and do not dump the notebook-generation Python into the chat.
- Target runtime commonly Kaggle **T4×2**.
- User values exact reproduction, deterministic seeds, hashes, and fail-close behavior.
- Avoid wasting daily submission slots on candidates identical to the champion or candidates that failed a meaningful offline gate.
- The user wants aggressive search for improvement, but not post-hoc validation/public-ID overfitting.
