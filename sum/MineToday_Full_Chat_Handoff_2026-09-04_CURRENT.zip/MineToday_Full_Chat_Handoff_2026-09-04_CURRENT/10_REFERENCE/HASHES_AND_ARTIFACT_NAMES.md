# Hashes and Artifact Names

## Important hashes
- Exact current champion B34+B45 Top5: `7c0d29a7309b7283a043b7d37ca5556ba7c0ca2270b0137a6e1e0878a69a5fe7`
- Hybrid34 Top5: `47f7db52ce8f782b8b393fd120140f1b6f51aeac452a9fabb5794cc9d8ba5e6e`
- current066020 Top5: `c70ce570ec311e3f7391cec324e566a3a0e27da99ffc210afc3a8f102daf0191`

## Recent notebook names referenced in chat (not included here)
- MineToday_V42_1_Champion_Anchored_Support_Shrunk_Generator_Exclusive_Head_Ranker_FINAL.ipynb
- MineToday_V43_Joint_User_Level_Anchor_Residual_TabM_Partial_PL_FINAL.ipynb
- MineToday_V43_1_Nested_Residual_Trust_Path_TabM_FINAL.ipynb / FIXED
- MineToday_V44_Frozen_Lineage_Causal_Pruning_V30_S2_FINAL.ipynb / FIXED

## Recent result bundles referenced in chat (not included here)
- results-v42.zip
- results-v42_1.zip
- v43.zip
- results-v44.zip

These names are recorded only so a future chat can map discussion back to artifacts if they are uploaded again.
