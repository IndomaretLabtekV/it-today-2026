# Key Numbers — Current

## Dataset
- 4,000 train users
- 1,000 test users
- 17 modules
- 14,573 chat rows
- 5,000 assessment rows
- K4/K5/K6 = 1362 / 1285 / 1353
- invalid assessment cells = 251 / 50,000
- administrative/noise chat rows = 535

## Public scores
- Consensus3 = 0.65856
- V21.1 = 0.65869
- V22.3 = 0.65912
- V25 = 0.65919
- V30 = 0.65963
- V31 whole = 0.65949
- Hybrid34 = 0.66006
- selective current066020 = 0.66020
- B34 = 0.66026
- B34+B45 = **0.66028**
- leader snapshot = 0.66142

## State geometry
- V30 changed vs V25 = 77
- V30 Top1 changes = 8
- V30 membership changes = 7
- V31 changed vs V30 = 60
- S0/S1/S2/S3 = 897/26/43/34
- S3 Top1/membership/order-only = 3/4/27
- S3 B23/B34/B45 = 9/10/8

## V42.1
- DESIGN delta = +0.00006898
- folds = 3/5
- blocks = 4/5
- changed = 21
- Top1 changes = 1

## V43
- TabM delta = -0.00371831
- TabM changed = 1475
- TabM Top1 changes = 420
- MLP delta = -0.01142021

## V43.1
- delta = -0.00004747
- folds = 1/5
- blocks = 1/5
- changed = 17
- Top1 changes = 3

## V44 class prune delta
- TOP1 +0.0000611
- MEMBERSHIP -0.0000436
- B23 +0.0000307
- B34 -0.0000334
- B45 -0.0000051
- COMPLEX_ORDER +0.0000154
- selected classes = none
