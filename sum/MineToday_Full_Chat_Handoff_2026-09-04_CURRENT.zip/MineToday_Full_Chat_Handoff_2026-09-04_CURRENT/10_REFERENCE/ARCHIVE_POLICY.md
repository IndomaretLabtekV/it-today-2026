# Archive Content Policy

Included:
- markdown/txt/json documentation
- synthesized experiment history
- research/post-mortem notes
- old handoff documentation
- exact public score and geometry facts recorded in the conversation
- next-step architecture and reproducibility rules

Excluded intentionally:
- `.ipynb` notebooks
- result CSVs
- submission CSVs
- raw competition dataset
- model weights/caches
- PDFs
- ZIP result bundles

Historical IDs/pairs may appear in documentation because they are part of the experiment record. They are not approved as hardcoded predictive logic for a final competition notebook.
