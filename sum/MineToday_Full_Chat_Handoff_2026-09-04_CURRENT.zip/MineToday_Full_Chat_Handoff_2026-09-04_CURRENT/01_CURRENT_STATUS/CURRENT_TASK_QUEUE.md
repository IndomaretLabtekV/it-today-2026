# Current Task Queue

## Priority 1 — V25 surgical package decomposition
Goal: determine whether the small public-positive V25 package contains hidden negative or neutral subcomponents that can be pruned algorithmically.

## Priority 2 — only if V25 audit is exhausted
Potential tiny causal probes, in decreasing preference:
- S3 membership 4-row package removal as a pure public causal probe (small upside, so not preferred first).
- revisit only structurally natural public-positive packages with remaining unresolved attribution.

## Do not spend time on
- V43.2 hyperparameter tuning
- V44.1 class×module pruning
- new Qwen/XLM-R/BGE semantic model
- another full-list LambdaRank/YetiRank/XE ensemble
- exact-template/user-ID whitelist
- confidence threshold mining after seeing validation
- random public probes with no causal interpretation
