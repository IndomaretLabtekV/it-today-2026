# Current Champion and Leaderboard

## Public score lineage near the top
- V25: **0.65919**
- V30: **0.65963**
- V31 whole: **0.65949**
- Hybrid34: **0.66006**
- Hybrid34 minus S3 order-only27: **0.66020**
- B23 probe from 0.66020: **0.65998**
- B34 probe: **0.66026**
- B34+B45: **0.66028** ← current best

## Current exact policy
The final champion is not a single model score. It is a deterministic lineage/state-machine construction:
1. reconstruct Consensus3 and V25;
2. apply V30 residual policy;
3. use V30/V31 geometry to construct S0/S1/S2/S3;
4. keep the public-proven S3 high-value actions while rejecting the harmful order-only aggregate;
5. restore the B34 and B45 sub-boundaries that public probes showed were positive/non-negative;
6. keep B23 rejected.

## Leaderboard snapshot supplied in the chat
- Rank 6: ~0.66046
- Rank 5: ~0.66066
- Rank 4: ~0.66080
- Rank 3: ~0.66082
- Rank 2: ~0.66083
- Rank 1: **0.66142**

The current best needs about +0.00038 to reach the displayed rank-5 region and +0.00114 to match the leader.

## Important restraint
Do not sacrifice the 0.66028 champion for a candidate that only looks attractive on one development split. Any new candidate should fail-close exactly to the champion if gates do not pass.
