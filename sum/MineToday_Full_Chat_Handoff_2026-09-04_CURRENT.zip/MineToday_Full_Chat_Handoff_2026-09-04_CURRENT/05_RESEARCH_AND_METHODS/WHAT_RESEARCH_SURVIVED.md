# What Research Survived

## Surviving modeling ideas
1. **Sparse word+char TF-IDF** with trajectory tags and cleaned assessment features.
2. **Per-module binary relevance calibration** rather than crude Borda/rank fusion.
3. **Small module-specific blend weights** (Consensus3 philosophy).
4. **Residual learning** rather than full replacement, as shown by V30.
5. **Strict nested/fold-pure validation** and untouched rejection-only LOCK sets.
6. **Natural ranking-geometry decomposition** for public causal probes.
7. **Fail-close to exact champion** when a development gate fails.

## Research ideas that contained real signal but were not deployable
- Qwen semantic embeddings: complementary information exists, but full-list residual action conversion was unstable.
- IndoBERT/XLM-R pair models: pairwise signal can be learned, but residual selection at the champion frontier is data-starved.
- Generator/template state: V42 showed a small genuine incremental representation effect, but it was too weak and fragile.
- Joint user-level TabM: the shared representation was better than plain MLP, but broad reranking authority was harmful; even strong shrinkage did not make the residual direction stable.

## Central research conclusion
The project is no longer bottlenecked primarily by representation capacity. It is bottlenecked by **precision of intervention against an already strong ranking surface**. The best late gains came from decomposing known public-positive/negative packages, not from adding a stronger encoder.
