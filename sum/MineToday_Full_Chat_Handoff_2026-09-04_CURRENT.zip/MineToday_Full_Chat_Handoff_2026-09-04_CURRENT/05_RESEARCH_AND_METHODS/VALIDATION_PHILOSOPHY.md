# Validation Philosophy

## Non-negotiable principles
- Never tune on public user IDs.
- Never use old submission CSVs as predictive inputs in the final reproducible notebook.
- Use old public scores only as causal evidence about algorithmic packages that can be reconstructed from organizer data.
- When stacking, first-level predictions used by a second-level learner must be nested relative to the second-level validation fold.
- Keep an untouched LOCK split; do not retrain/change policy after seeing LOCK.
- Prefer multiple random folds plus contiguous/high-ID blocks because train/test user IDs are sequential and some feature drift exists.
- Report changed-user geometry, not only aggregate NDCG.

## Why one lucky split is not enough
Many branches had positive development worlds but failed on a fresh or sealed split. This happened repeatedly with semantic stacks, routers, rare-action selectors, and V43.1 trust calibration.

## Action-level validation
For any residual change, track:
- exact before/after ranking positions
- Top1 change?
- Top5 membership change?
- boundary type
- per-user ΔNDCG on OOF
- beneficial/harmful/tie
- fold stability
- contiguous-ID stability
- whether action overlaps a public-protected region
