# Implementation Bug Log

This log prevents the next chat from rediscovering recent notebook errors.

## V43.1 first generated notebook
Runtime reached the SVD cell and failed:
`NameError: name 'V43_MODEL_SEED' is not defined`

Root cause: stale V43 variable name remained after the config was renamed for V43.1.
Fix: use the actual V43.1 model-seed variable consistently. The fixed notebook then ran and produced the V43.1 diagnostic result.

## V44 first generated notebook
Runtime reached outer fold 1 and failed inside `build_v44_val_split`:
`NameError: name 'ALL_INTENT' is not defined`

Root cause: helper code inherited an `ALL_INTENT` compatibility dependency from V42/V43 lineage, but V44 setup did not define it.
Fix: restore the compatible all-user intent array/alias before split helper use. The fixed notebook subsequently ran to completion and produced V44 metrics.

## General lesson
Static compile/unresolved-name scans are useful but not sufficient because dynamic notebook state and helper dependencies may only fail during deep execution. For new notebooks, run a lightweight lineage smoke path that enters at least the first outer-fold construction before claiming Kaggle readiness.
