# Competition Rules and Compliance Constraints

Official TM facts carried from the project:
- Kaggle submission phase: **19 Aug–9 Sep 2026**.
- Notebook submission: **10–14 Sep 2026**.
- Maximum **3 Kaggle submissions/day**.
- External data prohibited; use organizer-provided data only.
- Multiple ML models allowed.
- Open-source pretrained models allowed; paid pretrained models not allowed.
- LLM/GenAI must not directly generate test relevance values.
- Coding assistants are allowed.
- Prediction notebook and seeds are mandatory for reproducibility.
- Final evaluation checks notebook/output consistency with small tolerance (~0.001 referenced in discussion).

## Safe final-notebook practice
- Reconstruct every score/action from organizer data and code.
- Pin or report package versions and seeds.
- Assert dataset shapes and known lineage hashes.
- Do not load historical submission CSV as a predictive input.
- Do not hardcode a list of public test user IDs.
- Natural algorithmic categories derived from model ranking geometry are acceptable if reproducible.
- Use public leaderboard feedback only to choose between algorithmic hypotheses/packages, not to label individual test users.
