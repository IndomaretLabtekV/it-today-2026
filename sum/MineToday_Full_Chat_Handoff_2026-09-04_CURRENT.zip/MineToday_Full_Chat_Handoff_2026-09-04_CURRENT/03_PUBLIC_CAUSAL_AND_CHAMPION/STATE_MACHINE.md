# State Machine

Let A = V25/pre-V30 anchor, B = V30, C = V31.

Test state counts:
- S0 = 897
- S1 = 26
- S2 = 43
- S3 = 34

Operational interpretation:
- S0: no meaningful V30 intervention and V31 agrees; stable bulk.
- S1: V31-new-only region; public evidence showed this region is highly toxic when broadly adopted.
- S2: V30-only region; V44 coarse class audit found no removable harmful class.
- S3: V30 intervention plus V31 disagreement/overlap region; public decomposition found the strongest actionable signal.

S3 internal geometry:
- 3 Top1-changing actions
- 4 membership-changing actions
- 27 order-only actions
  - B23: 9
  - B34: 10
  - B45: 8

This state machine must be reconstructed algorithmically from model/policy geometry. Do not hardcode a list of test user IDs in the final competition notebook.
