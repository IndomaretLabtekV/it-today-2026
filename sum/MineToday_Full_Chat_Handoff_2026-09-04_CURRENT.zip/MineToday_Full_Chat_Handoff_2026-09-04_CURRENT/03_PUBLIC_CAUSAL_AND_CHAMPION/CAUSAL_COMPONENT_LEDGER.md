# Causal Component Ledger

## V22.3 / PB
Two-action package moved public score from 0.65878 to **0.65912**, package gain about +0.00034. Individual attribution was never isolated.

## V25 core-6
PB + core-6 moved displayed public score from 0.65912 to **0.65919**, package gain about +0.00007. Individual attribution remains unresolved. This is the reason V25 is now the next audit target.

## V25 relaxed-3
Core-6 + relaxed-3 remained displayed **0.65919**. Net incremental effect is unresolved/too small at displayed precision.

## V30
V30 moved V25 0.65919 → **0.65963**, genuine +0.00044 broad model-side gain. Changed 77 test users, 8 Top1, 7 membership.

## V31 disagreement decomposition
- V31 whole: 0.65949, worse than V30.
- V31 new-only26 added to V30: 0.65906, toxic.
- V30/V31 overlap34 (Hybrid34): **0.66006**, strongly positive.

## S3 public causal ablation
Starting from Hybrid34 0.66006:
- remove S3 Top1-3 → 0.65950. Therefore these 3 actions are collectively extremely valuable (~+0.00056 relative to removal).
- remove S3 membership-4 → 0.66006 displayed, net-neutral at shown precision.
- remove S3 order-only27 → **0.66020**, so aggregate order-only package is harmful.

## S3 boundary causal decomposition from 0.66020
- B23 9 actions: 0.65998 → harmful, reject.
- B34 10 actions: 0.66026 → keep.
- B45 8 actions after B34: 0.66028 → keep.

## V44 S2 causal audit
No coarse S2 natural class passed the pre-registered pruning gate. Therefore do not create V44.1 class×module subgroup mining from the same DESIGN evidence.
