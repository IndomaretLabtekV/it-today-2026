# MineToday V1–V41.1 Post-Mortem and Pre-Registered Final Experiment Plan

## Executive summary

The evidence from V1 through V41.1 does **not** say that the project has exhausted all learnable signal. It says something narrower and more useful: the current **full-list residual-ranking paradigm is saturated**, while the highest-leverage part of the label structure—the ordered head of the list—has not yet been isolated as its own learning problem.

The strongest public anchor remains **B34 = 0.66026**. Using the standings snapshot supplied for September 3, 2026, that leaves **+0.00020 to rank 6, +0.00040 to rank 5, +0.00054 to rank 4, +0.00056 to rank 3, +0.00057 to rank 2, and +0.00116 to the leader**. The public S3 probes provide the most important leverage evidence: three S3 Top1 corrections contributed roughly **+0.00056**, whereas four membership corrections were approximately net-zero, the ten B34 3↔4 corrections added only **+0.00006**, B23 lost **−0.00022**, and B45 is approximately flat. The exact state geometry is `S0=897, S1=26, S2=43, S3=34`; S3 decomposes into 3 Top1, 4 membership, and 27 order-only disagreements. fileciteturn30file17 The current V41.1 reconstruction independently reproduces those counts and the exact B34 hash; the earlier execution log also records the same geometry. fileciteturn0file0

The dataset itself strongly explains why so many lower-boundary ideas failed. Each training user has exactly **4, 5, or 6 positive modules**, distributed as 1,362 / 1,285 / 1,353 users, respectively. That is 34.05%, 32.13%, and 33.83%—almost a maximum-entropy three-way distribution. There are 19,991 relevant user-module pairs out of 68,000, an overall density of **29.40%**. More importantly, the graded-label counts show that ranks **1–4 exist for all 4,000 users**, rank 5 exists for 2,638 users, and rank 6 for only 1,353 users. fileciteturn0file0 Thus the top four are structurally stable while the lower cutoff is intrinsically conditional on K.

A previous K-predictability diagnostic reported about **0.3358 accuracy versus a 0.3405 majority baseline** using text plus assessment features. That exact diagnostic output was not preserved in the supplied V41.1 bundle, so I treat the number as provisional rather than as a gating statistic. It should be rerun and exported in the next notebook. Even without that provisional diagnostic, the near-uniform K distribution and the repeated failures of membership-focused models are consistent with high effective uncertainty at the lower boundary.

V41 was scientifically useful despite failing. Structural+Qwen achieved **+0.000824 CAL NDCG, four of four positive CAL folds**, but transferred to **−0.000136 on untouched LOCK**, a CAL→LOCK optimism gap of **0.000960**. Its LOCK bootstrap interval was **[−0.001244, +0.000998]**, and 12 of its 29 changed users were membership changes. More seriously, V41 reused the same CAL folds for first-level stack OOF predictions and second-level LambdaRank validation. For any outer ranker fold, **100% of the ranker-training rows had first-level stack features produced by models whose training data included the outer-validation fold**. That is an indirect second-level dependency, precisely the kind of optimistic assessment that proper stacking/nested validation is intended to prevent. Stacked generalization relies on out-of-sample first-level predictions, and when model-development steps feed back into assessment, all such steps must be nested inside the evaluation loop. citeturn0search2turn0search0turn0search3

V41.1 fixed that issue: one Qwen expert, no XLM-R, no LambdaRank, single-level cross-fitted ordinal stack, no post-LOCK retraining. The result was essentially zero: **−0.000029 CAL**, only **2/5 random folds positive**, **2/5 contiguous-ID blocks positive**, bootstrap CI **[−0.000996,+0.000923]**, Top1 accuracy **−0.002**, relevant@5 **+0.001**. Because CAL failed, LOCK was correctly never opened. `submission_v41_1_primary.csv`, candidate, and B34 reference all share the exact B34 Top5 hash according to `v41_1_summary.json` and `v41_1_reproduction_audit.json`.

That is the decisive diagnosis:

> **Qwen contains real complementary semantic information, but full-list relevance calibration does not translate that information reliably into within-user NDCG gains.**

V41.1’s Qwen module AUC averages **0.6135**, median **0.6254**, while median structural–Qwen correlation is only **0.1195**. Yet the Pearson correlation between Qwen module AUC and the module’s marginal contribution to V41.1 NDCG is only **~0.207**. High AUC therefore does not imply useful residual ordering. M012 is the clearest example: Qwen AUC ≈0.698 but marginal contribution ≈**−0.000218**; M006 has AUC ≈0.672 and contributes ≈**+0.000202**. This is not primarily an embedding-quality problem. It is an **objective mismatch**.

The single next experiment I recommend is therefore **GO**, but it should be the **last experiment of this family**:

> **V41.2 — B34-Anchored Stable-Top4 Qwen Partial-Ranking Specialist**

It should freeze Top5 membership, freeze all S1/S3 public decisions, use the exact B34 anchor, keep only Qwen3-Embedding-8B, and replace full-list binary/ordinal calibration with a **partial Plackett–Luce objective over the guaranteed ordered Top4**. Partial/top-K Plackett–Luce formulations are explicitly designed to learn ordered partial rankings without requiring an ordering over the remaining items, which matches this label structure much better than predicting full-list relevance. citeturn2search8turn2search4

My subjective pre-run probability assessment is deliberately conservative: roughly **30–45%** that the experiment identifies a genuinely positive head-order residual; **15–25%** unconditional probability of a public improvement large enough to reach 0.66066; conditional on passing both preregistered CAL and LOCK gates, I would raise the probability of a positive public transfer to roughly **60–75%**, but not claim certainty of Top-5. The reason to run it is not that success is guaranteed. It is that **this is the remaining intervention family with both empirical public leverage and a learning problem that has not yet been cleanly isolated**.

## Experimental lineage and public evidence

No Kaggle private-leaderboard artifact was supplied; “private” below therefore means internal OOF/CAL/LOCK evidence. Exact original artifacts for many early V1–V20 iterations are also absent. In accordance with the request not to invent missing history, those entries are marked unspecified rather than reconstructed from memory.

### Per-version post-mortem

| Version | Main experiment / surviving lesson | Public score or Δ | Internal/private evidence | Verdict |
|---|---|---:|---|---|
| V1 | Initial baseline | Unspecified | Original artifact unavailable | Historical only |
| V2 | Early baseline iteration | Unspecified | Artifact unavailable | Historical only |
| V3 | Sparse-text lineage | Unspecified | Superseded by V3.1 | Keep lineage |
| V3.1 | Word/char TF-IDF + Ridge sparse backbone | Public-validated; exact score not preserved here | Current reproduction OOF sparse ≈0.658254 | **Keep** |
| V4 | Early listwise/ranking exploration | Unspecified | Artifact unavailable | Superseded |
| V5 | Early full-ranking exploration | Unspecified | Artifact unavailable | Superseded |
| V6 | Early listwise/ranking exploration | Unspecified | Artifact unavailable | Superseded |
| V7 | Module relevance calibration lineage | Historical `cal045` public **0.65639** | OOF ≈0.662646 | **Keep calibration concept** |
| V8 | Seed/fold bagging | Historical repeated ≈0.65577; foldbag ≈0.65140 | Variance reduction did not transfer | **Drop bagging as strategy** |
| V9 | Intermediate | Unspecified | Artifact unavailable | Superseded |
| V10 | Membership/bottom-boundary exploration | Unspecified | Repeatedly weak lower-boundary transfer | Drop family |
| V11 | Intermediate | Unspecified | Artifact unavailable | Superseded |
| V12 | Ordered-ID / contiguity diagnostics lineage | Unspecified | Established train IDs 1–4000, test 4001–5000 | Keep as diagnostic |
| V13 | Stacking lineage | Unspecified | Led to dependency concern | Superseded |
| V13.1 | Second-level stacking validation | Unspecified | Offline optimism / deployment mismatch | **Do not repeat** |
| V14 | Membership/bottom-boundary refinement | Unspecified | Lower cutoff remained unstable | Drop family |
| V15 | Intermediate | Unspecified | Artifact unavailable | Superseded |
| V16 | Qwen semantic comparison | No preserved public score | Semantic meta ≈0.658433 vs old meta ≈0.658242; high cross-family correlation globally | Keep semantic as specialist |
| V17 | Intermediate | Unspecified | Artifact unavailable | Superseded |
| V18 | Intermediate | Unspecified | Artifact unavailable | Superseded |
| V19 | Intermediate | Unspecified | Artifact unavailable | Superseded |
| V20 | Intermediate | Unspecified | Artifact unavailable | Superseded |
| V21 | Semantic adaptation lineage | Unspecified | Led to V21.1 | Keep concept |
| V21.1 | Qwen3-Embedding-8B QLoRA + module-specific semantic calibration | **0.65869**, about **+0.00013** vs Consensus3 | First clearly public-positive semantic result in this lineage | **Keep Qwen** |
| V22 | Semantic follow-up | No preserved public score | Built from V21.1 public-positive branch | No independent proof |
| V23 | Intermediate | Unspecified | Artifact unavailable | Superseded |
| V24 | Intermediate | Unspecified | Artifact unavailable | Superseded |
| V25 | Surgical corrections on Consensus3 | **0.65919** | +0.00050 vs 0.65869 | **Keep anchor lineage** |
| V26 | Intermediate residual work | No preserved public point | Artifact unavailable | Superseded |
| V27 | Intermediate structural reconstruction | No preserved public point | Survives as compatibility/reproduction code | Internal only |
| V28 | Intermediate | No preserved public point | Artifact unavailable | Superseded |
| V29 | Intermediate structural lineage | No preserved public point | Survives in reproduction pipeline | Internal only |
| V30 | Residual LightGBM LambdaRank, fixed α=0.16 | **0.65963**, **+0.00044** vs V25 | 77 test changes; 8 Top1; 7 membership | **Strongly keep** |
| V31 | Intent-State structural residual | Diagnostic **0.65949**, **−0.00014** vs V30 | 60 changes vs V30; S1 new-only package ≈−0.00057 vs V30 | Use features, not broad deployment |
| V32 | Objective ensemble: LambdaRank/XE/YetiRank consensus | No public winner preserved | Loss diversity failed to yield robust incremental signal | **Drop objective ensemble** |
| V33 | Intermediate | Unspecified | No decisive surviving evidence | Superseded |
| V34 | Frozen BGE cross-encoder residual | No public winner preserved | Some counterfactual signal, insufficient robustness | Drop |
| V35 | IndoBERT residual utility | No preserved public score | Historical UVW pooled utility ≈+0.000225, ~0.80 precision | Signal existed |
| V35.1 | Fold-pure IndoBERT confirmation | No public winner | Confirmation regimes rejected deployment | **Drop IndoBERT selector** |
| V36 | Residual action selector | No public winner | Stability/uncertainty did not identify beneficial actions reliably | Drop |
| V37 | Residual router/selector continuation | No public winner | Same failure mode | Drop |
| V38 | XLM-R residual semantic selector | No public winner | Representation learned signal but selector unstable | Drop selector |
| V38.1 | XLM-R curriculum: dense relevance → pairwise → residual | No public winner | Dense Stage A/B learned; residual Stage C failed consistency | Keep lesson, drop XLM-R from final |
| V39 | Direct intent trajectory | No new submission | Exact anchor reproduction; no approved family | **Closed** |
| V39.1 | Pairwise trajectory | No new submission | Only 6 raw validation proposals; none approved | **Closed** |
| V39.5 | S3 causal order decomposition | B23 **0.65998**, B34 **0.66026**, all-order/Hybrid34 **0.66006** | Exact 9/10/8 decomposition | **Critical evidence** |
| V40 | Prerequisite-aligned S3 membership refinement | No new public submission | Fresh 17 actions, mean Δ **−0.03066**, 6 harmful; gate failed | **Closed** |
| V41 | Structural+Qwen(+XLM-R) dense stacking + LambdaRank | No new public submission | Q CAL +0.000824 → LOCK −0.000136 | **Architecture failed** |
| V41.1 | Hierarchical cumulative-ordinal Qwen stack | No new public submission | CAL **−0.000029**, 2/5 folds, 2/5 blocks; LOCK unopened | **Full-list semantic stack closed** |

The exact current notebooks preserve several historical public anchors: `cal045=0.65639`, `Consensus3=0.65856`, `V25=0.65919`, `V30=0.65963`, `V31 diagnostic=0.65949`, `Hybrid34=0.66006`, current pre-B34 anchor `0.66020`, B23 `0.65998`, and B34 `0.66026`. V30’s fixed residual strength of 0.16 was intentionally frozen rather than searched after observing validation outcomes. fileciteturn30file19 V31’s surviving value is mostly representational—its Intent-State block is fold-safe and useful as a structural feature family—but its broad deployment did not beat V30. fileciteturn29file15 V21.1 established the strongest semantic precedent: Qwen usefulness was heterogeneous by module, so semantic trust was already being treated module-specifically rather than with one global weight. fileciteturn28file1

### The decisive S3 causal decomposition

The public S3 evidence is more informative than another round of broad offline model comparison:

| Intervention | Rows | Public score | Δ vs 0.66020 | Mean displayed Δ / row | Interpretation |
|---|---:|---:|---:|---:|---|
| Current selective S3 anchor | 7 | 0.66020 | — | — | 3 Top1 + 4 membership retained |
| S3 Top1 package | 3 | — | **≈+0.00056 vs V30 component** | ≈+0.000187 | Extremely high leverage |
| S3 membership package | 4 | — | **≈+0.00001** | ≈+0.000003 | Aggregate near zero |
| B23 | 9 | 0.65998 | **−0.00022** | −0.000024 | Clearly harmful |
| B34 | 10 | **0.66026** | **+0.00006** | +0.000006 | Small positive |
| B45 | 8 | inferred | **≈+0.00002** | ≈+0.000003 | Effectively flat at displayed precision |
| All 27 order-only | 27 | 0.66006 | **−0.00014** | −0.000005 | Aggregate harmful |

The B45 estimate is the residual of the complete S3 order decomposition and is therefore approximate at leaderboard display precision. The exact structural partition is 9 B23, 10 B34, and 8 B45 actions. fileciteturn30file17

The most important conclusion is not “order does not matter.” It is:

> **The economic value of a ranking correction is highly position-dependent. Three correct head interventions outweighed dozens of lower-order interventions.**

```mermaid
timeline
    title MineToday experimental convergence
    V3.1–V7 : Sparse text + module calibration becomes reliable core
    V8–V20 : Bagging, voting, broad ranking and early semantic variants show transfer limits
    V21.1 : Qwen produces first clear public-positive semantic increment
    V25 : Surgical structural corrections lift the anchor
    V30 : Residual LambdaRank adds +0.00044 public
    V31–V38.1 : Intent state, objective diversity, IndoBERT and XLM-R expose residual-selector instability
    V39–V39.1 : Trajectory branch produces almost no deployable actions
    V39.5 : S3 causal probe identifies Top1 leverage and B34 small-positive family
    V40 : Prerequisite membership rule fails fresh structural gate
    V41 : Complex semantic stack looks strong on CAL but reverses on LOCK
    V41.1 : Clean Qwen ordinal stack becomes flat, closing full-list semantic calibration
    V41.2 : Proposed stable-Top4 partial-ranking specialist
```

## Dataset diagnostics and leakage

### Label geometry and effective noise

The current execution artifacts report `train=(4000,18)`, `test=(1000,1)`, 17 modules, 14,573 chat rows, and 5,000 assessment rows. Positive-module counts are exactly `{4:1362, 5:1285, 6:1353}`. fileciteturn0file0

That yields:

| K | Users | Share |
|---:|---:|---:|
| 4 | 1,362 | 34.05% |
| 5 | 1,285 | 32.13% |
| 6 | 1,353 | 33.83% |

The entropy of this K distribution is approximately **1.58448 bits**, versus the theoretical maximum `log2(3)=1.58496`; in other words, K is almost perfectly balanced.

The ordinal-grade counts in the executed notebook are `{0:48009, 1:1353, 2:2638, 3:4000, 4:4000, 5:4000, 6:4000}`. fileciteturn0file0 Together with the label-value ladder encoded in `v41_1.ipynb`, this means the target structure is effectively:

| True rank | Relevance value | Number of users with that rank |
|---:|---:|---:|
| 1 | 1.00 | 4,000 |
| 2 | 0.85 | 4,000 |
| 3 | 0.70 | 4,000 |
| 4 | 0.55 | 4,000 |
| 5 | 0.40 | 2,638 |
| 6 | 0.25 | 1,353 |

This is the strongest dataset-level argument for the next architecture. The **ordered Top4 is always defined**. The cutoff after rank 4 is not.

The earlier diagnostic that attempted to predict K from TF-IDF text plus assessment reported **0.3358 five-fold accuracy against a 0.3405 majority-class baseline**. Because that diagnostic file is not inside the supplied V41.1 output archive, it should be treated as provisional and reproduced in V41.2. It is directionally consistent with the repeated inability of V10/V14/V36/V37/V40/V41/V41.1 to extract reliable membership signal.

“Label noise” should therefore be interpreted carefully. There is no evidence in the supplied artifacts that the organizer labels are erroneous. The evidence instead supports **effective lower-tail uncertainty**: the presence and identity of rank-5/rank-6 positives is substantially harder to infer than the stable head.

### User, chat, and assessment covariates

The run reports **535 administrative/noise chat rows out of 14,573**, or roughly **3.67%**, and **251 invalid assessment cells out of 50,000**, or roughly **0.50%**. fileciteturn0file0 The feature pipeline creates 134 user-level structural features and removes administrative/noise messages before semantic Qwen construction. It also reports 46 train intent signatures and 46 test intent signatures, with zero test intent signatures unseen in train. fileciteturn0file0

What is **not** available in the supplied final artifacts is a preserved table of K versus assessment mean, chat count, chat length, or unique-message count. Those relationships were previously inspected informally and appeared weak, but they should not be promoted to hard evidence until V41.2 exports `v41_2_k_covariate_audit.csv`.

Likewise, exact **per-module relevance density** was not saved in `v41_1_module_audit.csv`; only per-module AUC, structural correlation, and rank-change involvement were exported. The overall pair density is known—19,991 positives / 68,000 train user-module pairs = **29.40%**—but module-specific positive rates are currently unspecified. V41.2 should export them directly rather than infer them from model behavior.

### Contiguity and block effects

Train IDs are strictly 1–4000 and test IDs 4001–5000. fileciteturn0file0 That does not prove distribution shift, but it makes contiguous-ID diagnostics important. If covariates vary with ordered user blocks, ordinary random CV can be optimistic; under genuine covariate shift, standard CV is no longer an unbiased proxy for future-test risk. citeturn2search1

V41.1’s CAL block results are:

| Ordered CAL block | Approx. source-ID span | Base NDCG | Candidate Δ |
|---:|---:|---:|---:|
| 0 | 1–878 | 0.668156 | **+0.000529** |
| 1 | 879–1612 | 0.673292 | **−0.000735** |
| 2 | 1614–2421 | 0.669016 | **−0.000051** |
| 3 | 2423–3260 | 0.662215 | **−0.000298** |
| 4 | 3263–3996 | 0.650113 | **+0.000412** |

Source: `v41_1_cal_block_metrics.csv`.

Two facts matter. First, only **2/5** blocks improved. Second, base difficulty itself varies substantially: max-minus-min base NDCG is about **0.02318**. The latest-ID block is markedly harder than the middle blocks, even though V41.1 happens to improve it. This is not enough evidence to weight later IDs more heavily—that would be post-hoc—but it absolutely justifies block bootstrap and contiguous-block gates.

### Leakage and public-feedback risks

There are four distinct risks to separate.

**Direct label leakage:** no evidence of it in V40–V41.1. The final reproduction audits explicitly state organizer data only, no external labeled data, no historical submission CSV used as model input, no direct GenAI-generated test relevance, and no post-LOCK retraining. The organizer rules cited in the prior artifacts allow open-source pretrained models and require a reproducible notebook/output pipeline; they prohibit using GenAI to directly supply hidden relevance labels. fileciteturn33file18

**Second-level validation leakage:** this occurred in V41’s architecture, not V41.1. It is the most important technical correction.

**Test-covariate transduction:** parts of the long-standing anchor pipeline fit unsupervised text preprocessing on the combined organizer-provided user pool. This uses no test labels, but it is still transductive preprocessing. The supplied TM excerpts do not identify this as prohibited; because the exact public anchor depends on that historical geometry, V41.2 should not silently alter it. It should document the behavior explicitly.

**Public-leaderboard adaptation:** B34 is now partly a public-feedback-selected anchor. That is legitimate competition feedback, but after 40+ experiments it creates a multiple-probing risk. Therefore V41.2 must not perform any new public subgroup mining. B34 should be frozen as prior evidence, not treated as a new search surface.

## Why V41 and V41.1 failed to transfer

### CAL versus LOCK

| Metric | V41 Structural | V41 Q candidate | V41 Δ | V41.1 Structural | V41.1 HORD-Q | V41.1 Δ |
|---|---:|---:|---:|---:|---:|---:|
| CAL NDCG | 0.664559 | 0.665382 | **+0.000824** | 0.664559 | 0.664530 | **−0.000029** |
| Positive CV folds | — | 4/4 | — | — | 2/5 | — |
| Positive ID blocks | Not exported | Not exported | — | — | 2/5 | — |
| CAL Top1 | 0.498 | 0.498 | 0.000 | 0.498 | 0.496 | **−0.002** |
| CAL relevant@5 | 2.845 | 2.851 | **+0.006** | 2.845 | 2.846 | **+0.001** |
| LOCK NDCG | 0.666278 | 0.666141 | **−0.000136** | Not opened | Not opened | — |
| LOCK 95% bootstrap CI | — | — | **[−0.001244,+0.000998]** | — | — | — |
| LOCK changed users | — | 29 | — | — | — | — |
| LOCK Top1 changes | — | 1 | — | — | — | — |
| LOCK membership changes | — | 12 | — | — | — | — |
| CAL 95% bootstrap CI | Not exported | Not exported | — | — | — | **[−0.000996,+0.000923]** |
| Module concentration | — | — | — | — | — | **0.2381** |

Sources: `v41_cal_metrics.csv`, `v41_lock_metrics.csv`, `v41_complementarity.csv`, `v41_1_cal_metrics.csv`, `v41_1_cal_fold_metrics.csv`, `v41_1_cal_block_metrics.csv`.

V41’s apparent +0.000824 advantage reversed to −0.000136, producing a **0.000960 CAL→LOCK transfer gap**—2.4 times the current +0.00040 leaderboard gap to fifth place.

### The V41 second-level dependency

V41’s `fit_stack()` generated OOF meta-features using four CAL folds. Its `fit_ranker_candidate()` then used **the same fold partition** to cross-validate LambdaRank.

Consider outer ranker validation fold `F0`. A ranker-training row in `F1` has a stack feature created by a first-level model trained on `F0+F2+F3`; similarly, a training row in `F2` was produced by a first-level model trained on `F0+F1+F3`. Therefore, although each validation row’s own stack feature was OOF, **every row used to train the second-level ranker had a feature whose construction could depend on labels from the outer validation fold**.

The validation labels did not enter the ranker directly, but they entered its training-feature generation path. That is precisely why a second-level learning stage requires either genuinely nested cross-fitting or a completely untouched final holdout. Wolpert’s original stacking formulation builds the second space from predictions made on data not used to fit the corresponding first-level learner, and nested-validation work shows why evaluation becomes optimistic when tuning/model-development stages are not re-executed inside the outer assessment loop. citeturn0search2turn0search0

V41.1 eliminated this issue. `v41_1_reproduction_audit.json` explicitly records `single_level_cal_oof=true` and `final_lambdarank_removed=true`. The clean result was no longer +0.0008; it was essentially zero.

That is strong evidence that **V41’s architecture, not merely unlucky LOCK sampling, was too optimistic**.

### Why the clean ordinal model was still flat

V41.1 correctly reduced complexity but retained a full-list target formulation. Qwen was asked to help cumulative relevance/grade estimation across all 17 modules.

The per-module result demonstrates the mismatch:

| Module | Topic | Qwen AUC | Corr. with structural | Marginal NDCG contribution |
|---|---|---:|---:|---:|
| M001 | Excel | 0.536 | −0.238 | −0.000001 |
| M002 | Python | 0.648 | 0.126 | **−0.000164** |
| M003 | SQL | 0.601 | 0.056 | −0.000045 |
| M004 | Web scraping | 0.438 | −0.005 | 0.000000 |
| M005 | Git / version control | 0.579 | 0.116 | **+0.000152** |
| M006 | Statistics | 0.672 | 0.119 | **+0.000202** |
| M007 | EDA | 0.679 | 0.346 | −0.000050 |
| M008 | Dashboard | 0.606 | 0.169 | +0.000016 |
| M009 | Machine learning | **0.748** | 0.338 | **+0.000106** |
| M010 | Computer vision | 0.626 | 0.285 | **+0.000137** |
| M011 | NLP | 0.522 | −0.027 | **−0.000101** |
| M012 | GenAI | **0.698** | 0.262 | **−0.000218** |
| M013 | Prompting | 0.518 | −0.177 | **−0.000175** |
| M014 | Automation | 0.597 | 0.090 | +0.000036 |
| M015 | No-code | 0.625 | 0.079 | +0.000041 |
| M016 | MLOps | **0.698** | 0.170 | **+0.000095** |
| M017 | Career | 0.637 | 0.138 | +0.000061 |

Sources: `v41_1_module_audit.csv` and `v41_1_module_leaveout.csv`. “Marginal contribution” is `full candidate gain − gain when that module is reverted to the structural score`; it is diagnostic, not additive.

Qwen AUC and marginal NDCG contribution correlate only about **0.207 Pearson / 0.240 Spearman**. Nine modules contribute positively, seven negatively, and one approximately zero. The sum of positive one-at-a-time marginal effects is about **+0.000847**; the magnitude of harmful effects is about **0.000754**. This is why the net result is ~zero.

That post-hoc decomposition also provides a useful pseudo-oracle lesson: there is apparently enough *conditional* semantic value to matter, but we do **not** have a validated way to identify the helpful modules at test time. Manually selecting M005/M006/M009/M010 after seeing CAL labels would simply recreate the overfitting problem.

The `module_concentration=0.2381` result is actually healthy: the positive side was not dominated by one module. The problem is **cancellation**, not one lucky module.

### Qwen versus XLM-R

V41’s module audit gives:

- Qwen mean AUC ≈ **0.6135**, median ≈ **0.6253**.
- XLM-R mean AUC ≈ **0.6301**, median ≈ **0.6361**.
- Structural↔Qwen median correlation ≈ **0.1195**.
- Structural↔XLM-R median correlation ≈ **0.4867**.

Source: `v41_module_audit.csv`.

XLM-R was modestly better as a per-module binary classifier, but far less orthogonal to the structural anchor. More importantly, QX produced **+0.000499 CAL**, below Q’s **+0.000824**, and only 3/4 folds improved. It therefore did not earn additional deployment complexity.

This is a classic ensemble lesson: the useful quantity is **conditional error complementarity**, not standalone AUC.

## Model families, ceilings, and intervention economics

### What to keep and what to drop

| Paradigm | Evidence | Decision |
|---|---|---|
| Sparse word/char TF-IDF + Ridge | Foundation of all strong anchors | **KEEP** |
| Module-specific structural calibration | Consensus3/public-positive lineage | **KEEP** |
| V25 surgical anchor logic | +0.00050 after V21.1 | **KEEP** |
| V30 residual LambdaRank | +0.00044 public with fixed α=.16 | **KEEP as frozen anchor mechanism** |
| V31 Intent-State features | Useful representation, broad deployment weaker | **KEEP as feature only** |
| Qwen3-Embedding-8B | Low correlation with structural; V21.1 public-positive | **KEEP as only semantic expert** |
| XLM-R | Higher binary AUC but redundant; QX weaker | **DROP for last experiment** |
| IndoBERT | Initial signal failed fold-pure confirmation | **DROP** |
| BGE frozen reranker | Insufficient robust gain | **DROP** |
| Seed/fold averaging | V8 public deterioration | **DROP** |
| Borda / majority voting | Historical ~0.65489 | **DROP** |
| Objective ensemble | V32 no robust winner | **DROP** |
| Rare-action selectors | V35–V39 repeatedly fail supply/transfer | **DROP** |
| Intent trajectory | V39/V39.1 closed | **DROP** |
| Prerequisite membership | V40 fresh gate negative | **DROP** |
| Dense full-list semantic stack | V41 LOCK reversal | **DROP** |
| Hierarchical ordinal full-list stack | V41.1 clean but flat | **DROP** |
| Stable-head partial ranking | Not yet isolated | **PRIORITY** |

### Exact leverage of different ranking positions

Because the label ladder is known, the NDCG sensitivity of a perfect adjacent correction can be computed directly. Averaging across the observed K distribution, one perfect correction for one of the 1,000 test users contributes approximately:

| Perfect correction | Mean per-user NDCG gain | Public-score gain from one corrected test user |
|---|---:|---:|
| 1↔2 | 0.02491 | **+0.0000249** |
| 2↔3 | 0.00884 | +0.00000884 |
| 3↔4 | 0.00468 | +0.00000468 |
| 4↔5 | 0.00577 | +0.00000577 |

A larger head mistake has much more leverage. If the true #1 is currently at #5, correcting that user can be worth roughly **+0.000162** on the leaderboard for K=5/6 and **+0.000289** for K=4. That is consistent with the observed empirical result that only three selected S3 Top1 corrections were worth about +0.00056 overall.

Membership is also theoretically high-leverage **when correct**. A perfect 5↔6 correction contributes approximately:

- K=5, where true #5=0.40 and the alternative is irrelevant: **+0.0000679 per corrected user**.
- K=6, where #5=.40 and #6=.25: **+0.0000255 per corrected user**.
- K=4: generally no gain from merely permuting irrelevant tail items.

So membership is not low-leverage mathematically. It is **low-precision empirically**.

### Candidate intervention comparison

| Family | Empirical/theoretical leverage | Evidence quality | Could plausibly add +0.00040? | Recommendation |
|---|---|---|---|---|
| **Top1 specialist** | 3 public actions ≈ **+0.00056** | Strongest public causal evidence | **Yes; only a few large corrections may suffice** | **Highest priority** |
| **Stable Top4 partial ranking, membership frozen** | 1↔2 ≈2.49e-5/user; larger moves much higher | Dataset geometry strongly supports it | **Yes, if ~15–20 clean small head corrections or a few large ones** | **Best last experiment** |
| B34-like 3↔4 | 10 actions = +0.00006 | Public causal | Need ~67 equally good actions | Too weak alone |
| B45 order | ~+0.00002 / 8 actions inferred | Weak/rounded | Would require ~160 similar actions | No |
| Membership 5↔6 | Up to 6 perfect K5 corrections could theoretically add >.00040 | High leverage but repeated low precision | Theoretically yes; empirically unlikely | No last-shot attack |
| Full-list Qwen stack | V41 LOCK −0.000136 | Direct untouched evidence | Not currently | Close |
| Hierarchical ordinal Qwen | V41.1 −0.000029 CAL | Clean evidence | No | Close |
| Qwen + XLM-R ensemble | QX < Q in CAL | Direct internal evidence | Unlikely | Drop |
| More public micro-probes | High public-overfit risk | Exhausted | Unclear | Avoid |

This is why the next experiment should **not** optimize relevant@5 or K. The remaining leaderboard economics are dominated by correctly identifying a small number of head-ranking mistakes.

The head-focused proposal is also methodologically coherent. Plackett–Luce models represent rankings through sequential choices; modern work extends them to feature-based ranking regression and to top-K/partial-ranking observations, where the top ordered segment is known but the tail need not be ordered. citeturn2search4turn2search8 That is almost exactly the MineToday label geometry we want to exploit.

## Pre-registered V41.2 blueprint

### Core hypothesis

**V41.2 — B34-Anchored Stable-Top4 Qwen Partial-Ranking Specialist**

The hypothesis is deliberately narrow:

> Qwen’s complementary semantic representation may be useful for **within-user head ordering even though it is not useful for globally recalibrating relevance**. Because ranks 1–4 are present for every user, train only on that ordered partial ranking; preserve B34’s Top5 membership and all public-proven S3 decisions.

There will be one architecture, one alpha, one semantic model, one CAL gate, and one LOCK opening.

### Data and anchor

Use exactly the same fixed high-level split as V41/V41.1:

| Split | Users | Role |
|---|---:|---|
| ADAPT | 2,400 | Qwen task adaptation only |
| CAL | 1,000 | Head-ranking residual estimation + cross-fitted validation |
| LOCK | 600 | Untouched final confirmation |
| Test | 1,000 | Used only after all gates |

Keep the exact split seed already used by V41/V41.1 so performance differences are attributable to the objective rather than a new split.

The structural anchor must be reconstructed algorithmically from organizer data:

`V3.1 sparse → calibration/Consensus3 → V25 → V30 → V31 disagreement state → selective current anchor → B34`.

No historical submission CSV may be used as a predictive input. The exact B34 hash must reproduce:

`a235d00a05cb32573ba79565d05d70e3b65928cdb413d354acb5f9b1e039730c`

before any deep model trains.

For CAL and LOCK, generate the **policy-matched analog anchor**, not merely raw V30: apply the same label-free disagreement policy that defines the test anchor—retain the fixed eligible S3 head/membership policy, reject toxic S1 behavior, and keep only the B34 order boundary. This reduces the small but real validation/deployment geometry mismatch that remained in V41/V41.1.

### Exact semantic model

No XLM-R.

Use the exact successful Qwen family already established in V41.1:

| Parameter | Fixed value |
|---|---|
| Model | `Qwen/Qwen3-Embedding-8B` |
| Revision | `1d8ad4c` |
| Quantization | 4-bit NF4, double quantization |
| Compute dtype | FP16 |
| Semantic dimension | 1,024 |
| Query max length | 160 |
| Module max length | 224 |
| LoRA layers | Last 8 transformer layers |
| LoRA projections | q/k/v/o |
| LoRA rank | 8 |
| LoRA alpha | 16 |
| LoRA dropout | 0.05 |
| Learning rate | 5e-5 |
| Weight decay | 0.01 |
| Epochs | **1** |
| Batch size | 4 |
| Gradient checkpointing | On |

These values come directly from the V41.1 notebook configuration; the previous run successfully trained about 1.70M trainable parameters out of ~7.57B total and completed one Qwen epoch. fileciteturn0file0

### Replace the Qwen loss with stable-Top4 partial ranking

Do **not** train Qwen on full-list relevance BCE or cumulative ordinal relevance.

For each ADAPT user, identify the true ordered top four modules:

\[
m_1 \succ m_2 \succ m_3 \succ m_4
\]

Everything else is treated as an unordered tail.

Optimize a weighted partial Plackett–Luce loss:

\[
\mathcal L_u
=
-\sum_{r=1}^{4}
w_r
\log
\frac{\exp(s_{u,m_r}/T)}
{\sum_{j \notin \{m_1,\ldots,m_{r-1}\}}
\exp(s_{u,j}/T)}
\]

with no supervision over relative ordering inside the tail.

Use fixed position weights derived from relevance × NDCG discount:

\[
w =
[1.0000,\ 0.5363,\ 0.3500,\ 0.2369]
\]

and fixed temperature `T=0.075`, inherited from the existing Qwen semantic loss scale.

This changes only **what Qwen is asked to learn**, not its architecture or training budget.

### Low-capacity head residual model

After Qwen is frozen, CAL learns one global hierarchical partial-ranking model. There is no second LambdaRank, no binary relevance head, and no ordinal stack.

Per `(user,module)` features:

- row-standardized structural anchor score;
- row-standardized Qwen semantic score;
- Qwen minus anchor standardized score;
- anchor rank;
- readiness;
- latest-intent indicator;
- semantic-availability indicator;
- module intercept;
- one module-specific deviation on the Qwen coefficient.

The model is intentionally tiny: global coefficients plus 17 module intercepts and 17 Qwen deviations. Module deviations receive substantially stronger L2 shrinkage than global coefficients.

Pre-register:

- global L2 = `0.01`;
- module intercept/deviation L2 = `0.10`;
- optimizer = deterministic L-BFGS;
- max iterations = `200`;
- convergence tolerance = `1e-7`;
- no hyperparameter search.

### Deployment must freeze Top5 membership

This is crucial.

For each eligible user:

1. Take the five modules already inside the B34 anchor Top5.
2. Compute head residual preference scores only for those five.
3. Align the residual score vector to the anchor’s within-Top5 mean/std.
4. Blend with fixed:

\[
\alpha=0.16.
\]

5. Use the blended signal only to choose a new permutation of those five modules.
6. Reassign the **original five B34 score levels** to the new order.

Therefore:

- Top5 membership cannot change.
- Scores outside Top5 cannot cross the cutoff.
- The model can promote the anchor’s #5 into the head if strongly warranted.
- It can fix Top1/Top2/Top3/Top4 order.
- It cannot invent a new module from outside the current membership set.

This directly removes one of V41’s largest failure surfaces: 12/29 LOCK changes were membership changes.

S1 and S3 remain **fully frozen**. Only S0+S2 are eligible. The exact 10 B34 test rows and all public-proven S3 decisions remain immutable.

### Validation

Proper stacking requires level-one predictions to be generated out of sample; evaluation after model development must isolate all fitting/model-selection decisions from the outer assessment set. citeturn0search2turn0search0 V41.2 therefore uses a strictly nested audit even though the residual model is small.

For CAL:

- Five fixed outer folds, stratified by true Top1 module.
- For each outer fold:
  - the outer validation users are completely untouched;
  - split outer-train into four inner folds;
  - fit four hierarchical PL models, each leaving out one inner fold;
  - average their predictions on the outer validation set.
- No fold-specific result changes any hyperparameter.
- Full CAL metrics are assembled only from outer-held-out predictions.

The inner loop is therefore used as cross-fitted coefficient bagging/stability control, not hyperparameter selection.

After CAL passes, train the five outer-fold models on their respective 80% CAL subsets and **average those five models** on LOCK. Do not fit a new “full-CAL” model after observing LOCK. The same five-model ensemble predicts test after a LOCK pass. This preserves validation-to-deployment training geometry and retains the V41.1 principle of no post-LOCK retraining.

### Diagnostics and gates

CAL must emit:

- NDCG@5;
- Top1 accuracy;
- B12/B23/B34/B45/B56 pair accuracy;
- relevant@5, even though membership is fixed;
- five outer-fold deltas;
- five contiguous-ID quintile deltas;
- user bootstrap CI;
- block bootstrap CI;
- module leave-one-out contributions;
- module relevance density;
- Qwen AUC and pairwise-head accuracy;
- K predictability diagnostic;
- test-free coefficient stability.

For block bootstrap, divide CAL into 20 ordered-ID blocks of 50 CAL users and resample blocks with replacement. This is stronger than ordinary IID bootstrap when local ID dependence may exist. The ordered train/test structure makes this a useful stress test, though it does not prove actual covariate shift. citeturn2search1

Preregister the CAL gate:

| Requirement | Threshold |
|---|---:|
| CAL ΔNDCG | **≥ +0.00060** |
| Positive outer folds | **≥ 4/5** |
| Positive contiguous quintiles | **≥ 3/5** |
| User-bootstrap 95% CI lower bound | **≥ −0.00025** |
| Block-bootstrap 95% CI lower bound | **≥ −0.00035** |
| Top1 accuracy delta | **≥ 0** |
| Mean head-boundary improvement B12–B34 | **> 0** |
| Membership changes | **exactly 0** |
| Largest positive module concentration | **≤ 0.50** |

If CAL fails, **LOCK is never evaluated**.

Preregister the LOCK gate:

| Requirement | Threshold |
|---|---:|
| LOCK ΔNDCG | **≥ +0.00030** |
| Positive contiguous quintiles | **≥ 3/5** |
| User-bootstrap lower bound | **≥ −0.00050** |
| Block-bootstrap lower bound | **≥ −0.00060** |
| Top1 delta | **≥ 0** |
| Membership changes | **0** |

No threshold may be modified after seeing CAL or LOCK.

### Test leverage gate

Do not demand an arbitrary minimum number of changed users.

Instead, calculate a label-free **maximum theoretical leverage implied by the test permutation geometry**. For every changed test row, compute the maximum NDCG improvement that its observed position movement could possibly yield under the known relevance ladder, average over allowed K states, and sum across 1,000 users.

Classify the candidate:

- `VALID_BUT_LOW_LEVERAGE` if all statistical gates pass but theoretical maximum movement cannot reach **+0.00040**.
- `SUBMISSION_SCALE` only if the movement geometry has at least **+0.00040 theoretical headroom**.

Safety caps:

- membership changes = **0 by construction**;
- S1/S3 changed users = **0**;
- Top1 changed users ≤ **20**;
- total head-order changed users ≤ **120**.

This avoids both extremes: another V39-style candidate with too little mathematical upside, and a V41-style broad reranker that touches too much surface.

```mermaid
flowchart TD
    A[Organizer train/chat/assessment/modules] --> B[Exact structural reconstruction]
    B --> C{B34 hash and S0-S3 geometry exact?}
    C -- No --> Z[Abort / fail-close]
    C -- Yes --> D[Fixed split: ADAPT 2400 / CAL 1000 / LOCK 600]

    D --> E[ADAPT: Qwen3-Embedding-8B QLoRA]
    E --> F[Stable Top4 partial Plackett-Luce loss]
    F --> G[Freeze Qwen]

    D --> H[CAL: exact policy-matched structural anchor]
    G --> I[Qwen semantic scores]
    H --> J[Five outer CAL folds]
    I --> J

    J --> K[Four inner PL fits per outer fold]
    K --> L[Strict outer-held-out predictions]
    L --> M[CAL NDCG + Top1 + boundary metrics]
    M --> N[User bootstrap + block bootstrap]
    N --> O[Leave-one-module-out + concentration + K audit]

    O --> P{CAL gate passes?}
    P -- No --> Z

    P -- Yes --> Q[Five CAL fold models predict untouched LOCK]
    Q --> R{LOCK gate passes?}
    R -- No --> Z

    R -- Yes --> S[Predict test]
    S --> T[Freeze B34 membership; reorder anchor Top5 only]
    T --> U[Test geometry + leverage upper bound]

    U --> V{Submission-scale and safety gates pass?}
    V -- No --> Z
    V -- Yes --> W[submission_v41_2_primary.csv]

    Z --> X[Primary remains exact B34 0.66026]
```

## Go/no-go, risk, runtime, and deliverables

### Final recommendation

**GO for exactly one V41.2 experiment.**

But the GO is conditional on one strategic rule:

> **V41.2 must be a stable-head partial-ranking experiment, not another full-list ensemble iteration.**

I would explicitly **NO-GO** all of the following as the “last experiment”:

- Qwen + XLM-R averaging;
- another LambdaRank layer;
- another cumulative-ordinal stack;
- another membership selector;
- another prerequisite/trajectory filter;
- hand-selecting modules from V41.1’s leave-one-out table;
- tuning alpha against CAL;
- public-testing several module masks.

The rationale is now unusually strong. V41.1 is clean enough to close full-list Qwen calibration. V39.5 is causal enough to show where leaderboard leverage exists. The target-label geometry explains why the two findings coexist.

### Risk assessment

| Risk | Severity | Why it matters | Mitigation |
|---|---|---|---|
| Qwen semantics still fail at within-user head ordering | **High** | V41.1 shows binary/module AUC does not imply NDCG utility | Change training objective to partial Top4 ranking itself |
| Anchor Top5 excludes true Top1 | **Medium–high** | Membership freeze limits reachable corrections | Accept intentionally; membership selection has repeatedly failed |
| CAL block instability persists | **High** | V41.1 had only 2/5 positive ID blocks | Mandatory block-bootstrap + quintile gate |
| Residual model overfits 1,000 CAL users | **Medium** | Small dataset | <40 effective parameters, strong partial pooling, nested OOF |
| Public B34 already overfit to visible LB | **Medium** | Many historical probes | Treat B34 as immutable prior; no new public subgroup mining |
| Head model changes too few rows | **Medium** | Could be statistically valid but competition-useless | Theoretical leverage gate |
| Head model changes too many rows | **Medium** | Could destroy strong anchor | ≤20 Top1 / ≤120 total head-order safety caps |
| GPU stochasticity | **Low–medium** | Reproducibility requirement | Fixed seeds, deterministic CUDA settings, one GPU training path |
| Model/package download failure | **Low with Internet ON** | Qwen requires large model pull unless cached | Internet ON, exact revision, optional cache reuse |

My decision-theoretic probability ranges are:

| Outcome | Subjective probability before run |
|---|---:|
| V41.2 discovers a stable positive head residual | **30–45%** |
| Produces any positive public Δ if submitted through gates | **30–45% unconditional** |
| Reaches at least +0.00020 | **20–30% unconditional** |
| Reaches +0.00040 / current Top-5 threshold | **15–25% unconditional** |
| Positive public transfer conditional on CAL+LOCK pass | **60–75%** |
| ≥+0.00040 conditional on CAL+LOCK pass | **35–50%** |

These are judgment ranges, not frequentist probabilities. A 100% guarantee would be indefensible given the hidden test relevance and the observed validation variance.

### Kaggle runtime plan

The current V41.1 package lock is:

| Package | Version |
|---|---|
| Python | 3.12.13 |
| NumPy | 2.0.2 |
| pandas | 2.3.3 |
| SciPy | 1.16.3 |
| scikit-learn | 1.6.1 |
| LightGBM | 4.6.0 |
| PyTorch | 2.10.0+cu128 |
| Transformers | 4.57.6 |
| PEFT | 0.18.1 |
| bitsandbytes | 0.48.2 |

Source: `v41_1_package_versions.json`.

Use **Kaggle T4×2, Internet ON**. For determinism, pin the 4-bit Qwen training to **GPU 0 exactly as V41.1 did**; do not introduce DDP merely to consume the second T4. The second GPU can remain unused/reserved. The existing implementation proved that Qwen3-Embedding-8B QLoRA fits and trains on one T4 in 4-bit form. The failed first V41.1 execution shows the Qwen epoch completing after roughly 56 minutes from model setup, so a realistic end-to-end budget is approximately **70–90 minutes with model download/cache variation**, with the classical partial-ranking stage adding relatively little compute. fileciteturn0file0

```mermaid
timeline
    title V41.2 Kaggle execution schedule
    section Preflight
      Package and seed audit : exact versions
      Anchor reconstruction : B34 hash and 9/10/8 boundary check
    section ADAPT
      Qwen load and LoRA setup : Internet ON / GPU0
      One stable-Top4 PL epoch : roughly one hour
    section CAL
      Nested five-by-four cross-fitting : CPU
      Fold/block/bootstrap/module audits : CPU
    section Gate
      CAL pass required : otherwise fail-close
      Untouched LOCK evaluation : only after CAL pass
    section Final
      Test head permutation : only after LOCK pass
      Geometry and leverage gate : fail-close or submission CSV
```

### Reproducibility checklist

The final Kaggle notebook should hard-fail unless all of these are true:

- Organizer-provided files only; no external labeled data.
- Exact fixed random seeds recorded at the top of the notebook.
- Exact Qwen model ID **and revision** pinned.
- Exact package versions exported to JSON.
- Internet ON recorded in the run instructions.
- T4×2 selected; Qwen pinned deterministically to GPU0.
- B34 Top5 hash reproduced before deep training.
- V30/V31 state counts reproduce `897/26/43/34`.
- S3 order decomposition reproduces `B23=9 / B34=10 / B45=8`.
- No historical submission CSV is used as a predictive input.
- No user-ID numeric feature is used for prediction.
- No test relevance labels or GenAI-generated pseudo-labels are used.
- ADAPT/CAL/LOCK manifest exported and unchanged.
- Qwen sees **ADAPT labels only**.
- CAL outer-validation labels cannot influence any model used to predict that outer fold.
- LOCK remains untouched until CAL passes.
- No hyperparameter, module mask, threshold, or alpha changes after CAL.
- No post-LOCK retraining.
- S1 and S3 test rows are byte-identical to B34.
- Test Top5 membership is identical to B34 for **all 1,000 users**.
- Primary submission is the candidate only when every gate passes; otherwise it is exact B34.
- The notebook-generated submission hash is exported.
- Final CSV shape, user order, finite scores, and TM submission format are asserted.

The organizer documentation previously cited for this project requires reproducible notebook predictions/seed handling and permits open-source pretrained ML models while prohibiting direct GenAI generation of hidden test relevance. fileciteturn33file18 The competition metric is NDCG, so both relevance and rank position matter; that is exactly why the proposed experiment changes the objective from binary relevance to ordered partial-head likelihood. fileciteturn33file17

### Required deliverables

The notebook should emit all of the following even if it fails its gate:

| Artifact | Purpose |
|---|---|
| `MineToday_V41_2_B34_StableTop4_Qwen_PL.ipynb` | Fully reproducible Kaggle notebook |
| `submission_v41_2_b34_anchor_reference.csv` | Exact 0.66026 fail-close reference |
| `submission_v41_2_candidate_DIAGNOSTIC.csv` | Candidate regardless of final gate, clearly diagnostic |
| `submission_v41_2_primary.csv` | Candidate only when all gates pass; otherwise B34 |
| `v41_2_summary.json` | Final decision and hashes |
| `v41_2_reproduction_audit.json` | V30/V31/B34/state/boundary reconstruction |
| `v41_2_package_versions.json` | Environment lock |
| `v41_2_split_manifest.csv` | ADAPT/CAL/LOCK membership |
| `v41_2_training_history.csv` | Qwen loss and runtime |
| `v41_2_cal_metrics.csv` | Aggregate CAL metrics |
| `v41_2_cal_outer_fold_metrics.csv` | Strict outer OOF results |
| `v41_2_cal_inner_stability.csv` | Inner-fold coefficient/prediction stability |
| `v41_2_cal_block_metrics.csv` | Ordered-ID quintile diagnostics |
| `v41_2_cal_user_bootstrap.csv` | IID paired bootstrap summary |
| `v41_2_cal_block_bootstrap.csv` | Ordered-block bootstrap summary |
| `v41_2_lock_metrics.csv` | Untouched LOCK result |
| `v41_2_lock_block_metrics.csv` | LOCK contiguity diagnostics |
| `v41_2_head_boundary_audit.csv` | Top1, B12, B23, B34, B45, B56 effects |
| `v41_2_module_audit.csv` | Per-module density, Qwen quality and residual effects |
| `v41_2_module_leaveout.csv` | Diagnostic concentration only |
| `v41_2_k_predictability_audit.csv` | Reproduce the 4/5/6 predictability question |
| `v41_2_k_covariate_audit.csv` | K vs chat/assessment covariates |
| `v41_2_test_geometry.csv` | Changed users, Top1 changes, membership=0 assertion |
| `v41_2_leverage_budget.csv` | Label-free theoretical maximum movement leverage |
| `v41_2_tm_compliance.json` | Organizer-data / model / reproducibility assertions |

The existing V41.1 bundle already provides the right failure-analysis template: `v41_1_summary.json`, reproduction audit, CAL fold/block metrics, complementarity, module audit, leave-one-module-out, ordinal-head audit, package versions, split manifest, training history, test geometry, and the three fail-close submission CSVs. Its one important omission for this post-mortem is **per-module target density and the preserved K-predictability/covariate diagnostic**, which V41.2 should explicitly add.

**Final decision: GO V41.2, but only as the Stable-Top4 partial-ranking specialist described above.** If its clean CAL gate fails, or CAL passes but untouched LOCK does not, the correct conclusion is not to build V41.3. At that point the evidence would be strong enough to say that the remaining learnable head residual cannot be extracted reliably with the available organizer data, and **0.66026 B34 should remain the final reproducible submission**.