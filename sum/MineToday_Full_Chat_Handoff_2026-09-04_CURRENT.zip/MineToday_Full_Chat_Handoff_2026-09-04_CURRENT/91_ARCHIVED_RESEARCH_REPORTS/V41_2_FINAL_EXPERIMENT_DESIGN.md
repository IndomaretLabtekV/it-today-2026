# V41.2 Final Experiment Design: Full Audit, Dataset Diagnosis, and the Last High-Leverage Bet

## Executive summary

After re-auditing the experimental lineage, directly inspecting the available V40, V41, and V41.1 artifacts, re-checking the dataset geometry encoded in the production notebooks, and separating **what is actually demonstrated** from what we had only hypothesized, my conclusion is:

> **We are not completely stuck, but the current full-list residual/semantic-ensemble paradigm is saturated.**
>
> **The one remaining experiment I would still justify is V41.2: a B34-anchored, Head-4 pairwise preference model that trains on the stable Top-4 ranking problem but is allowed to deploy only high-confidence Top-1 corrections.**

I would **not** build a full Plackett–Luce Top-4 reranker, another ordinal stack, another LambdaRank, another Qwen/XLM-R ensemble, another membership selector, or another public subgroup probe.

The key distinction is that V41.2 would no longer try to produce “better scores for 17 modules.” It would answer a much narrower question:

> **Among the four modules that B34 already places at the head of a user's ranking, is there overwhelming evidence that one of ranks 2–4 should actually be rank 1?**

That is the most attractive remaining intervention because all 4,000 training users have at least four positive modules: the observed positive-module counts are exactly `K=4: 1,362`, `K=5: 1,285`, and `K=6: 1,353`. Therefore target ranks 1–4 exist for every training user, whereas the lower cutoff inherently has less supervision. The production lineage also reconstructs the exact B34 anchor and current state geometry reproducibly. fileciteturn0file0

More importantly, the NDCG discount makes this economically rational. With the exact metric used by the notebook,

\[
D_1=1,\quad
D_2=0.63093,\quad
D_3=0.5,\quad
D_4=0.43068,\quad
D_5=0.38685
\]

so the positional difference between ranks 1 and 2 is `0.36907`, versus only `0.06932` between ranks 3 and 4 and `0.04382` between ranks 4 and 5. A 1↔2 correction therefore has roughly **5.32× the positional leverage of 3↔4 and 8.42× that of 4↔5**, before user-specific IDCG and relevance differences.

That matches the strongest piece of public evidence in the lineage: the historical three S3 Top-1 corrections were associated with roughly **+0.00056**, while 10 B34 order actions yielded only **+0.00006**, B23 was negative, and the inferred B45 effect was essentially flat. The exact B34 public anchor is `0.66026`, leaving approximately `+0.00040` to the current Top-5 threshold you provided.

The final architecture I recommend is therefore:

```mermaid
flowchart LR
    A[B34 exact anchor<br/>0.66026] --> B[Anchor Top-4 only]
    C[Structural evidence<br/>V30 / V31 / Consensus features] --> D
    E[Qwen3-Embedding-8B<br/>ADAPT only] --> D
    B --> D[Transitive Head-4<br/>Bradley-Terry / PL utility model]

    D --> F{High-confidence<br/>challenger beats anchor #1?}

    F -->|No| G[Exact B34 row]
    F -->|Yes + p >= 0.80<br/>+ fold stability| H[Promote challenger to #1]

    H --> I[Permute existing<br/>Top-4 score values only]
    G --> J[Final candidate]
    I --> J

    J --> K[Ranks 5-17 untouched<br/>Top-4 membership untouched]
```

The breakthrough is not a larger model. It is the **action space**:

**train densely on Top-4 preferences → abstain aggressively → spend risk only on Top-1.**

Probabilistic ranking models such as Plackett–Luce naturally support top-\(K\) ranking observations, while pairwise “rank breaking” can retain strong statistical efficiency under PL assumptions; there is also established ranking literature on abstaining when pairwise preferences are insufficiently certain. citeturn12academia33turn12search3turn12search1

**Recommendation: RUN V41.2, but only this restricted design.** If its CPU-only oracle feasibility test or CAL gate fails, stop immediately and retain B34. If it reaches LOCK and LOCK fails, the correct conclusion is that we really have exhausted the defensible modeling avenues for this public leaderboard.

There is also an operational caveat: it is now **September 3, 2026 in WIB**, and a secondary event listing reports MineToday Kaggle submissions as August 12–September 2, with notebook collection September 3–7. The official IT TODAY page confirms MineToday as the event's Data Mining & Data Science competition, but I did not find the detailed submission dates on the organizer's official page itself. Therefore, burn the GPU hour only if the Kaggle competition interface still accepts the entry; otherwise the rational action is to freeze B34 and focus on the reproducible notebook deliverable. citeturn12search0turn12search9

## What the V1–V41.1 lineage actually proves

There is an important evidence boundary. I can directly inspect the current V40, V41, and V41.1 notebooks/results. The earlier V1–V39 lineage is represented through the frozen reconstruction logic, public constants embedded in those notebooks, and the experiment record from this conversation; I do **not** currently have a complete direct artifact bundle for every individual V1–V39 notebook. Therefore I would not pretend every historical offline statistic has been independently re-derived tonight.

What *is* remarkably consistent is the progression of ideas.

| Experimental family | What it tested | What the lineage tells us | V41.2 consequence |
|---|---|---|---|
| Early sparse / TF-IDF / Ridge | lexical learner signal | Remains a valuable foundation | **Keep as structural evidence** |
| Per-module calibration / Consensus3 | module-specific trust | Strong, durable improvement | **Keep philosophy** |
| Early listwise / boosting variants | full-ranking replacement | Did not beat calibrated anchor robustly | **Do not restart** |
| Seed/fold averaging | variance reduction | Smoother predictions did not imply better LB geometry | **No generic bagging** |
| Borda / rank voting | democratic ensemble | Too coarse for graded NDCG | **Reject** |
| V13-style stacking | learned combination | Revealed second-level validation risk | **Single-level validation only** |
| Qwen semantic lineage | independent semantic information | Some genuine complementarity/public signal | **Keep Qwen only as evidence** |
| V25 | surgical corrections | Sparse high-quality changes can transfer | **Keep conservative deployment** |
| V30 | residual LambdaRank | Public-positive residual model | **Preserve anchor lineage, not another LTR layer** |
| V31 | Intent-State structural residual | Useful diagnostic representation, but broad deployment weakened | **Feature only** |
| V32 | objective diversity | XE/YetiRank/LambdaRank diversity was insufficient | **No loss-function ensemble** |
| Transformer residual selectors | semantic judgement of rare actions | Signal existed but selection/generalization unstable | **Do not predict “action utility”** |
| V39 / V39.1 | trajectory / pairwise residual | Almost no robust actionable supply | **Close branch** |
| V39.5 | S3 order decomposition | B23 toxic, B34 tiny-positive, B45 flat-ish | **Freeze B34** |
| V40 | prerequisite-aligned membership | Structural story failed fresh validation | **Close membership branch** |
| V41 | Structural + Qwen + XLM-R stack + LTR | CAL looked strong, untouched LOCK reversed | **Too layered; XLM-R unnecessary** |
| V41.1 | Qwen + hierarchical ordinal residual | Clean CAL itself was flat/negative | **Close full-list semantic calibration** |

The public progression has also become brutally compressed. Frozen notebook constants record examples such as V25 `0.65919`, V30 `0.65963`, current pre-B34 anchor `0.66020`, B23 `0.65998`, B34 `0.66026`, with rank-5 reference `0.66066`. The V40/V41.1 reconstruction explicitly verifies the B34 geometry and exact hash. fileciteturn0file0

The pattern is clear:

```mermaid
flowchart LR
    A["Sparse / calibrated foundation"] --> B["Consensus3"]
    B --> C["V25<br/>surgical"]
    C --> D["V30<br/>residual LTR"]
    D --> E["Current anchor<br/>0.66020"]
    E --> F["B34<br/>0.66026"]

    D -. "V31 broad residual<br/>weakens public" .-> X1["Closed"]
    E -. "V39 trajectory<br/>no supply" .-> X2["Closed"]
    E -. "B23<br/>-0.00022" .-> X3["Closed"]
    E -. "B45<br/>~flat" .-> X4["Closed"]
    F -. "V40 membership<br/>fresh fail" .-> X5["Closed"]
    F -. "V41 stack<br/>LOCK -0.000136" .-> X6["Closed"]
    F -. "V41.1 ordinal<br/>CAL -0.000029" .-> X7["Closed"]

    F --> Y["V41.2<br/>Head-4 learning<br/>Top-1-only deployment"]
```

The key conclusion is **not** “machine learning no longer works.” It is narrower:

> **Continuous full-list score modification has reached a point where new information is as likely to disturb correct geometry as to repair incorrect geometry.**

V41 demonstrates that vividly. Its Structural+Qwen candidate gave CAL `+0.000824` with 4/4 fold wins, yet on untouched LOCK it produced `-0.000136`, with 29 changed users and 12 membership changes. The candidate slightly improved LOCK Top-1 accuracy but reduced relevant@5. The extra ranking layer had enough freedom to turn useful semantic information into unstable downstream decisions.

V41.1 removed the final LambdaRank and fixed the validation dependency. Yet the cleaner experiment reported:

| V41.1 CAL metric | B34/structural | HORD-Q | Delta |
|---|---:|---:|---:|
| NDCG@5 | 0.664559 | 0.664530 | **−0.000029** |
| Top-1 accuracy | 0.498 | 0.496 | **−0.002** |
| Relevant modules @5 | 2.845 | 2.846 | +0.001 |
| B12 accuracy | 0.720 | 0.714 | −0.006 |
| B23 accuracy | 0.653 | 0.647 | −0.006 |
| B34 accuracy | 0.682 | 0.684 | +0.002 |
| B45 accuracy | 0.719 | 0.720 | +0.001 |
| B56 accuracy | 0.737 | 0.730 | −0.007 |
| Bootstrap CI |  |  | **[−0.000996, +0.000923]** |

Source: direct `v41_1_cal_metrics.csv`.

The fold pattern makes the rejection stronger, not weaker:

| CAL fold | V41.1 ΔNDCG |
|---:|---:|
| 0 | **+0.001247** |
| 1 | **−0.000856** |
| 2 | **−0.000152** |
| 3 | **−0.000566** |
| 4 | **+0.000184** |

Only 2/5 random folds and 2/5 contiguous-ID blocks were positive. Because CAL already failed, LOCK was correctly never opened.

Likewise, V40 was not a missed opportunity caused by a harsh gate. Its fresh prerequisite membership family selected 17 actions with mean action delta `−0.03066` and six harmful actions; world G was particularly poor at `−0.10178`. Source: `v40_fresh_structural_summary.csv` and `v40_summary.json`.

So several branches can now be closed with high confidence:

**membership optimization, trajectory, generic prerequisite logic, whole-list Qwen calibration, XLM-R stacking, another LambdaRank stage, objective ensembles, and order-boundary micro-mining.**

That is progress. It removes most of the search space.

## Where the dataset still has learnable headroom

The strongest dataset fact is simpler and more robust than our earlier speculation about whether \(K\) is random.

The production log reports:

| Positive modules per user | Users |
|---|---:|
| 4 | 1,362 |
| 5 | 1,285 |
| 6 | 1,353 |
| **Total** | **4,000** |

There are 17 modules, 4,000 train users, and 1,000 test users. Every user therefore has **at least four positive modules**, meaning target positions 1, 2, 3, and 4 are present for every training user. fileciteturn0file0

The corresponding ordinal-grade counts in the production run are particularly revealing:

- grade corresponding to rank 1: **4,000**
- rank 2: **4,000**
- rank 3: **4,000**
- rank 4: **4,000**
- rank 5: **2,638**
- rank 6: **1,353**
- zero: **48,009**

That means the head is the only part of the relevance ranking where we have full user coverage.

I would **not** rely on the earlier claim that \(K\) itself is unlearnable: the dedicated K-predictability output is not present in the currently retrievable V40–V41.1 artifact bundle, so that point is **unspecified rather than established**. Fortunately, V41.2 does not require it. Whether \(K\) is predictable or not, the Top-4 supervision remains fully observed.

### The semantic evidence is useful but misaligned

V41.1 also clarifies why another semantic stack would be a mistake.

Its Qwen module audit is:

| Module | Qwen AUC | Corr. Qwen–structural | Approx. signed residual contribution |
|---|---:|---:|---:|
| M001 | 0.536 | −0.238 | −0.000001 |
| M002 | 0.648 | 0.126 | **−0.000164** |
| M003 | 0.601 | 0.056 | −0.000045 |
| M004 | 0.438 | −0.005 | 0 |
| M005 | 0.579 | 0.116 | **+0.000152** |
| M006 | 0.672 | 0.119 | **+0.000202** |
| M007 | 0.679 | 0.346 | −0.000050 |
| M008 | 0.606 | 0.169 | +0.000016 |
| M009 | **0.748** | 0.338 | **+0.000106** |
| M010 | 0.626 | 0.285 | **+0.000137** |
| M011 | 0.522 | −0.027 | −0.000101 |
| M012 | **0.698** | 0.262 | **−0.000218** |
| M013 | 0.518 | −0.177 | **−0.000175** |
| M014 | 0.597 | 0.090 | +0.000036 |
| M015 | 0.625 | 0.079 | +0.000041 |
| M016 | **0.698** | 0.170 | +0.000095 |
| M017 | 0.637 | 0.138 | +0.000061 |

Sources: direct `v41_1_module_audit.csv` and `v41_1_module_leaveout.csv`.

Across the 17 modules, Pearson correlation between Qwen AUC and the signed leave-one-module contribution is only about **0.21** in this diagnostic. In other words, being good at the column-wise question—

> “Which users find module M012 relevant?”

—does not reliably answer the row-wise NDCG question—

> “For this particular user, should M012 outrank M006?”

That is exactly why V41.2 must switch from **module-wise calibration** to **within-user preference modeling**.

```mermaid
xychart-beta
    title "V41.1 signed module contribution to residual gain (×10⁴)"
    x-axis [M006,M005,M010,M009,M016,M017,M015,M014,M008,M004,M001,M003,M007,M011,M002,M013,M012]
    y-axis "Contribution ×10⁴" -2.5 --> 2.5
    bar [2.016,1.525,1.375,1.060,0.954,0.612,0.414,0.357,0.156,0,-0.008,-0.448,-0.503,-1.009,-1.639,-1.748,-2.181]
```

There is another reason to focus on the head: the metric itself.

For an adjacent ordering mistake, the positional discount gaps are:

| Boundary | Discount gap | Relative to 4↔5 |
|---|---:|---:|
| **1↔2** | **0.36907** | **8.42×** |
| 2↔3 | 0.13093 | 2.99× |
| 3↔4 | 0.06932 | 1.58× |
| 4↔5 | 0.04382 | 1.00× |

That does **not** mean every Top-1 correction is worth 8.42× every membership correction, because relevance differences and IDCG matter. It means the metric places dramatically more positional leverage near the head.

And the public probes tell the same story empirically: the historical Top-1 package is the only tiny intervention family that has demonstrated leaderboard-scale movement. The order-only families have not.

### One diagnostic V41.2 must perform before touching the GPU

Because this is the final experiment, V41.2 should start with an **oracle feasibility stage**.

On CAL using a deployment-like structural anchor, compute:

1. **True Top-1 coverage inside anchor Top-4:** how often is the real best module already somewhere in B34's Top-4?
2. **Top-1-within-Top4 oracle:** if an oracle could promote the correct module from B34 ranks 2–4 to #1 while changing nothing else, how much NDCG would that gain?
3. **Full Top-4 permutation oracle:** if the four existing B34 head modules could be optimally ordered, what is the upper bound?
4. **Recoverable Top-1 mistakes:** number of users where B34's Top-1 is wrong but the true Top-1 is already inside B34 Top-4.
5. **Qwen complementarity oracle:** when B34 Top-1 is wrong, how often does Qwen put the correct choice above the current #1 within the existing Top-4?

These exact oracle numbers are **not present in the current artifacts**, so they are unspecified. That is precisely why they should be the first V41.2 output.

I would terminate V41.2 before Qwen training if the **Top-1-within-Top4 oracle CAL delta is below roughly +0.0010**. We need `+0.00040` publicly; if the complete action space itself has less than about 2.5× that headroom offline, expecting a learned selective policy to extract enough of it is not rational.

## Choosing among the three V41.2 architectures

The three proposed designs are not equally attractive after V41.1.

| Design | Statistical efficiency | Public leverage | Overfit risk | T4×2 cost | Reproducibility | Final verdict |
|---|---|---|---|---|---|---|
| **A. Top1 specialist + conditional Top2–4** | High | **Very high at Top1** | Low–medium | Medium | High | **Best, but deploy Top1 only** |
| B. Joint hierarchical / Plackett–Luce Top4 | Very high | Medium–high theoretically | **Medium** | Medium | High | Useful research, too risky for last submission |
| C. Top1 classifier + ordinal residual ranks2–4 | Medium | High + low-rank mix | **Medium–high** | Medium | Medium–high | Reject; inherits V41.1 failure mode |

My recommended design is therefore a refinement of A:

> **A\*: train a Head-4 transitive preference model, but deploy only Top-1 interventions.**

### Why not a plain 17-class Top1 classifier?

A 17-class classifier would have 4,000 Top-1 labels and would be much cleaner than rare action selection. But it still asks a harder global question than necessary.

B34 has already done most of the candidate discovery.

Instead of:

\[
P(m=\text{Top1}\mid u),\quad m\in 17
\]

V41.2 should solve:

\[
P(a\succ b\mid u),\quad a,b\in \text{B34 Top4}(u)
\]

with a utility model

\[
P(a\succ b)=
\sigma\!\left(u_\theta(u,a)-u_\theta(u,b)\right).
\]

This Bradley–Terry/Plackett–Luce-style parameterization ensures the pair probabilities originate from a common module utility, instead of training six unrelated pair classifiers that can form contradictory cycles.

PL methods are a natural model for top-\(K\) rankings; work on partial rankings also shows that decomposing ranked observations into pairwise comparisons can retain favorable statistical behavior under PL-type assumptions. citeturn12academia33turn12search3

For a Top-4 set there are at most:

\[
{4\choose2}=6
\]

head comparisons per user.

That yields up to:

- **6,000 pair observations from 1,000 CAL users**, and
- far denser supervision than the rare beneficial-action labels that doomed trajectory/residual selectors.

Tied-relevance pairs should simply be discarded rather than assigned arbitrary order.

### Why train Top-4 if only Top-1 is deployed?

Because the lower head comparisons act as **representation supervision**, not necessarily deployment actions.

The model gets to learn statements like:

> SQL > CV for this learner,

> Python > MLOps,

> EDA > Stats,

across many users, even when those comparisons are not rank #1 decisions.

But at deployment, we only spend that learned information where NDCG leverage is greatest.

This is a critical distinction:

> **Top2–4 provide training signal; Top1 receives deployment authority.**

### Why not deploy the entire PL Top-4 order?

Because our own empirical prior argues against it.

The public S3 order decomposition showed:

- B23: negative;
- B34: tiny positive;
- B45: essentially flat.

So allowing a new model to reorder all Top-4 positions introduces actions in precisely the boundaries whose public marginal value has been weak or adverse.

A listwise PL model is statistically elegant, but this is a competition decision, not a ranking-theory paper.

### Why not the hybrid ordinal option?

Because V41.1 just conducted the cleanest test we have of that basic idea.

It used a partially pooled six-head ordinal stack, fixed alpha, true single-level CAL OOF, no final LambdaRank, no post-LOCK retraining—and it still produced `−0.000029`.

Reintroducing ordinal prediction for positions 2–4 immediately after that result would not be a new hypothesis. It would be relabeling a failed hypothesis.

## The recommended V41.2 blueprint

I would name it:

> **V41.2 — B34-Anchored Head4 Preference Specialist with Abstaining Top1 Deployment**

This is intentionally a V41.2 rather than V42: it keeps the useful component of the V41 semantic branch—Qwen as independent evidence—but radically changes **how that evidence is extracted and allowed to act**.

### Fixed data protocol

Reuse the exact V41/V41.1 split:

| Split | Users | Purpose |
|---|---:|---|
| ADAPT | **2,400** | structural training + Qwen task adaptation |
| CAL | **1,000** | pairwise head learner + all architecture gates |
| LOCK | **600** | one untouched confirmation only |

Seeds should remain exactly from the current lineage:

- global seed `42`;
- split seed `2026090241`;
- CAL fold seed `2026090242`;
- new bootstrap/action audit seed fixed in the notebook before results are viewed.

No post-LOCK retraining.

This was one of the strongest methodological decisions in V41.1 and should remain unchanged.

### Exact anchor

Reconstruct B34 **algorithmically** from organizer data and frozen V3.1→V25→V30/V31 lineage.

Hard checks before training:

- V30 changed rows = 77;
- V30 Top1 changes = 8;
- V30 membership changes = 7;
- V31 changes = 60;
- states = `S0 897 / S1 26 / S2 43 / S3 34`;
- S3 boundary decomposition = `B23 9 / B34 10 / B45 8`;
- final B34 Top-5 SHA-256 = `a235d00a...e039730c`.

The production notebook has already reproduced these exact values. fileciteturn0file0

No historical submission CSV is read as an input.

### Structural features

The preference specialist should receive **compressed decision evidence**, not the 100+ raw feature universe.

Recommended item-level inputs:

| Feature family | Keep? | Reason |
|---|---|---|
| B34/V30 structural score | Yes | strongest prior |
| Within-user anchor z-score | Yes | score scale normalization |
| Anchor rank 1–4 | Yes | decision geometry |
| Consensus3 score | Yes | stable calibrated view |
| Sparse score | Yes | lexical evidence |
| V31−V30 delta | Yes | intent-state residual evidence |
| Readiness | Yes | organizer-derived skill-gap context |
| Latest-intent match | Yes | proven structural context |
| Qwen raw semantic score | Yes | independent semantic evidence |
| Qwen calibrated relevance probability | Optional | secondary semantic view |
| module ID/intercept | Yes | controlled module heterogeneity |
| XLM-R | **No** | did not earn incremental complexity |
| retrieval/KNN | **No** | prior unstable |
| prerequisite selector | **No** | V40 failed |
| trajectory | **No** | V39 failed |

All pair features are expressed as differences:

\[
x_{u,a,b}=x_{u,a}-x_{u,b}.
\]

This forces the model to learn **preference**, not absolute cross-user scores.

### Qwen expert

Do not redesign Qwen.

Reuse V41.1 exactly:

- `Qwen/Qwen3-Embedding-8B`;
- pinned revision `1d8ad4c`;
- QLoRA;
- final eight transformer layers;
- rank `8`;
- alpha `16`;
- dropout `0.05`;
- learning rate `5e-5`;
- weight decay `0.01`;
- one epoch;
- batch size `4`;
- query max length `160`;
- module max length `224`;
- ADAPT only.

The goal is **not** to test a new LLM.

The goal is to test whether already-observed semantic complementarity becomes useful when converted into an appropriate **within-user head preference**.

### Preference learner

Use **one strongly regularized linear Bradley–Terry-style utility model**, operationally implemented through pairwise logistic loss.

Do not use LightGBM.

Do not use MLP.

Do not use another Transformer head.

Do not use six independent classifiers.

A reasonable fixed regularization is approximately equivalent to logistic `C≈0.20–0.30`; I would preregister **0.25** and never search it.

Module heterogeneity can be represented with module intercept differences and a heavily shrunk module×Qwen deviation. Do not create 17 separate full models.

The pair weight should be based on **metric importance**, not handpicked module identities. A defensible fixed scheme is to derive weight from the relevance difference and the corresponding head discount difference, normalized and clipped to prevent one observation from dominating. That directly makes the pair objective care more about mistakes near the top without introducing a hyperparameter search.

### The critical deployment change: score permutation, not score blending

This is the part I regard as most important.

V41 and V41.1 both created new continuous scores.

V41.2 should **never invent a new score scale**.

For each test user:

1. take exact B34 Top-4 modules and their four existing B34 score values;
2. normally leave everything unchanged;
3. if a challenger passes the Top-1 confidence/stability policy, promote it to #1;
4. **permute the four existing B34 score values** to encode that new order;
5. ranks 5–17 remain numerically bit-for-bit unchanged.

Thus the multiset of Top-4 scores is identical before and after the action.

There is:

- no alpha;
- no score calibration;
- no row standardization at final output;
- no membership movement;
- no accidental #4↔#5 crossing;
- no semantic score leaking into lower ranking geometry.

This removes an entire class of failures that affected V41/V41.1.

### Abstaining action policy

The model must be allowed to say:

> **B34 is already good enough; do nothing.**

For an eligible user, let \(m_1\) be B34's current #1 and \(m^\*\) be the best alternative among B34 ranks 2–4.

Promote only if all conditions hold:

\[
P(m^\*\succ m_1)\ge 0.80
\]

and at least **4 of the 5 CAL-fold models agree on the direction**, with the full CAL model also selecting the same challenger.

No post-hoc module whitelist.

No user-ID rule.

No public-probe-derived candidate list.

No threshold sweep.

The idea of thresholding probabilistic ranking preferences and abstaining when evidence is weak has a formal precedent in label-ranking research; that literature specifically studies deriving partial orders by thresholding pairwise preference probabilities rather than forcing every comparison to be resolved. citeturn12search1

### Protected rows

Keep:

- **S1 locked** because its broad public history is adverse;
- **S3 locked** because it contains the expensive public-proven decisions, including the Top1 package and B34;
- **S0 + S2 eligible**.

That is the same 940/60 eligible/locked geometry already reproduced by V41.1.

The difference is that an eligible user can only experience a **Top-4 internal permutation that changes #1**.

Membership is impossible by construction.

## Expected leaderboard economics and the submission gate

This experiment should be judged much more harshly than V41.1 because it is the last one.

### Historical Top-1 sensitivity

Using the historical package estimate:

\[
3\ \text{Top1 corrections}\approx +0.00056,
\]

a crude average is:

\[
a \approx 0.000187
\]

per net-equivalent correct Top-1 correction.

To cover the current Top-5 gap:

\[
\frac{0.00040}{0.000187}\approx2.14.
\]

So roughly **three net-equivalent correct Top-1 interventions** are enough under that historical effect scale.

That is precisely why a small, very precise Top-1 policy is economically more attractive than another 30-user generic reranker.

### Sensitivity simulation

The following is **not a forecast of V41.2 accuracy**. It is a conditional sensitivity calculation.

Assume:

1. correct and incorrect Top-1 actions have approximately symmetric magnitude;
2. each action has the historical average absolute effect \(0.00056/3\);
3. decisions are approximately independent;
4. the model has true action precision \(p\).

For five test actions, at least four correct are needed to comfortably exceed the `+0.00040` target under that approximation.

For eight actions, roughly six correct are needed.

| True precision assumption | P(≥4 correct of 5) | Expected Δ, 5 actions | P(≥6 correct of 8) | Expected Δ, 8 actions |
|---:|---:|---:|---:|---:|
| 70% | 52.8% | +0.00037 | 55.2% | +0.00060 |
| 75% | 63.3% | +0.00047 | 67.9% | +0.00075 |
| 80% | 73.7% | +0.00056 | 79.7% | +0.00090 |
| 85% | 83.5% | +0.00065 | 89.5% | +0.00105 |

These are conditional probabilities, **not the probability V41.2 reaches Top-5**. The unknown quantity is whether the model can genuinely sustain 75–85% precision on unseen high-confidence Top-1 corrections.

There is also effect-size uncertainty. If the historical three-action package happened to have twice the average impact of future Top-1 actions, then the expected `+0.00056` at five actions/80% precision becomes only about **+0.00028**.

That is why the notebook must gate on **actual CAL and LOCK NDCG improvement**, rather than accepting a candidate purely because its action precision looks attractive.

### Comparative risk-adjusted outlook

These ranges are judgmental sensitivity bands from the empirical lineage, not fitted confidence intervals.

| Option | Plausible effect profile after passing its gate | Main danger |
|---|---|---|
| **A\*: Head4-trained, Top1-only** | **Best chance of +0.0002 to +0.0007+** with very few actions | confidence calibration |
| Full PL Top4 | roughly −0.0002 to +0.0004 | B23/B34-type low-value reordering dilutes Top1 benefit |
| Top1 + ordinal 2–4 | roughly −0.0003 to +0.0005 | reintroduces V41.1 ordinal instability |
| Another semantic full-list stack | around flat with substantial variance | already falsified directly by V41.1 |

### CAL gate

V41.2 should **not open LOCK** unless all of the following preregistered conditions hold:

| Gate | Requirement |
|---|---:|
| Exact B34 reproduction | **True** |
| Top1-within-Top4 oracle delta | **≥ +0.0010** |
| CAL OOF ΔNDCG | **≥ +0.00050** |
| Positive CAL folds | **≥ 4 / 5** |
| Positive contiguous ID blocks | **≥ 3 / 5** |
| CAL Top1 accuracy delta | **≥ +0.004** |
| Proposed Top1 action precision | **≥ 0.80** |
| Proposed actions on 1,000 CAL users | approximately **8–30** |
| Relevant@5 delta | **exactly 0** |
| Top-4 membership changes | **0** |
| Ranks 5–17 changes | **0** |
| Bootstrap CI lower bound | **≥ −0.00035** |
| No single-module dependence | leave-one-module stress must not destroy all gain |

The action-count band is not there to optimize the model after the fact. It is an economic sanity check. Three lucky CAL changes do not establish an 80% precision policy; 100 changes would indicate the supposed abstaining policy is not actually selective.

### LOCK gate

LOCK is opened exactly once.

Require:

| LOCK criterion | Requirement |
|---|---:|
| LOCK ΔNDCG | **≥ +0.00030** |
| Top1 accuracy delta | **> 0**, preferably ≥ +0.005 |
| Action precision | **≥ 0.75** |
| Positive contiguous blocks | **≥ 3 / 5** |
| Net beneficial minus harmful Top1 actions | **≥ 2** |
| Bootstrap CI lower | **≥ −0.00060** |
| Relevant@5 | **exactly unchanged** |
| Membership changes | **0** |
| Changes outside Top4 | **0** |

After LOCK, nothing is retrained or modified.

No threshold adjustment.

No module exclusion.

No “0.80 almost worked, let's try 0.77.”

No V41.2.1.

### Test geometry gate

Only after LOCK passes:

- S1 + S3 changed users = `0`;
- membership changes = `0`;
- ranks 5–17 changes = `0`;
- Top1 changes ideally **3–15**;
- every changed row must come from the generic preregistered rule;
- all four original Top-4 score values must be preserved as a multiset;
- exact output hash recorded.

If it produces fewer than three test Top1 changes, I would classify it:

> **VALID_BUT_LOW_LEVERAGE**

and **HOLD** rather than spend the final submission, because the historical economics would make bridging `+0.00040` unlikely.

If it produces more than roughly 15, the threshold is probably not behaving as an abstention rule and I would also HOLD.

## Kaggle T4×2 runbook and reproducibility contract

V41.2 does not need more compute than V41.1. In fact, after Qwen finishes, everything new is cheap CPU work.

```mermaid
flowchart TD
    A["Environment + seed audit"] --> B["Exact B34 reconstruction"]
    B --> C["CPU head-oracle feasibility audit"]

    C -->|Oracle insufficient| Z["FAIL-CLOSE to B34<br/>Stop before GPU"]
    C -->|Oracle sufficient| D["ADAPT structural features"]

    D --> E["Qwen3-Embedding-8B<br/>1 epoch QLoRA on ADAPT<br/>T4×2"]

    E --> F["Freeze all deep outputs"]
    F --> G["Build CAL B34 Top-4 pairs"]
    G --> H["5-fold OOF Bradley-Terry utility models"]
    H --> I["CAL NDCG + Top1 + precision<br/>block bootstrap + module stress"]

    I -->|Fail| Z
    I -->|Pass| J["Fit one full-CAL preference model"]
    J --> K["Open LOCK exactly once"]

    K -->|Fail| Z
    K -->|Pass| L["Predict test"]
    L --> M["S0+S2 only<br/>p≥0.80 + 4/5 stability"]
    M --> N["Permute existing B34 Top-4 scores"]
    N --> O["Geometry + hashes + TM audit"]
    O -->|Pass + submission-scale| P["submission_v41_2_primary.csv"]
    O -->|Otherwise| Z
```

### Compute sequence

**Environment phase.** Record Python and package versions before doing anything. Reuse the known V41.1 environment where possible: Python 3.12.x, NumPy 2.0.2, pandas 2.3.3, scikit-learn 1.6.1, LightGBM 4.6.0, PyTorch 2.10.0+cu128, Transformers 4.57.6, PEFT 0.18.x, bitsandbytes 0.48.x. Do not silently upgrade a working environment.

**Reproduction phase.** Exact anchor first. If any frozen count or hash differs, abort.

**Oracle phase.** CPU only. This must happen *before* one hour of Qwen training.

**Deep phase.** Qwen one epoch, ADAPT only. T4×2. No XLM-R.

**Preference phase.** CPU logistic/Bradley–Terry. Five deterministic CAL folds.

**LOCK phase.** Exactly one evaluation.

**Submission phase.** Discrete score permutation only.

### Required artifact bundle

V41.2 should write at least:

| Artifact | Purpose |
|---|---|
| `submission_v41_2_b34_anchor_reference.csv` | exact fail-close reference |
| `submission_v41_2_candidate_DIAGNOSTIC.csv` | candidate regardless of gate |
| `submission_v41_2_primary.csv` | candidate only if all gates pass; B34 otherwise |
| `v41_2_summary.json` | final verdict |
| `v41_2_reproduction_audit.json` | lineage/hash checks |
| `v41_2_split_manifest.csv` | exact ADAPT/CAL/LOCK assignment |
| `v41_2_package_versions.json` | reproducible environment |
| `v41_2_training_history.csv` | Qwen training history |
| `v41_2_head_oracle.csv` | Top1-within-Top4 and Top4 oracle headroom |
| `v41_2_cal_metrics.csv` | aggregate CAL metrics |
| `v41_2_cal_fold_metrics.csv` | five outer folds |
| `v41_2_cal_block_metrics.csv` | contiguous-ID stability |
| `v41_2_lock_metrics.csv` | untouched confirmation |
| `v41_2_lock_block_metrics.csv` | LOCK block stability |
| `v41_2_head_pair_audit.csv` | pair count, accuracy, loss, ties |
| `v41_2_top1_action_ledger_cal.csv` | every CAL proposal and correctness |
| `v41_2_top1_action_ledger_lock.csv` | every LOCK proposal and correctness |
| `v41_2_top1_action_ledger_test.csv` | test proposals, no labels |
| `v41_2_module_audit.csv` | module-level proposal/effect distribution |
| `v41_2_module_leaveout.csv` | concentration stress test |
| `v41_2_complementarity.csv` | structural vs Qwen vs preference specialist |
| `v41_2_test_geometry.csv` | changed users, Top1, membership, protected rows |
| `v41_2_score_multiset_audit.csv` | proves changed Top4 rows only permute anchor scores |

### TM/reproducibility checklist

Based on the compliance contract already encoded and passed in V41/V41.1, V41.2 should preserve:

- organizer-provided train/test/chat/assessment/module data only;
- no external labeled data;
- open-source pretrained Qwen used only as a model initialization;
- no request to a GenAI system to manufacture test relevance values;
- no hand-entered test labels;
- no historical submission CSV as an input;
- exact deterministic seeds recorded;
- test actions generated algorithmically;
- no manual test-user whitelist;
- no post-LOCK tuning or retraining;
- primary output fails closed to exact B34 if any gate fails;
- notebook-generated submission must match the submitted CSV.

The official IT TODAY page confirms MineToday is the event's Data Mining & Data Science competition. citeturn12search0 The currently available Kaggle data card also corresponds to the MineToday IT TODAY 2026 dataset used in the notebook lineage. citeturn13search16

The exact `TM MINETODAY.pdf` is not in the currently retrievable artifact bundle I could inspect in this pass, so any rule not already encoded in the V41.1 compliance audit should be checked line-by-line against that PDF before notebook hand-in. I would not add any new external dataset, external API, pseudo-label service, or test-specific manual correction to V41.2.

## Final recommendation

My judgment after this audit is:

> **We have reached the ceiling of the current full-list paradigm, but we have not yet tested the cleanest high-leverage head-only problem.**

That distinction matters.

V41.1 is strong evidence against:

\[
\text{B34}
+
\text{semantic score calibration}
+
\text{continuous residual blend}.
\]

It is **not** evidence against:

\[
\text{B34 Top4}
+
\text{within-user preference learning}
+
\text{selective Top1 permutation}.
\]

The latter is genuinely different in four ways.

First, it changes the target from **module-wise relevance** to **within-user preference**, directly addressing the disconnect between Qwen AUC and NDCG contribution exposed by V41.1.

Second, it trains on the part of the target with full supervision: all 4,000 users possess ranks 1–4. fileciteturn0file0

Third, it places deployment risk only where the metric has maximum positional leverage.

Fourth, it eliminates continuous score-blending risk entirely: a changed user simply receives a permutation of their **existing B34 Top-4 scores**, while all lower scores remain untouched.

That is why my ranking of the final choices is:

| Priority | Final choice |
|---:|---|
| **1** | **V41.2 A\*: Head4 Bradley–Terry/PL preference learning → abstaining Top1-only deployment** |
| 2 | HOLD exact B34 `0.66026` |
| 3 | Joint PL full Top4 reranking |
| 4 | Top1 + ordinal Top2–4 |
| 5 | Another full semantic ensemble / XLM-R / LambdaRank / membership experiment |

I would **not** spend the final experiment on options 3–5.

And I would not force V41.2 to submit merely because this is the last run.

The correct terminal logic is:

> **Oracle weak → stop before Qwen.**  
> **CAL weak → HOLD B34.**  
> **LOCK weak → HOLD B34.**  
> **LOCK strong but test has <3 credible Top1 actions → HOLD B34.**  
> **Only a clean CAL + untouched LOCK + submission-scale Top1 geometry earns the final submission.**

The conditional economics are attractive enough to justify the experiment: under the historical three-Top1 `≈+0.00056` package, only a few net-correct Top1 changes are theoretically sufficient to cover the `+0.00040` Top-5 gap. But that historical package is too small to treat as a guaranteed effect distribution, so the **LOCK result—not the simulation—must decide**.

There is one last operational caveat. It is approximately **01:15 WIB on September 3, 2026**. A secondary competition listing says the Kaggle submission phase ended September 2 and notebook collection runs September 3–7; I could confirm MineToday from the official IT TODAY event page but not that detailed schedule from a primary competition page. citeturn12search0turn12search9 Therefore:

> **Strategic verdict: RUN V41.2 only if the Kaggle submission endpoint is still open.**
>
> **Model verdict: V41.2 A\* is the one remaining experiment I believe is materially better justified than HOLD.**
>
> **If it fails its preregistered gate, stop. Do not build V41.3. Freeze B34 at 0.66026 and use the remaining energy to ensure the final notebook reproduces the exact submitted solution.**