# V44 Frozen-Lineage Causal Pruning Implementation Plan

Goal: Build a Kaggle-ready notebook that reconstructs the exact 0.66028 B34+B45 champion, audits V30-only S2 interventions by natural ranking geometry on honest OOF DESIGN data, freezes independently harmful classes, confirms the union on untouched LOCK, and only then emits a test candidate that reverts those S2 classes to the pre-V30/V25 surface.

Constraints: organizer data only; no external labels; no learned test selector; no user-ID feature/whitelist; no module whitelist; no class-subset combinatorial search; exact public S3/B34/B45 geometry protected; fail-close exact 0.66028; deterministic seeds; Kaggle T4x2 compatible.

Tasks:
1. Reuse exact V3.1→Consensus3→V25→V30/V31 reconstruction from V43.1 and assert historical geometry/hashes.
2. Add tested natural V30 action classifier with hierarchy TOP1 > MEMBERSHIP > B23/B34/B45 > COMPLEX_ORDER.
3. Build lightweight fold-pure V30/V31 validation helper and fixed DESIGN/LOCK split.
4. Assemble honest DESIGN OOF S2 ledger and exact per-class counterfactual reversion gains.
5. Freeze independently harmful classes using preregistered class gates; no subset search.
6. Confirm frozen union once on LOCK; if fail, abstain.
7. Apply frozen class pruning only to exact test S2 rows; protect S3/B34/B45 and all other rows bit-exact.
8. Emit primary/fail-close submission plus union/individual diagnostics and full audit artifacts.
9. Run syntax/static checks and smoke execution.
