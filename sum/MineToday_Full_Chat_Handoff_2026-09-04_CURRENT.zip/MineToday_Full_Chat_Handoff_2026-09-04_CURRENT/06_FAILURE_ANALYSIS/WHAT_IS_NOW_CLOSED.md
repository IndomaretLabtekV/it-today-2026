# What Is Now Closed

These branches should not be reopened without genuinely new evidence.

## Broad semantic recommender/reranker
Qwen, BGE, IndoBERT, XLM-R repeatedly showed some representation learning but unreliable residual NDCG transfer.

## Full-list objective replacement
XE/YetiRank/LambdaRank objective diversity alone did not solve the frontier problem.

## Generic selector/router
Confidence, uncertainty, stability, retrieval neighbor memory, proposal consensus, and competence routers repeatedly failed to select the rare beneficial actions reliably.

## Membership-heavy correction
Lower cutoff prediction is weakly supervised due K=4/5/6 uncertainty. Membership-focused branches were especially unstable.

## Generator/template specialist
V42 signal was real but small; V42.1 clean isolation was only +0.000069 and failed transfer gates. Do not tune kappa, support thresholds, modules or alpha post hoc.

## Joint TabM residual
V43 full authority was strongly harmful. V43.1 showed that after shrinking authority enough to nearly neutral, direction still failed 4/5 outer folds. Do not create V43.2 via epoch/L2/dropout/hidden-size fishing.

## V30-S2 coarse pruning
V44 found no harmful natural S2 class that passed stability gates. Do not create class×module or class×intent subgroups from the same evidence; that would be post-hoc subgroup mining.
