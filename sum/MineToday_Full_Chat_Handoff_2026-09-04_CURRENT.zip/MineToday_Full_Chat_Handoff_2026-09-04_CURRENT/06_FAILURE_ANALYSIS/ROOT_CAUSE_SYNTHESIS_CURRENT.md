# Root Cause Synthesis — Current

## 1. Strong-anchor saturation
The 0.66028 champion already contains multiple public-validated corrections. A new model must beat not a generic baseline but a hand-pruned ensemble of proven decisions.

## 2. Selector bottleneck
Several models can propose many potentially useful actions, and oracle analysis often shows headroom. The hard part is identifying the correct actions without labels at test time.

## 3. Lower-boundary entropy
Because K=4/5/6 is near-balanced and weakly predictable, rank5/rank6 membership is intrinsically difficult. This explains why membership specialists often fail despite high per-action leverage.

## 4. Offline optimism
V13-like stacking, V41 and many router experiments demonstrate that small validation dependency or repeated threshold selection can create false confidence.

## 5. Broad authority is dangerous
V43 is the cleanest demonstration: allowing a learned model to rewrite many head permutations destroyed NDCG even though TabM itself outperformed the MLP control.

## 6. Fine residual direction can still be wrong
V43.1 reduced action count from 1,475 to 17 but remained negative. Therefore safety via shrinkage is necessary but not sufficient.

## 7. Causal decomposition works better than model complexity late in the competition
The path Hybrid34 → 0.66020 → B34 → B34+B45 is the strongest late-stage evidence. The next effort should apply the same discipline to the remaining unresolved public-positive package: V25.
