# What Remains To Do

This is deliberately not a full new experiment design. It is a map of remaining work for the next chat/team.

## Immediate operational priority
Let the teammate's independent branch use the remaining daily slots.

Why:
- independence now has higher information value than another variation of the same historical archive,
- V49 demonstrated historical archive meta-overfitting/transfer failure.

## Before another new version from this branch

### 1. Reconstruct a genuinely prospective validation plan
Need a split/criterion that has not already been repeatedly optimized against.

Questions to answer:
- Which user/template groups have never been used for architecture decisions?
- Can a chronological or generator-family holdout be created without target leakage?
- Can we preserve enough sample size to detect ≥~0.0005 effects?

### 2. Improve the anchor analogue
The 0.66028 test champion has no exact honest OOF twin.

Future incremental experiments should either:
- reconstruct a closer fold-pure analogue of the complete champion policy,
- or avoid claiming tiny deltas vs V30 proxy are equivalent to champion deltas.

### 3. Focus on head authority
If building another specialist:
- challenger likely restricted to current Top4,
- Top5 membership frozen by default,
- ranks 5–17 frozen,
- target exact counterfactual Top1 ΔNDCG,
- very low coverage.

### 4. Search for genuinely new information, not another correlated representation
Potentially useful only if it captures something not already encoded by:
- sparse topic,
- V30 structural rank,
- intent/readiness,
- current semantic history.

The key question is not "what model is stronger?"
It is:
**what latent variable explains beneficial champion Top1 errors that current views miss?**

### 5. Treat public LB only as confirmation
Do not use the V49 0.65986 result to search weights or exclude individual old experts.
That would directly overfit test feedback.

## Stop conditions
If future prospective head-selection experiments cannot demonstrate a clearly larger effect than the recent noise floor, protect 0.66028 and stop changing the model.

A robust final rank is better than destroying the champion with late noisy probes.
