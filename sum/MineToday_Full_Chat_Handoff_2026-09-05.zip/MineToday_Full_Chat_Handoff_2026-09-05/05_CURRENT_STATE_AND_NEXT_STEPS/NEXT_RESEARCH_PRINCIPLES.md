# Principles for the Next Research Iteration

1. **Start from the frozen 0.66028 champion.**
2. **Protect public-proven Top1 actions.**
3. **Do not trust absolute OOF scores across historical versions.**
4. **Use matched incremental deltas.**
5. **Require genuinely prospective validation.**
6. **Treat +1e-4/+3e-4 as weak unless confirmation is exceptionally strong.**
7. **Prioritize Top1/head ordering.**
8. **Freeze membership unless evidence directly supports changing it.**
9. **Do not mine B45/B56 as the primary branch.**
10. **Do not equate model count with diversity.**
11. **Do not retune V49 after seeing 0.65986.**
12. **Independent teammate signal is valuable.**
13. **Runtime failure != scientific failure.**
14. **A weaker standalone model can be useful only if complementarity transfers. V49 proved OOF complementarity alone is insufficient.**
15. **Every new degree of freedom needs a reason and a validation budget.**
