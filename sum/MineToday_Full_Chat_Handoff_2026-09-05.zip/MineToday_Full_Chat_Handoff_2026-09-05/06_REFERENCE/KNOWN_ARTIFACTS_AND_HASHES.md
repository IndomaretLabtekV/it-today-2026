# Known Artifacts and Hashes

No artifact files are included in this handoff. This document only records names and identifiers referenced in the chat.

## Current champion
Top5 hash:
`7c0d29a7309b7283a043b7d37ca5556ba7c0ca2270b0137a6e1e0878a69a5fe7`

Exact champion CSV SHA256:
`443785fb534df9820ce57bfe450a2768881625bf7ae37aa849dd0d9f2afc957d`

Earlier local exact champion path:
`/mnt/data/submission_ready/submission_champion_066028.csv`

## V47
Notebook previously generated:
`/mnt/data/v47.ipynb`

Final static notebook SHA256 recorded:
`4058ee9817205f3a827371e1f77b40a6b76d2a113526ac76e400125e18c2faf4`

## V48
Notebook generated in prior chat:
`MineToday_V48_Protected_CrossFitted_MultiView_Ensemble.ipynb`

Actual run failed before meaningful ensemble evaluation.

## V49
Local notebook:
`notebooks/v49.ipynb`

Frozen diagnostic:
`results/v49/submission_v49_diagnostic.csv`

Diagnostic SHA256:
`2618ae7182ca071e77655e0b1da2f81ac6ed7a0bc552cf5e8af08815cfec026c`

Diagnostic public score:
`0.65986`

## Main result tree
User's repository has `results/v1` through `results/v48` style folders with many OOF/result artifacts.

Important families/files mentioned:
- V1 `minetoday_cache/oof_final_blend.npy`
- V2 final OOF/test arrays
- V3.1 `v31_oof_artifacts.npz`
- V4 `v4_oof_artifacts.npz`
- V5 `v5_oof_artifacts.npz`
- V6 `v6_oof_artifacts.npz`
- V7–V22 many `*_oof_artifacts.npz`
- V32 `v32_test_score_artifacts.npz`
- V33 `v33_stage1_oof_artifacts.npz`
- V38 hybrid OOF NPZs
- V47 split/results
- V48 split/results
- V49 generated runtime outputs locally

Do not assume every artifact is safe to stack. Provenance must be audited.
