# Glossary

## Anchor
The current protected prediction policy used as the baseline for incremental changes.

## Champion
Current best public submission, **0.66028**.

## S0 / S1 / S2 / S3
Historical state/action-confidence groups used in late versions. The exact generating logic lives in historical notebooks; conceptually S0 is the least publicly protected region and later states contain increasingly trusted/proven interventions.

## B12 / B23 / B34 / B45 / B56
Adjacent rank boundaries:
- B12 = rank1 vs rank2
- B23 = rank2 vs rank3
- etc.

## Consensus3
Durable V12.2-era sparse/calibrated consensus baseline.

## Hybrid34
V30/V31-derived overlap/agreement package that materially improved public score to around 0.66006.

## OOF
Out-of-fold prediction. Must be generated without training on the same user's target.

## CAL
Calibration/development partition used in some historical versions.

## LOCK
Holdout intended for one-shot final confirmation. A reused/opened LOCK is no longer pristine.

## Fail-close
If a validation/runtime gate fails, output exact anchor rather than a potentially harmful new candidate.

## Action
A small ranking intervention on a user, often moving/reordering one or more modules.

## Top1 utility
Exact change in NDCG caused by making a candidate module rank1.

## Membership
Which modules are in Top5, ignoring their internal order.

## Authority
The system's decision of whether a proposed challenger is reliable enough to overwrite the anchor ranking.
