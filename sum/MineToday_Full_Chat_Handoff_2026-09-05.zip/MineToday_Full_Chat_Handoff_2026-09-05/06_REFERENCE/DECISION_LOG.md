# Decision Log

## Durable modeling decisions
- Sparse word+char representations remain a core backbone.
- V30 residual ranking is a trusted structural improvement.
- Protect the 0.66028 champion.
- Protect public-proven Top1 packages.
- Membership changes are disfavored by default.
- Lower-order edits are low priority.
- New candidates should fail-close.

## Research decisions
- Shifted from whole-model optimization to selective action utility after V30/V31.
- V47 focused on Top1 semantic competence.
- V48 moved to multi-view ensemble after learning a 0.66076 team used strong multi-model blending.
- V49 moved to mature-Kaggle artifact-level OOF/test ensembling rather than retraining base models.
- V49 public sign reversal closed that historical ensemble branch for now.

## Submission decisions
- V47: no submission because exact anchor fail-close.
- V48: no submission because exact anchor fail-close.
- V49 official primary: no submission because exact anchor fail-close.
- V49 frozen diagnostic: intentionally submitted as one information-gathering slot.
- Result: 0.65986.
- Keep 0.66028 as best.
- Remaining two daily slots delegated/planned for teammate independent approach.

## Important epistemic decisions
- Do not call runtime failures scientific failures.
- Do not use public V49 failure to retune historical weights.
- Do not compare historical absolute OOF scores naively.
- Do not treat dozens of versions as dozens of independent models.
