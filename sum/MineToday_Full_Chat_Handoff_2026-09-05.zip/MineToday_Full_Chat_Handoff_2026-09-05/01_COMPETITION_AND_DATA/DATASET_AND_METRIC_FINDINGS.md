# Dataset, Metric, and EDA Findings

## Core dimensions
- train users: 4,000
- test users: 1,000
- modules: 17
- chat rows: about 14.6k
- chat unique users: ~4.94k
- organizer chat contains 90 users outside the core train/test cohort; this is legitimate organizer data and should be audited rather than asserted away.

## Positive-set size
Each train user has exactly 4, 5, or 6 relevant modules.

## Relevance pattern
The ranking target typically uses:
1. 1.00
2. ~0.85
3. ~0.70
4. ~0.55
5. ~0.40
6. ~0.25

Rank1 is always 1.0.

## Pairwise boundary difficulty
Approximate historical AUC:
- 1 vs 2: 0.668
- 2 vs 3: 0.614
- 3 vs 4: 0.563
- 4 vs 5: 0.530
- 5 vs 6: 0.521

Therefore:
- head ordering has exploitable signal,
- lower ordering approaches chance,
- aggressive B45/B56 optimization is low-EV.

## Template duplication
The language data is highly templated:
- around half of chat rows were duplicate-like,
- most test conversations share normalized template families with train,
- adversarial train/test classification is near random.

This made sparse word/character TF-IDF extremely competitive.

But template identity is not equivalent to target identity. Users with nearly the same latest message can need different next modules.

## Topic vs learning-path order
Explicit topic is often relevant but true Top1 only ~40.5% of the time.
This means:
- semantic encoders can capture useful relevance,
- but semantics alone repeatedly fail to solve within-user Top1 order.

## Oracle headroom
Multiple later experiments found large theoretical headroom:
- V46 DESIGN oracle delta ~+0.0276 in its setup.
- V47 oracle DESIGN delta ~+0.0203, with roughly 64% of wrong Top1 cases recoverable from within the current Top4.

This proves the champion often already contains the correct module; the difficult part is selecting which candidate should be first **with extremely high precision**.
