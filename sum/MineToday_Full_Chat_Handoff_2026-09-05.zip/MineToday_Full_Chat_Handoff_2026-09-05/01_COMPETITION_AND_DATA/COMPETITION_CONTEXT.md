# Competition Context and Rules

## Task
Build an AI Course Advisor that recommends the most relevant learning modules for each learner.

The practical output is a ranking over 17 modules, evaluated at top-5.

## Metric
**NDCG@5**, user-level.

Metric implications:
- Rank1 errors have the largest effect.
- Correct membership alone is insufficient; ordering matters.
- Lower rank boundaries produce much smaller expected value than Top1/Top2 corrections.

## Rules captured from the technical meeting / competition context
- Maximum **3 submissions per day**.
- No external labeled data.
- Multiple ML models are allowed.
- Python/R or similar programming languages are allowed.
- Open-source pretrained models are allowed.
- Paid pretrained models are not allowed.
- LLM/GenAI must not be directly asked to predict the test set.
- Coding assistants are allowed.
- Final notebook must be reproducible with fixed seeds.
- Final notebook output should reproduce within approximately **0.001 tolerance**.
- No collaboration between teams.

## Important reproducibility implication
A final ensemble based on precomputed historical predictions must still be packaged in a way that complies with final notebook rules. The earlier V49 discussion considered:
- uploading a compact private Kaggle Dataset containing only selected historical OOF/test prediction artifacts,
- or deterministic reconstruction if organizer rules require it.

No final production packaging was created because V49 itself failed the public probe.
