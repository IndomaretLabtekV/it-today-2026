# Detailed Recent Work: V47, V48, V49

## V47 intended architecture

### Goal
Test whether dual independent semantic encoders can identify a tiny set of beneficial Top1 corrections against the frozen 0.66028 champion.

### Encoders
- multilingual E5 large instruct
- Nomic embed text v2 MoE

### Text construction
User:
- last 3 non-administrative learning messages
- chronological tags OLDER / RECENT / CURRENT
- assessment profile for 10 skills

Module:
- module name
- syllabus
- prerequisite level

### Pooling
- E5: mean pooling
- Nomic: mean pooling
- L2 normalization

### Action space
- S0 only
- challenger from current ranks 2–4
- Top1 permutation only
- Top5 membership frozen
- ranks 5–17 frozen

### Target
Exact counterfactual ΔNDCG@5 from moving challenger to Top1.

### Heads
- one low-capacity Ridge head per semantic encoder
- structural control is diagnostic only
- final authority requires same challenger and both semantic utilities positive

### Splits
Approximate:
- ACTION_TRAIN 2600
- DESIGN 800
- LOCK 600
Grouped by latest-template family.

### Risk coverage
~0.25%, 0.5%, 1.0%, 1.5%

### Intended gates
DESIGN roughly:
- ≥ +0.0008
- positive clustered CI
- ≥ 4/5 folds positive
- no catastrophic ID block
- benefit:harm ≥ 2:1
- consensus beats singles/control
- projected 3–15 test actions

LOCK:
- positive
- pooled DESIGN+LOCK ≥ +0.0008
- positive lower bound
- no post-lock retuning

### Actual
Nomic loading failed.
No embeddings → no DESIGN → no LOCK → no test actions.
Exact champion fail-close.

---

## V48 intended architecture

### Goal
Test whether a small library of genuinely different expert families can improve the protected champion.

### Initial expert set
- Consensus3
- V30
- V31
- Qwen semantic

### Meta design
- strict nested OOF
- low-capacity/discrete selection
- no broad high-capacity stacker
- conservative head authority
- protected public-proven actions

### Actual failure
Qwen loading/runtime compatibility:
`keras_nlp` backend issue.

Transformers package pinning was ineffective in-process because module had already been imported.
No meaningful ensemble was evaluated.

---

## V49 design shift

Instead of reconstructing base models:
- use existing local historical artifacts,
- identify valid OOF/test pairs,
- deduplicate,
- group families,
- evaluate quality and complementarity,
- conservative ensemble selection.

Codex was permitted to run V49 locally because it was artifact-level computation only.

### Local restrictions
Allowed:
- load OOF/test predictions
- align matrices
- compute NDCG/correlation
- fit ensemble weights
- generate V49 result artifacts

Forbidden:
- retrain V1–V48
- download or run Qwen/BGE/E5/Nomic/XLM-R/IndoBERT
- regenerate embeddings
- recreate missing predictions

### V49 validation
Nested OOF:
0.6632663 → 0.6634656
gain +0.0001993

Gate required:
+0.0004500

CI:
[+0.0000410, +0.0003986]

Stability:
- 4/5 folds positive
- 4/5 ID blocks positive
- worst fold -0.0000597
- family Jaccard 0.62

Behavior:
- 19 development users changed
- 13 Top1
- 6 rank2/3
- 13 beneficial
- 6 harmful
- no Top5 membership change

Selected counts:
- anchor x2
- V1 final blend x1
- V5 primary x1
- V2 supervised multimodal x1
- V4 LambdaRank x1

Official primary failed closed because gate was not met.

### Controlled public diagnostic
Because a daily slot would otherwise expire, the frozen DEVELOPMENT-selected policy was exported without retuning.

Test behavior:
- 28 users changed
- 13 Top1
- 15 other head-order changes
- 0 Top5 membership changes

Hash:
`2618ae7182ca071e77655e0b1da2f81ac6ed7a0bc552cf5e8af08815cfec026c`

Public:
**0.65986**

Anchor:
**0.66028**

Delta:
**-0.00042**

This is currently the strongest evidence against further historical-ensemble weight tweaking.
