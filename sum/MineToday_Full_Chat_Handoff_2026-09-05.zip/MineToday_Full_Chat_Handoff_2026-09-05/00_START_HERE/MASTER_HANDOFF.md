# MASTER HANDOFF

## 1. What this project is

The user is competing in **MineToday: Data Mining Competition – IT Today 2026**, an AI Course Advisor / learning-path recommendation task. The system must rank 17 learning modules for each user and output the top-5. The official metric is **NDCG@5**.

The project has progressed through approximately V1–V49, with increasingly careful validation, causal public probes, residual rankers, semantic systems, structural selectors, and finally historical-prediction ensemble experiments.

The user wants to beat the current strong region around 0.66076 and ideally the leader around 0.66142. The best confirmed score from this lineage remains **0.66028**.

---

## 2. Dataset facts that matter

### Size
- Train users: **4,000**
- Test users: **1,000**
- Modules: **17**
- Chat rows historically noted: ~14,573
- Unique users in chat: ~4,940 because organizer chat also includes a small out-of-cohort set.
- V49 found **90 organizer chat users outside the train/test cohort**. A previous assertion incorrectly assumed all chat users were in cohort; Codex fixed this by turning it into an explicit audit rather than an invalid assertion.

### Relevance geometry
Every train user has exactly 4, 5, or 6 positive modules.

Typical relevance sequence:
- rank 1 = **1.00**
- rank 2 ≈ **0.85**
- rank 3 ≈ **0.70**
- rank 4 ≈ **0.55**
- rank 5 ≈ **0.40**
- rank 6 ≈ **0.25**

Rank1 relevance is always 1.0.

### Pairwise learnability
Historical pairwise AUCs:
- B12 ≈ **0.668**
- B23 ≈ **0.614**
- B34 ≈ **0.563**
- B45 ≈ **0.530**
- B56 ≈ **0.521**

This is one of the most important dataset findings. The upper head is substantially more learnable than lower boundaries.

### Chat/template behavior
- Chat is heavily templated and duplicated.
- ~51.5% of chat rows were described as duplicates in the research audit.
- ~69.9% of test messages had normalized exact overlap to train.
- ~95.8% of test users with chat had a train-repeated template family.
- Yet repeated template does **not** imply a unique target ranking. Users sharing text can still have different true Top1 because readiness/history/module state differs.
- Broad adversarial train-vs-test classifiers were around **AUC 0.51–0.525**, so there is no strong evidence of gross covariate shift.

### Semantic topic signal
Explicit/latest topic is often relevant, but is the true Top1 only around **40.5%**. Thus:
- semantic topical relevance helps,
- but topic alone does not solve personalized Top1 ordering.

---

## 3. Current champion

The current protected champion is the **B34+B45 lineage at public 0.66028**.

Known Top5 hash:
`7c0d29a7309b7283a043b7d37ca5556ba7c0ca2270b0137a6e1e0878a69a5fe7`

Known exact champion CSV SHA256 from earlier extraction:
`443785fb534df9820ce57bfe450a2768881625bf7ae37aa849dd0d9f2afc957d`

This anchor should be treated as frozen unless a new candidate has materially stronger evidence than the recent small-delta experiments.

---

## 4. Durable lineage

Approximate major public progression:

- V3.1 sparse word+char TF-IDF: durable breakthrough.
- Consensus3: ~**0.65856**
- V22.3: ~**0.65912**
- V25: ~**0.65919**
- V30 residual LambdaRank: ~**0.65963**
- V31 whole model: ~**0.65949** (worse standalone)
- Hybrid34 / V30-V31 agreement geometry: ~**0.66006**
- S3 package: ~**0.66020**
- B34: ~**0.66026**
- B34+B45 champion: **0.66028**

The important lesson is not just the numbers. V31 standalone was worse, yet some V30/V31 **agreement** regions were valuable. This established that marginal ensemble/consensus value can differ from standalone quality.

---

## 5. Public causal decomposition that must be preserved

For the S3/hybrid packages, historical public probes decomposed actions roughly as:

- S3 total: 34 user/actions
  - 3 Top1
  - 4 membership
  - 27 pure lower-order actions
    - B23: 9
    - B34: 10
    - B45: 8

Key public findings:
- Removing the 3 S3 Top1 actions caused about **-0.00056**. These are extremely valuable.
- Removing S3 membership actions was display-flat.
- B23 was harmful at roughly **-0.00022**.
- B34 contributed about **+0.00006**.
- B45 contributed about **+0.00002**.
- Removing all 27 lower-order actions improved by roughly **+0.00014**.

Another public-proven package:
- Removing 4 V30 S2 Top1 actions moved approximately **0.66028 → 0.66000**, i.e. ~**-0.00028**.

Core causal conclusion:
**a very small number of precise Top1 decisions is worth far more than broad lower-order surgery.**

---

## 6. Main diagnosis before V47

The research reset through V46 concluded:

### Confirmed
- selection/authority bottleneck
- validation mismatch
- objective mismatch, especially at lower boundaries

### Directions that had become low-EV defaults
- broad semantic blending
- generic membership editing
- B45/B56 mining
- arbitrary embedding ensembles
- high-capacity residuals with small action samples
- pruning already public-proven Top1 authority

### Best remaining research bet at that time
Find **3–15 new Top1 actions with very high precision**, ideally S0-only and with as little collateral geometry change as possible.

---

## 7. V47

V47 was designed as a very strict semantic Top1 utility experiment using:
- `intfloat/multilingual-e5-large-instruct`
- `nomic-ai/nomic-embed-text-v2-moe`
- exact counterfactual Top1 ΔNDCG target
- S0 only
- challengers only from champion ranks 2–4
- no membership edits
- no ranks 5–17 edits
- separate low-capacity Ridge utility heads
- consensus requires same challenger and both experts positive
- template-aware ACTION_TRAIN / DESIGN / LOCK
- intended 2600 / 800 / 600 split
- risk-coverage approximately 0.25%, 0.5%, 1.0%, 1.5%
- fail-close to champion

V47 did **not scientifically test the hypothesis** because the semantic stack failed operationally:
- environment packages were mostly fixed compared with V46,
- but Nomic loading failed with an AutoTokenizer/config incompatibility.
- `embeddings_ready = false`
- DESIGN not evaluated
- LOCK not evaluated
- test actions = 0
- candidate/primary were exact champion.

Important: classify V47 as **implementation/runtime failure, hypothesis unresolved**, not semantic failure.

---

## 8. Competitor ensemble clue

The user learned that a teammate/competitor around **0.66076** reportedly:
- ensembled ~6 models,
- had a large/complex modeling codebase,
- then combined that with a teammate's independently built system at roughly **40/60**.

This raised the prior that genuine cross-pipeline error diversity can matter.

The initial reaction was to investigate whether our own V1–V48 archive contained complementary historical predictions.

---

## 9. V48

V48 was designed as a **Protected Cross-Fitted Multi-View Ensemble Selection** experiment.

Intended expert views:
- Consensus3 sparse/calibrated
- V30 residual ranking
- V31 intent-state
- Qwen semantic

Principles:
- exact 0.66028 anchor frozen
- nested template-aware OOF
- untouched lock
- conservative S0/head-order authority
- no broad membership changes
- low-capacity/discrete ensemble selection rather than large meta-model
- test only after validation gates

But V48 also failed operationally before meaningful ensemble evaluation.

Observed problem:
- Qwen semantic stage failed with:
  `ValueError: Backend should be defined in the BACKENDS_MAPPING. Offending backend: keras_nlp`
- Notebook attempted to pip-install a compatible transformers version after importing transformers, but the active Python process still recorded **transformers 5.0.0**. The installed package was not reloaded from `sys.modules`, likely contributing to the mismatch.

Result:
- semantic ready = false
- DEVELOPMENT not evaluated
- no expert correlation
- no learned weights
- LOCK not opened
- test actions 0
- output exact champion

Again: **implementation failure, not ensemble hypothesis failure**.

---

## 10. V49: historical artifact ensemble

Because mature Kaggle workflows can ensemble huge libraries by loading OOF/test predictions, the strategy changed:

Instead of retraining multiple experts in one notebook:
- load historical OOF/test artifacts,
- audit provenance,
- deduplicate,
- measure quality/diversity,
- perform conservative ensemble selection,
- apply exact selected transformation to test.

Codex was used locally because all result artifacts already existed on disk, making artifact-level search much faster than packaging a huge Kaggle input dataset.

Local permission was explicitly limited:
- allowed: load predictions, fit ensemble, compute OOF NDCG/correlation, generate V49 artifacts
- forbidden: retrain base models, rerun deep models, download embeddings/models, regenerate missing predictions.

### V49 main validation result

Verdict before public probe: **DO NOT SUBMIT** under preregistered rules.

Nested OOF:
- anchor: **0.6632663**
- ensemble: **0.6634656**
- gain: **+0.0001993**
- required DEVELOPMENT gain: **+0.0004500**

Other validation:
- best single anchored policy: **0.6632732**
- ensemble edge over best single anchored policy: **+0.0001924**
- best standalone expert: `v13_router` at **0.6670496**
  - but this was not trusted as a direct submission candidate because historical transfer/provenance is weaker and standalone absolute OOF is not equivalent to incremental authority.
- bootstrap CI for ensemble gain:
  **[+0.0000410, +0.0003986]**
- positive folds: **4/5**
- positive ID blocks: **4/5**
- worst fold: **-0.0000597**
- family Jaccard: **0.62**

Nested DEVELOPMENT behavior:
- 19 changed users
- 13 Top1 changes
- 6 rank-2/3 swaps
- 13 beneficial
- 6 harmful
- benefit:harm = 13:6 ≈ 2.17:1
- Top5 membership unchanged
- ranks 5–17 unchanged

Selected diagnostic mixture:
- anchor: 33.3%
- `v1_final_blend`: 16.7%
- `v5_primary`: 16.7%
- `v2_supervised_multimodal`: 16.7%
- `v4_lambdarank`: 16.7%

No deployment occurred initially because preregistered DEVELOPMENT gain failed. LOCK stayed sealed.

### Important V49 caveats

- Current champion does not have a perfectly honest historical OOF equivalent; V30 was used as a train proxy.
- Historical candidate universe has been adaptively researched for weeks.
- V1/V2 surfaces have known validation→public transfer gaps.
- Many late surfaces are correlated or fail-closed descendants.
- Thus +0.000199 incremental OOF was considered too small to trust.

---

## 11. V49 public diagnostic probe

Because the user had 3 daily slots and planned to let a teammate use the other 2, one controlled diagnostic slot was intentionally allocated.

Codex exported the frozen selected policy without:
- retuning,
- opening LOCK,
- changing coverage/weights,
- redesigning V49.

Diagnostic file facts:
- changed test users: **28**
- Top1 changes: **13**
- other head-order changes: **15**
- Top5 membership changes: **0**
- SHA256:
  `2618ae7182ca071e77655e0b1da2f81ac6ed7a0bc552cf5e8af08815cfec026c`

Public result:
- **0.65986**

Compared with 0.66028 anchor:
- **-0.00042**

This is a decisive recent finding because OOF predicted +0.0001993 with a positive CI, but public was materially negative.

Interpretation:
- historical old-model diversity was real in OOF,
- but the selected diversity was **not transportable** to test,
- the sign reversed,
- therefore do not retune V49 weights based on that public score,
- do not conclude "200-model ensemble" is automatically appropriate for this lineage.

V49 is best described as:
- **research success:** it executed and answered a question;
- **leaderboard failure:** candidate was harmful.

---

## 12. Why several approaches keep failing

### A. Small validation gains are below the transport noise floor
Recent repeated evidence suggests +1e-4 to +3e-4 offline deltas are not reliable enough.

### B. Validation is adaptively researched
The project has repeatedly revisited:
- CAL-like partitions,
- similar template groups,
- related feature families,
- public feedback.
Even without direct target leakage, this creates meta-overfitting.

### C. Late models share ancestry
Many V30+ outputs are nearly identical. "Many versions" does not mean many independent errors.

### D. Old diverse models are often weak for a reason
V49 showed that complementarity can select V1/V2/V4/V5, but their historical errors can poison test.

### E. Champion OOF proxy mismatch
The actual 0.66028 champion is a surgically composed test policy. Using V30 OOF as its train proxy is imperfect, so incremental OOF gain may not represent incremental gain against the true deployed champion.

### F. Wrong action class
Lower-order edits are weak-leverage and less learnable. Top1 decisions dominate NDCG economics.

### G. Semantic relevance is not personalized order
Knowing a user's topic does not solve readiness/path ordering.

---

## 13. What is still alive

Do not interpret the research as "nothing works."

Strong evidence still supports:

1. **Sparse lexical/topic modeling** as the backbone.
2. **Residual learning-to-rank** when it produces a robust enough improvement, as V30 did.
3. **Cross-representation agreement** as a precision filter, not necessarily as broad blending.
4. **Very selective Top1 authority**.
5. **Frozen champion geometry** and minimal change count.
6. **Prospective validation that is genuinely new**, not another reuse of already-mined splits.
7. **Independent teammate pipelines**. After V49, genuinely independent work now has more expected information value than further micro-tuning the same historical archive.

---

## 14. Current action state

At the time of this handoff:
- Best score remains **0.66028**.
- V49 diagnostic scored **0.65986** and should not replace the champion.
- The historical-prediction ensemble branch should be considered closed in its current form.
- The user planned to let their teammate handle the remaining two daily submission slots with an independent direction.
- Do not use V49 public failure to tune weights or cherry-pick historical models.

The next chat should start from this state, not from "let's ensemble more old models."
