# MineToday Full Chat Handoff
## Data Mining Competition – IT Today 2026
**State captured:** 2026-09-05, after V49 diagnostic public submission.

This package is a narrative handoff of the MineToday work represented in the current ChatGPT project/chat context. It intentionally contains **no notebooks, model binaries, prediction arrays, result folders, or submissions**. It explains the project state so another chat/agent can continue without re-discovering the whole lineage.

## Current headline

- Task: recommend the top-5 Intelligo learning modules per user.
- Metric: user-level **NDCG@5**.
- Dataset: 4,000 train users, 1,000 test users, 17 modules.
- Best confirmed public score from this lineage: **0.66028**.
- Approximate competitor references discussed in chat:
  - top-5 cutoff around **0.66076**
  - leader around **0.66142**
- Latest public diagnostic:
  - V49 diagnostic ensemble: **0.65986**
  - change vs 0.66028 anchor: **-0.00042**
- Today after that probe:
  - 1 submission slot used by this branch
  - 2 remaining daily slots were planned to be handled by the user's teammate using an independent direction.

## Most important conclusion right now

The project is no longer bottlenecked by raw model capacity. The repeated bottleneck is **validation-to-test transfer and decision authority**:

1. Head ordering, especially Top1, has high metric leverage.
2. There is still substantial oracle headroom because the correct Top1 is often already inside the champion Top4.
3. Many offline-positive selectors, residuals, semantic systems, pruning rules, and ensembles do not transfer reliably to the 1,000-user test set.
4. Broad/model-level improvements are highly correlated in the late lineage.
5. Historical diversity exists, but V49 showed that weak-old-model diversity selected by nested OOF can still be **toxic on public test**.
6. Public-proven surgical actions from V30/S3/B34/B45 are more trustworthy than small generic offline deltas.
7. The current **0.66028 anchor should remain protected** unless a new candidate has genuinely stronger, cleaner evidence.

## Recommended reading order

1. `00_START_HERE/MASTER_HANDOFF.md`
2. `05_CURRENT_STATE_AND_NEXT_STEPS/CURRENT_STATE.md`
3. `03_RESEARCH_AND_DIAGNOSIS/CORE_FINDINGS.md`
4. `02_EXPERIMENT_HISTORY/VERSION_LINEAGE.md`
5. `03_RESEARCH_AND_DIAGNOSIS/FAILURE_MODES_AND_LEAKAGE.md`
6. `04_V47_V48_V49_RECENT_WORK/RECENT_WORK.md`
7. `05_CURRENT_STATE_AND_NEXT_STEPS/WHAT_REMAINS.md`

## Critical rule for the next chat

Do **not** assume that a small positive OOF delta is submission-worthy. V49 gave the clearest recent counterexample:

- nested OOF predicted **+0.0001993**
- bootstrap CI was positive
- 4/5 folds and 4/5 ID blocks were positive
- public LB nevertheless moved **0.66028 → 0.65986**

That sign reversal must materially change how future evidence is weighted.
