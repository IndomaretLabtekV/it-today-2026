# Core Research Findings

## Finding 1: The head is the problem worth solving
The metric and empirical learnability both favor the top of the list.

Top1 and B12 have the most leverage and the most signal.
B45/B56 are near chance and small-value.

Therefore future work should generally optimize:
- Top1 correctness,
- top head order,
- confidence/authority,
rather than lower-boundary reshuffling.

## Finding 2: Correct Top1 is often already in the champion Top4
Oracle audits repeatedly showed major headroom.
This means candidate generation is not the core problem.

The real problem is:
**when should the system move rank2/3/4 to rank1?**

## Finding 3: Selection/authority is the dominant bottleneck
Many systems can generate a plausible challenger.
Very few can distinguish beneficial from harmful overrides at the precision required for a 0.66028+ anchor.

## Finding 4: Sparse lexical representation is genuinely strong
The dataset's templated language makes word/char TF-IDF unusually effective.
Deep semantic encoders have not consistently beaten this as a broad model.

## Finding 5: Semantics is useful but not sufficient
Latest-topic semantics captures topical relevance.
It does not reliably capture:
- readiness,
- learning progression,
- prerequisite state,
- exact within-user ordering.

## Finding 6: Consensus can be valuable
V30/V31 showed that a worse standalone model can still help when its agreement with another model identifies a high-precision region.

This remains valid even after V49; what V49 invalidated was broad reliance on old-model diversity, not the concept of high-precision cross-view agreement.

## Finding 7: Public-proven surgical actions are unusually valuable
A handful of Top1 actions generated larger LB movement than dozens of lower-order edits.

Protect these actions.

## Finding 8: OOF quality alone is not enough
The project has multiple examples where:
- OOF looked strong,
- public was flat or negative.

V49 is the clearest latest example:
- nested OOF +0.0001993
- positive bootstrap CI
- public -0.00042.

## Finding 9: Version count is not diversity
By late versions, many prediction surfaces are near-identical descendants of the same anchor.

Earlier audit found:
- dozens of submission files collapse to far fewer unique Top5 surfaces,
- late V30+ surfaces are highly correlated.

## Finding 10: Old-model diversity can be toxic
V49 selected V1/V2/V4/V5 because they added complementary OOF error information.
Public result was harmful.

Therefore:
- diversity must be transportable,
- not merely low correlation.

## Finding 11: Gross train/test shift is not the main issue
Adversarial AUC near 0.51 suggests no huge global distribution shift.
The transfer problem is more likely:
- subtle latent state mismatch,
- validation adaptivity,
- template dependence,
- champion proxy mismatch,
- tiny action-count variance.

## Finding 12: Small gains are below the reliable transport threshold
The latest evidence strongly suggests that +0.0001 to +0.0003 OOF gains should be treated as weak evidence, even with decent fold signs.

Any new candidate likely needs a materially larger and cleaner prospective effect.
