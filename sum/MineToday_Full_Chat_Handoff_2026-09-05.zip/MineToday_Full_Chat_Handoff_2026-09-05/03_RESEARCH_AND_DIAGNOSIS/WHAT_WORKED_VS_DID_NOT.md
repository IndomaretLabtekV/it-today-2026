# What Worked vs What Did Not

## Durable positive evidence

### Sparse word+char TF-IDF
Why it worked:
- language is templated,
- lexical cues strongly map to module relevance,
- low variance and robust.

Use:
- continue as backbone/reference.

### V30 residual LambdaRank
Why it mattered:
- broad but still transferred,
- public gain about +0.00044 over V25,
- one of few strong broad residual successes.

Use:
- retain as a key structural reference.

### V30/V31 agreement geometry
Why it mattered:
- V31 standalone worse,
- agreement identified higher-precision subsets.

Use:
- cross-view consensus is still a valid *precision filter* concept.

### Public-proven Top1 packages
Why they matter:
- few actions caused large LB movements.

Use:
- protect from generic reranking.

### B34 tiny lower-order contribution
Modestly positive.
Keep only because already integrated and publicly supported.

---

## Repeatedly weak / negative / low-EV

### Broad semantic blending
Problem:
- relevance ≠ personalized order.
- often correlated with topical anchor.

### Generic membership editing
Problem:
- membership actions often display-flat or harmful.
- champion membership is already strong.

### B23/B45/B56 mining
- B23 specifically harmful in public decomposition.
- B45 tiny.
- B56 near chance.
Low expected value.

### High-capacity residual/meta models on small action sets
Problem:
- can learn noise from few beneficial actions,
- unstable across folds/templates.

### Pruning public-proven Top1 authority
Problem:
- directly reduced public score.

### Historical broad Borda/average ensembling
Problem:
- correlated model voting adds little,
- diverse weak models can dominate disagreements,
- earlier Borda-like attempts were poor.

### V49 old-model ensemble
Problem:
- nested OOF found a positive mixture,
- public sign reversed.
Do not keep tuning it.

### Train-analogue action family logic
V45 showed analogues that look good in train may not transfer to exact unseen test actions.

---

## Unresolved rather than failed

### E5/Nomic semantic utility
V47 never completed embeddings.

### Qwen multi-view V48
V48 never reached actual ensemble evaluation.

These can only be revisited if there is a compelling implementation reason and genuinely new validation, not as another automatic next version.
