# Failure Modes, Leakage, and Validation Risks

## No evidence of direct forbidden leakage
The project has not found evidence of:
- deliberate test-label leakage,
- external ground-truth usage,
- same-user target leakage intentionally fed into test prediction.

The major problem is subtler: **validation validity**.

## 1. Template-family dependence
Chat templates repeat heavily.
Random/group-insufficient splits can let nearly identical language structures occur on both sides.

V35.1 demonstrated that template-held-out confirmation can reverse earlier optimism.

## 2. Adaptive validation contamination
Over dozens of versions, the research process repeatedly examined:
- similar CAL sets,
- similar LOCKs,
- module families,
- action regions,
- public LB responses.

Even if each individual run is technically OOF, the *researcher* has adapted to the validation distribution.

This is meta-overfitting.

## 3. Reused CAL / pseudo-public sets
Historical validation sets were sometimes reused for:
- thresholding,
- module selection,
- action family selection,
- architecture decisions.

Do not call these pristine holdouts later.

## 4. Second-level / stacking dependency
Some historical versions such as V13.1 and V41 had concerns where second-level features or model selection were not fully independent of the evaluation fold.

Any future stacker must use genuinely cross-fitted base predictions.

## 5. False ensemble independence
Different version names can share:
- same sparse base,
- same V30 anchor,
- same features,
- same folds,
- same action geometry.

Treat family ancestry as part of dependence.

## 6. Champion proxy mismatch
The actual 0.66028 public champion is a surgically composed test policy.
There is no exact honest OOF equivalent for all of those public-informed protected actions.

V49 used V30-like OOF as an anchor proxy.
Therefore an incremental gain vs OOF proxy need not equal incremental gain vs deployed champion.

## 7. Small action sample variance
Many later experiments change only 3–30 users.
This is desirable for safety, but it creates:
- huge variance in per-action public value,
- unstable benefit:harm estimates,
- easy sign reversal.

## 8. Public leaderboard adaptation
Public causal probes were scientifically useful, but repeated use means the final 0.66028 champion itself contains public-informed decisions.

Future research should not over-interpret the public LB as an optimization target.

## 9. Runtime failures are not scientific failures
V46, V47, V48 each failed before their intended hypothesis was actually evaluated.

Do not mark:
- dual semantic,
- E5/Nomic competence,
- protected multi-view ensemble
as conceptually refuted merely because environment/model loading failed.

## 10. Historical standalone OOF is not directly comparable
V49 surfaced `v13_router` at ~0.66705 standalone OOF.
That does not mean it would score 0.667 public.

Different historical protocols, splits, and adaptation make absolute OOF numbers non-exchangeable.

Prefer:
- incremental, matched-protocol deltas,
- prospective locked validation,
- true independent confirmations.
