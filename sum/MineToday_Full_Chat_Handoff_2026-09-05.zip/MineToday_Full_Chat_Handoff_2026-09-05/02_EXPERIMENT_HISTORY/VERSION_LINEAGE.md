# Experiment Lineage V1–V49

This document emphasizes the lineages that materially changed understanding. Not every historical filename is reproduced; the goal is to preserve all currently known experimental conclusions.

## V1–V2: early multimodal / baseline era
Early systems established usable predictions but had significant validation/transfer gaps.

V1 later reappeared as a diverse historical expert in V49, not because it was strong standalone but because its errors differed from the late anchor.

V2 similarly supplied a multimodal historical surface. In V49 it was selected by nested ensemble search, but the eventual public ensemble failed, reinforcing that old diversity can be toxic.

## V3 / V3.1
V3 semantic cross-encoder direction was not the durable breakthrough.

**V3.1 sparse word + character TF-IDF** became the major durable base representation and ancestor of the strongest lineages.

Lesson:
- templated language strongly favors sparse lexical representations,
- deep semantic complexity is not automatically superior.

## V4–V6
Ranking / LambdaRank and nesting work established stronger ranking behavior.
V6 is remembered especially for more defensible nested evaluation patterns.

V4 later entered the V49 selected mixture as a diverse LambdaRank surface.

## V7–V11
A series of calibration, foldbag, pairwise, distribution-preserving, ordinal, and related variants.

Broad conclusion:
- many locally attractive calibration changes did not reliably produce public gains,
- small calibration deltas were not durable enough.

## V12 / V12.1 / V12.2
Module-specialized/calibrated sparse lineage.

V12.2 produced the durable **Consensus3** style baseline and explicit OOF artifacts.

Consensus3 public was roughly **0.65856** and became an important anchor/ancestor for many later models.

Important lesson:
cross-representation or cross-profile **consensus** could be more useful than broad deployment of every expert.

## V13 / V13.1
Router / second-order approaches.

Some OOF metrics looked strong. Later research marked portions of this family as questionable for second-level dependency/nesting.

V13.1 in particular should not be treated as clean efficacy evidence.

In V49:
- `v13_router` had standalone OOF around **0.66705**,
- but was not trusted as an immediate submission because absolute historical OOF is not equal to transportable incremental value.

## V14–V15
Pairwise and surgical voting experiments.

Helped reinforce:
- narrow interventions can be safer than broad reranking,
- but low-boundary signals remain weak.

## V16–V22
Semantic embedding / Qwen / BGE-related and module-trust iterations.

Some semantic experiments generated useful diversity, but broad semantic policies repeatedly failed to dominate the sparse/ranker anchor.

Approximate strong progression:
- V22.3 ~**0.65912**

One durable insight:
semantic relevance may contribute as a second opinion, but should not automatically receive ranking authority.

## V23
Action-level semantic/ranking experiment with detailed action artifacts.

Not a durable public breakthrough. Useful mainly as evidence that action selectors can overfit despite rich representations.

## V24–V26
Public probes and distilled/surgical action packages.

V25 became a strong anchor around **0.65919**.

These versions increasingly shifted from "train a better whole model" toward "identify a few high-value corrections."

## V27–V29.5
Head-boundary, hierarchy/curriculum, uncertainty, and structural audits.

Broad result:
- many plausible structural heuristics did not transfer strongly,
- lower-boundary mining was not the missing signal,
- offline/pseudo-public validation could be misleading.

## V30
Major residual LambdaRank breakthrough.

Approximate public:
**0.65963**, about +0.00044 over V25.

This is one of the strongest examples of a broad residual method that genuinely transferred.

V30 remains one of the most important historical experts and the approximate OOF proxy later used for the final champion.

## V31
Intent × module × readiness state representation.

Whole model public:
~**0.65949**, worse than V30.

New-only behavior also underperformed.

But the **disagreement/agreement geometry** with V30 was useful. Certain overlap regions produced some of the best later gains.

This is a foundational lesson:
**standalone quality != marginal ensemble/consensus utility.**

## V32–V34
Objective diversity, XE/Yeti residuals, protected residuals, cross-encoder/head attacks.

Broad policies were not the decisive solution.

Hybrid/overlap geometry eventually produced:
- Hybrid34 around **0.66006**

## V35 / V35.1
IndoBERT/TAPT structural experiment.

Initial positive-looking evidence was corrected by stronger fold-pure/template-held-out confirmation.

V35.1 is one of the clearest reminders that template leakage/overlap can create false confidence.

## V36–V38
Meta policies, selectors, XLM-R, pressure/corridor experiments.

Generated substantial diagnostics but not a durable public improvement beyond the protected anchor lineage.

## V39 / V39.1 / V39.5
Trajectory/pairwise and boundary decomposition.

V39.5 public probes became extremely important for causal attribution:
- B23 harmful
- B34 modestly positive
- B45 tiny positive
- lower-order package removable
- head actions much more valuable

## V40
Prerequisite/curriculum membership direction.
Did not establish a meaningful new durable signal.

## V41 / V41.1 / V41.2
Qwen semantic selector / complementarity studies.

One version had second-level dependency concerns and should not be treated as clean efficacy evidence.

V41.2 reinforced:
- huge oracle Top1 headroom,
- semantic scores can identify relevant modules,
- selector/authority remains the bottleneck.

## V42–V45
Generator-state, empirical Bayes/support, pruning, action family audits.

V44 pruning and V45 legacy analog audits did not produce a new robust candidate.

Important V45 lesson:
train-analogue utility did **not** reliably transfer to unseen exact test actions.

## V46
Dual semantic experiment intended to test semantic consensus.

Runtime/tokenizer dependency failure before embeddings.
Oracle looked large, but hypothesis was not executed.

## V47
Rebuilt semantic competence test using E5 + Nomic, stricter nesting, risk-coverage and one-shot LOCK.

Again failed during Nomic loading.
Hypothesis unresolved.

## V48
Protected multi-view ensemble: Consensus3 + V30 + V31 + Qwen.

Failed at Qwen runtime/environment compatibility.
Hypothesis unresolved.

## V49
Historical OOF/test prediction warehouse and conservative ensemble search.

First recent ensemble experiment to genuinely execute.

Nested OOF:
+0.0001993, positive CI, 4/5 fold/block.

Frozen diagnostic public:
**0.65986**, a -0.00042 regression vs champion.

Conclusion:
the specific historical diversity strategy is not transportable enough and should not be tuned further from public feedback.
