# Public Score and Action History

## Approximate major public progression

| Milestone | Public score / effect |
|---|---:|
| Consensus3 | ~0.65856 |
| V22.3 | ~0.65912 |
| V25 | ~0.65919 |
| V30 | ~0.65963 |
| V31 whole | ~0.65949 |
| Hybrid34 | ~0.66006 |
| S3 | ~0.66020 |
| B34 | ~0.66026 |
| B34+B45 | **0.66028** |
| V49 diagnostic ensemble | **0.65986** |

Approximate external references discussed:
- top-5 threshold: ~0.66076
- leader: ~0.66142

## Proven action-level public evidence

### S3
Approximate package:
- 3 Top1 actions
- 4 membership actions
- 27 lower-order actions

Ablation findings:
- remove 3 Top1 → roughly -0.00056
- remove 4 membership → display-flat
- B23 component → ~-0.00022
- B34 → ~+0.00006
- B45 → ~+0.00002
- remove all lower-order 27 → ~+0.00014

### V30 S2 Top1
Removing four protected V30 S2 Top1 actions caused roughly:
0.66028 → 0.66000

### Implication
Do not let a generic new ensemble or selector overwrite already public-proven Top1 decisions unless evidence is extraordinarily strong.

## Recent daily-probe context
A previously generated 0.66028 minus S3 membership-4 probe was display-flat, confirming those membership actions were not material at displayed precision.

Later, on 2026-09-05:
- user had 3 daily slots available,
- one was intentionally spent on V49 diagnostic,
- result 0.65986,
- remaining 2 slots were planned for teammate's independent experiments.
