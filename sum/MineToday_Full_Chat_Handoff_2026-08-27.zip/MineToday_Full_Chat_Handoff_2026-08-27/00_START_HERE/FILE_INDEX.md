# File Index

## 00_START_HERE

- `README.md` — pintu masuk paket.
- `CURRENT_STATUS.md` — leaderboard dan kondisi submission sekarang.
- `ONE_PAGE_CHEATSHEET.md` — ringkasan angka dan keputusan.
- `NEXT_CHAT_BOOTSTRAP.md` — prompt siap tempel.
- `FILE_INDEX.md` — indeks ini.

## 01_COMPETITION_DATA_RULES

- `COMPETITION_AND_METRIC.md` — objektif dan NDCG@5.
- `DATASET_AND_TARGET_FINDINGS.md` — audit data utama.
- `MODULE_CATALOG.md` — mapping 17 modul.
- `RULES_AND_COMPLIANCE.md` — aturan TM dan status compliance.

## 02_EXPERIMENT_HISTORY

- `MASTER_TIMELINE_V1_V25.md` — seluruh versi.
- `PUBLIC_SCOREBOARD.md` — semua public score yang tercatat.
- `V23_POSTMORTEM.md` — F2LLM local-action corrector.
- `V24_POSTMORTEM.md` — causal micro-probe.
- `V25_DESIGN_AND_PUBLIC_RESULT.md` — core-6/aggressive-9 dan hasilnya.

## 03_RESEARCH

- `METHODS_AND_PAPERS.md` — paper/metode yang ditinjau.
- `EMBEDDING_RESEARCH.md` — Qwen, BGE, F2LLM, SEA-Embedding.
- `WHAT_RESEARCH_SURVIVED.md` — ide yang masih layak.

## 04_DIAGNOSIS

- `ROOT_CAUSE_SYNTHESIS.md` — kenapa progres sulit.
- `FAILURE_CATALOG.md` — percobaan gagal dan penyebabnya.
- `VALIDATION_AND_REPRODUCIBILITY.md` — leakage, geometry mismatch, environment drift.
- `PUBLIC_PRIVATE_INTERPRETATION.md` — cara membaca skor few-user.

## 05_CURRENT_STATE

- `EXACT_ACTION_LEDGER.md` — seluruh swap penting.
- `KNOWN_VS_UNCERTAIN.md` — fakta vs inferensi.
- `ARTIFACT_MAP.md` — lokasi artefak repo tanpa menyertakan filenya.

## 06_NEXT_STEPS

- `PRIORITY_PLAN.md` — urutan kerja setelah reset.
- `EXPERIMENT_BACKLOG.md` — kandidat eksperimen terkontrol.
- `DO_NOT_REPEAT.md` — blacklist hemat waktu.
- `PRIVATE_FINAL_SELECTION.md` — strategi pemilihan submission final.

## 07_CHAT_HANDOFF

- `CURRENT_CHAT_NARRATIVE.md` — alur percakapan V23–V25.
- `DECISION_LOG.md` — pivot keputusan.
- `OPEN_QUESTIONS.md` — hal yang belum terjawab.
- `READY_TO_PASTE_NEXT_CHAT.txt` — bootstrap versi singkat.

## 08_REFERENCE

- `GLOSSARY.md` — istilah proyek.
- `SCORE_ALGEBRA.md` — dekomposisi skor.
- `V25_EVIDENCE_TABLE.md` — evidence sembilan actions.
- `ARCHIVE_CONTENT_POLICY.md` — apa yang sengaja masuk/tidak masuk ZIP.

## 09_ARCHIVE_PRIOR_HANDOFFS

Berisi dokumentasi handoff 26 Agustus secara lengkap. Handoff tersebut sudah menyertakan arsip 23 dan 24 Agustus, sehingga histori sebelum V23 tetap tersedia tanpa notebook/results mentah.

