# One-Page Cheatsheet

## Angka utama

- Train: 4,000 user.
- Test: 1,000 user.
- Modul: 17.
- Chat: 14,573 baris / 4,940 user.
- Train tanpa chat: 117.
- Test tanpa chat: 33.
- Metrik: user-level NDCG@5.
- Submission: maksimal 3/hari.
- PB terbaru: **0.65919**.
- Leader terakhir: **0.66083**.
- Gap: **0.00164**.

## Score timeline ringkas

`V1 0.63629 -> V2 0.64413 -> V3.1 0.65036 -> cal035 0.65540 -> cal045 0.65639 -> V12.2 0.65856 -> V21.1 0.65869 -> V22.3 0.65912 -> V25 0.65919`

## Yang berulang kali bekerja

- word + char TF-IDF;
- current/recent chat weighting;
- assessment/readiness features;
- binary per-module relevance calibration;
- tiny module-specific smooth weights;
- fail-closed/abstention;
- exact local score swaps;
- public decomposition dengan satu hipotesis per submission.

## Yang berulang kali gagal

- generic/larger embeddings sebagai replacement;
- global semantic blend;
- user router;
- Borda/foldbag/repeated averaging;
- generic Top-6 atau #5/#6 pairwise reranking;
- LambdaRank/free reranking;
- exact template-to-label lookup;
- positive-count 4/5/6 predictor;
- broad prerequisite-first rules;
- QLoRA residual yang terlalu bebas;
- joint calibration baru yang salah target atau tidak lolos LOCK.

## Temuan data terpenting

- Text organizer sangat templated, tetapi target tidak deterministic dari template.
- Positive modules per user selalu 4/5/6.
- Ordered target sequence hampir unik: sekitar 3,960 dari 4,000.
- Explicit topic sudah sangat mudah bagi Consensus3.
- Sekitar 95.6% missed-positive events berasal dari modul yang tidak disebut eksplisit.
- Remaining headroom lebih banyak berupa latent curriculum/next-step inference dan noise, bukan kekurangan semantic encoder.

## V23–V25 dalam satu kalimat

- V23: F2LLM direct-action utility corrector gagal seluruh promotion gate; primary kembali ke PB.
- V24: causal micro-probe; U4498 tambahan tidak mengubah skor `0.65912`.
- V25: distill action lama menjadi core-6; naik kecil ke `0.65919`; relaxed-3 tidak mengubah display.

## Prinsip untuk chat berikutnya

Jangan bertanya “model apa yang lebih canggih?” sebelum menjawab “user dan pasangan modul mana yang masih salah, apa bukti action itu transferable, dan apakah submission tersebut memberi informasi baru?”

