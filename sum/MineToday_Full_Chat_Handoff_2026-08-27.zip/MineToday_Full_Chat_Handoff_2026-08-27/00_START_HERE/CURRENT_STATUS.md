# Current Status — Wajib Dibaca

## Leaderboard

| Kandidat | Public NDCG@5 | Delta vs Consensus3 | Status |
|---|---:|---:|---|
| V12.2 Consensus3 | 0.65856 | baseline | anchor utama |
| V22.3 U4047 + U4953 | 0.65912 | +0.00056 | PB lama |
| V24 PB + U4498 | 0.65912 | +0.00056 | tidak mengubah display |
| V25 PB + core-6 | **0.65919** | **+0.00063** | PB terbaru |
| V25 PB + aggressive-9 | **0.65919** | **+0.00063** | sama dengan core-6 |
| Top-1 terakhir | 0.66083 | +0.00227 vs Consensus3 | target |

Gap PB terbaru ke Top-1 adalah `0.66083 - 0.65919 = 0.00164`.

## Apa yang baru terbukti

1. Enam action core V25 secara agregat memberi public delta sekitar `+0.00007` di atas PB `0.65912`.
2. Tiga action tambahan aggressive-9 memberi displayed delta `0.00000` di atas core-6.
3. Public leaderboard belum bisa mengidentifikasi action core mana yang positif karena keenamnya disubmit sekaligus.
4. Public leaderboard juga belum bisa memastikan apakah relaxed-3 berada di private subset.

## Action yang ada di PB terbaru

PB terbaru memuat dua koreksi lama dan enam action core:

- U4047: M007 di atas M009.
- U4953: M005 di atas M016.
- U4074: M003 di atas M014.
- U4176: M017 di atas M003.
- U4491: M002 di atas M003.
- U4567: M012 di atas M014.
- U4836: M002 di atas M003.
- U4929: M002 di atas M003.

Aggressive-9 menambahkan:

- U4030: M003 di atas M007.
- U4650: M012 di atas M003.
- U4731: M006 di atas M014.

## Status submission hari ini

Urutan kejadian:

1. V24 PB + U4498 disubmit dan mendapat `0.65912`.
2. V25 core-6 + PB disubmit dan mendapat `0.65919`.
3. V25 aggressive-9 + PB disubmit dan mendapat `0.65919`.

Dengan asumsi ketiganya terjadi pada hari kompetisi yang sama, jatah `3 submission/hari` sudah habis. Jangan submit lagi sebelum reset harian.

## Status teknis V25

- Notebook V25 terdiri dari 19 cell dan lulus full execution lokal.
- LightGBM dipin ke `4.6.0`, versi yang dipakai run Kaggle V24.
- Canonical core submission berbeda tepat 8 user / 16 score-cell dari Consensus3.
- Canonical aggressive submission berbeda tepat 11 user / 22 score-cell dari Consensus3.
- Contract notebook dan canonical result lulus.
- Ada risiko reproducibility karena run lokal memakai NumPy/pandas/sklearn berbeda dari image Kaggle V24; detail ada di `../04_DIAGNOSIS/VALIDATION_AND_REPRODUCIBILITY.md`.

## Kesimpulan saat ini

Kita belum menemukan model general yang jelas mengalahkan anchor. Peningkatan terbaru datang lagi dari **few-user surgical ranking actions**, bukan embedding atau reranker global. Namun public delta core-6 terlalu kecil untuk menyimpulkan keluarga rule tersebut sudah tervalidasi secara general.

