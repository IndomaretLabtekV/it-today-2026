# MineToday Full Chat Handoff — 27 Agustus 2026

Paket ini adalah handoff lengkap untuk melanjutkan proyek **MineToday: Data Mining Competition — IT Today 2026** di chat baru. Isinya merangkum konteks kompetisi, dataset, seluruh eksperimen V1–V25, riset metode dan paper, leaderboard forensics, kesalahan metodologi, status submission terbaru, serta pekerjaan yang masih tersisa.

## Baca dengan urutan ini

1. `CURRENT_STATUS.md` — posisi leaderboard dan arti hasil terbaru.
2. `ONE_PAGE_CHEATSHEET.md` — angka dan keputusan terpenting.
3. `NEXT_CHAT_BOOTSTRAP.md` — konteks siap tempel ke chat baru.
4. `../02_EXPERIMENT_HISTORY/MASTER_TIMELINE_V1_V25.md` — seluruh perjalanan eksperimen.
5. `../04_DIAGNOSIS/FAILURE_CATALOG.md` — hal yang sudah gagal dan jangan diulang.
6. `../06_NEXT_STEPS/PRIORITY_PLAN.md` — apa yang sebaiknya dilakukan selanjutnya.

## Snapshot terkini

- Anchor lama: V12.2 Consensus3, public `0.65856`.
- PB sebelum V25: Consensus3 + koreksi U4047 dan U4953, public `0.65912`.
- V24 menambah U4498 dan tetap `0.65912`.
- V25 core-6 + PB mendapat **`0.65919`**.
- V25 aggressive-9 + PB juga mendapat **`0.65919`**.
- Top-1 terakhir yang disebut: `0.66083`.
- Gap PB terbaru ke Top-1: `0.00164`.

## Interpretasi yang aman

Core-6 memberi peningkatan public kecil sekitar `+0.00007`. Tiga action tambahan pada aggressive-9 tidak mengubah skor yang ditampilkan. Itu **tidak membuktikan** ketiga user pasti berada di private subset. Kemungkinan lain adalah relevansi kedua modul sama, efek saling meniadakan, atau delta berada di bawah presisi tampilan.

## Batas isi paket

Paket ini sengaja tidak menyertakan file notebook, dataset, model, cache embedding, NPZ, maupun submission CSV. Semua artefak tersebut hanya dijelaskan dan dipetakan melalui dokumentasi. Arsip handoff 26 Agustus disertakan sebagai dokumentasi historis dan di dalamnya sudah tercakup handoff 23 dan 24 Agustus.

