# Public Scoreboard

| Candidate | Public NDCG@5 | Delta vs previous relevant anchor | Evidence |
|---|---:|---:|---|
| V1 | 0.63629 | — | public |
| V2 | 0.64413 | +0.00784 | public |
| V3.1 sparse | 0.65036 | +0.00623 | public |
| cal035 | 0.65540 | +0.00504 | public |
| Borda | 0.65489 | -0.00051 vs cal035 | public |
| cal045 | 0.65639 | +0.00099 vs cal035 | public |
| V8 repeated | 0.65577 | -0.00062 vs cal045 | public |
| V8 foldbag | 0.65140 | -0.00499 vs cal045 | public |
| V9.1 | 0.65432 | -0.00207 vs cal045 | public |
| V12 Leader6 | 0.65792 | +0.00153 vs cal045 | public |
| V12.2 Consensus3 | 0.65856 | +0.00064 | public |
| V13.1 | 0.65754 | -0.00102 vs Consensus3 | public |
| V18 | 0.65829 | -0.00027 | public |
| V19 | 0.65791 | -0.00065 | public |
| V21 | 0.65786 | -0.00070 | public |
| V21.1 | 0.65869 | +0.00013 | public |
| V21.2 | 0.65776 | -0.00080 | public |
| V22.1 M003/M014 | 0.65846 | -0.00010 | public |
| V22.2 four changes | 0.65878 | +0.00022 | public |
| V22.3 U4047+U4953 | 0.65912 | +0.00056 | public |
| V24 PB+U4498 | 0.65912 | +0.00000 vs PB | public |
| V25 core-6+PB | **0.65919** | **+0.00007 vs PB** | public |
| V25 aggressive-9+PB | **0.65919** | **+0.00000 vs core** | public |

Top-1 terakhir: `0.66083`. PB terbaru masih tertinggal `0.00164`.

## Catatan presisi

Semua delta leaderboard adalah dari angka yang ditampilkan. Exact internal delta tidak diketahui. Jangan melakukan algebra seolah presisinya tak terbatas.

