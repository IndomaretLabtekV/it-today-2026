# V23 Postmortem — F2LLM Local-Action Utility Corrector

## Tujuan

Mencari pendekatan fresh tanpa merusak PB `0.65912`: bukan meranking ulang 17 modul, melainkan memprediksi exact NDCG utility dari satu local score swap.

## Arsitektur

- Exact V3.1/V7/V12.2 Consensus3 anchor.
- Reconstruct public PB dengan U4047 dan U4953.
- Candidate hanya low-margin Top-7 local pairs.
- Novel Top-1 changes dilarang.
- Maksimal satu action per user.
- Organizer prerequisite graph menjadi feature/gate, bukan hard rule.
- Structured branch: score geometry, assessment, mention flags, module identities, prerequisite flags.
- Hybrid branch: structured features + frozen `codefuse-ai/F2LLM-v2-4B` similarities.
- F2LLM views: latest chat, last-three trajectory, dan chat + assessment profile.
- Direct target: exact change in user NDCG@5 jika score values ditukar.
- Hard semantic negatives di-upweight.
- Pair families ditemukan hanya di outer-train fold.
- Conservative/balanced/confirmed policies dengan intervention cap.

## Kenapa approach ini secara teori masuk akal

- Directly optimizes action utility, bukan generic module relevance.
- Local action menjaga anchor.
- Semantic model berfungsi sebagai feature extractor, bukan test-label generator.
- Outer-fold isolation mengurangi action-family leakage.
- Fail-closed primary mencegah forced deployment.

## Hasil real

### Conservative

- 10 fold-wise selected actions.
- OOF delta `+0.0000012127`.
- Precision 0.40.
- Selected mean delta `+0.000485`.
- 3/5 fold wins.
- Worst fold `-0.00003194`.
- Promotion gate gagal.
- Test actions: 3.

### Balanced

- 25 selected.
- OOF delta `-0.0000191052`.
- Precision 0.32.
- Selected mean delta `-0.003057`.
- Worst fold `-0.00011612`.
- Promotion gate gagal.
- Test actions: 6.

### Confirmed

- Satu selected OOF action.
- OOF delta `-0.000006588`.
- Precision 0.
- 0 fold wins.
- Test actions: 1.

## Temuan diagnostic

- Structured dan hybrid branches berbagi sekitar 93% features.
- Predicted utility correlation sekitar 0.79; agreement bukan independent confirmation.
- Raw direct-prerequisite action mean sekitar `-0.01090`.
- q10-margin prerequisite action mean sekitar `-0.00658`.
- U4047/U4953 archetype analogues di OOF tidak menunjukkan positive generalization.
- Embedding/action confidence tidak meranking beneficial swaps dengan cukup baik.

## Keputusan

`primary_policy = pb_reference`. V23 primary tidak mengubah PB. Ini adalah hasil fail-closed yang benar, bukan kegagalan pipeline. Yang gagal adalah hipotesis bahwa F2LLM + structured agreement mampu memprediksi transferable local utility.

## Jangan salah baca

V23 tidak membuktikan F2LLM sebagai embedding buruk. Ia membuktikan bahwa incremental action utility di atas strong anchor tidak cukup learnable oleh setup ini.

