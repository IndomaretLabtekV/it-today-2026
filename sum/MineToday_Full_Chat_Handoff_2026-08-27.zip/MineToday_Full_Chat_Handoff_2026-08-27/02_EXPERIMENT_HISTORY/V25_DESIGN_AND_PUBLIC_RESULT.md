# V25 Design and Public Result

## Motif

V24 tidak menaikkan PB dan waktu/submission tinggal sedikit. V25 mencari action family yang sudah pernah menyentuh public leaderboard, bukan melatih encoder/ranker baru.

## Public-action distillation

Source action family adalah 32 ranking changes dari V21.1 stable035, submission yang pernah mendapat `0.65869`. Empat action sudah didekomposisi lebih dahulu. Remaining actions dipindai menggunakan:

- exact latest-learning-chat skeleton;
- train analog support;
- count pairwise positive vs harmful relevance differences;
- mean pair relevance delta;
- tiny Consensus3 score margin;
- exclusion U4047/U4498/U4876/U4953 dari novel set.

## Core-6 gates

- support minimal 10;
- pair positives minus harms minimal 3;
- pair mean delta positif;
- frozen full Consensus3 margin maksimal 0.002.

Core users:

- U4074 M003>M014;
- U4176 M017>M003;
- U4491 M002>M003;
- U4567 M012>M014;
- U4836 M002>M003;
- U4929 M002>M003.

## Relaxed-3 extension

Tiga next-best shrunken pair-evidence candidates:

- U4030 M003>M007;
- U4650 M012>M003;
- U4731 M006>M014.

Support/margin threshold sedikit dilonggarkan sampai support 9 dan margin 0.0028.

## Output strategy

Karena V24 sudah memakai satu dari tiga slots, pure probe dianggap tidak mampu mengejar leader. Dua remaining attacks:

1. PB + core-6.
2. PB + core-6 + relaxed-3.

## Public results

- Core-6 submission: **0.65919**.
- Aggressive-9 submission: **0.65919**.

## Apa yang dapat disimpulkan

- Core-6 family secara agregat memberikan displayed `+0.00007` di atas PB.
- Relaxed-3 memberikan displayed `0.00000` incremental effect.
- Core-6 belum cukup untuk mencapai `0.66083`.
- General family belum tervalidasi karena action individual tidak diisolasi.

## Apa yang tidak dapat disimpulkan

- Tidak diketahui action core mana yang positif/negatif/private.
- Tidak diketahui relaxed users pasti private.
- Public equality tidak memprediksi private effect.
- Template pair evidence belum terbukti sebagai calibrated utility score.

## Technical verification

- Notebook: 19 cells.
- LightGBM pinned `4.6.0`.
- Primary canonical diff: 8 users, 16 cells vs Consensus3.
- Lastshot canonical diff: 11 users, 22 cells vs Consensus3.
- Notebook SHA256 pada snapshot: `9cfcd6ddfdcbf8adf3186981303b92a83e43290302e6754b8c8fd1f98990b968`.
- Primary CSV SHA256: `2e9d9553db483d68d98a2a97cc421bc9c996a22e77be755c2b652e7d3f481d4a`.
- Lastshot CSV SHA256: `db78bb7d03bf978113e1973aa48cf78414d71b608bb504324683638d69fd4fd4`.

