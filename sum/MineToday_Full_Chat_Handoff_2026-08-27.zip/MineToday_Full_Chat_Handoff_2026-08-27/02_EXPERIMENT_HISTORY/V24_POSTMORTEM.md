# V24 Postmortem — Causal Public Micro-Probes

## Mengapa V24 dibuat

Setelah V23 menolak semua action policies, membuat semantic model baru tidak mempunyai evidence. V24 kembali ke deterministic public-score algebra di atas exact PB.

## Kandidat

1. Consensus3 + U4047 only.
2. Consensus3 + U4953 only.
3. PB + U4498.
4. PB + U4876.

Setiap kandidat mengubah tepat satu user dan dua numeric score cells terhadap base-nya. Tidak ada retraining hypothesis di layer action.

## Dekomposisi sebelum submission

- `B = 0.65856`.
- `B + a + b = 0.65912` untuk U4047 dan U4953.
- `B + a + b + c + d = 0.65878` untuk four-change.
- Maka `c + d ≈ -0.00034`, tetapi sign individual belum diketahui.

## Submission dan hasil

`PB + U4498` disubmit. Public tetap `0.65912`, sama dengan PB.

## Interpretasi valid

U4498 mempunyai displayed public effect nol.

## Interpretasi yang tidak valid

Tidak boleh langsung menyatakan U4498 pasti private. Satu action dapat terlihat nol jika:

- user tidak termasuk public subset;
- swapped modules mempunyai relevance sama;
- swap tidak mengubah effective public NDCG;
- delta lebih kecil daripada precision display.

## Pelajaran

Micro-probe memberi clean causal evidence, tetapi satu daily slot yang menghasilkan zero display tetap belum mengidentifikasi mechanism. Dengan gap 0.00171 saat itu, user kemudian memilih pendekatan lebih agresif untuk dua slot tersisa.

