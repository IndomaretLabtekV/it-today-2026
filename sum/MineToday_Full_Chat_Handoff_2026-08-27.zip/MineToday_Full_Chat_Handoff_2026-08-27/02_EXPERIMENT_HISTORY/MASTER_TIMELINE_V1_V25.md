# Master Timeline V1–V25

## V1–V2: semantic-heavy starting point

### V1 — 0.63629

Hybrid Qwen 0.6B, reranker, TF-IDF, LambdaRank, dan template memory. Terlalu banyak moving parts dan belum mempunyai anchor yang terkalibrasi.

### V2 — 0.64413

Mengganti semantic encoder dengan model multilingual lebih besar. Naik dari V1, tetapi masih jauh di bawah sparse approach berikutnya. Pelajaran: model semantic lebih besar bukan bottleneck utama.

## V3–V7: sparse and relevance calibration breakthrough

### V3.1 sparse — 0.65036

- word TF-IDF ngram;
- char TF-IDF;
- clean text dan typo robustness;
- latest/recent trajectory tags;
- template tokens;
- assessment + invalid flags;
- sparse Ridge multi-output.

Ini menjadi backbone semua versi kuat berikutnya.

### Calibration family

- `cal035`: 0.65540.
- Borda/rank fusion: 0.65489, lebih buruk.
- `cal045`: 0.65639.

Binary relevance LightGBM per modul memberi gain publik terbesar setelah sparse backbone. Probability-like score lebih berguna daripada rank fusion.

## V8–V12.2: stability attempts and module weights

### V8

- repeated-seed averaging: 0.65577;
- foldbag: 0.65140.

Averaging mengubah score geometry dan bukan improvement gratis.

### V9.1

Residual/adaptive correction, public 0.65432. Local residual learnability tidak transfer.

### V10–V11 family

Berbagai adjustment dan diagnostic mengarah pada kesimpulan bahwa global residual/routing terlalu bebas. Detail historis lengkap tersedia di arsip 23/24/26 Agustus.

### V12 Leader6 — 0.65792

Small module-specific calibration changes memperbaiki public.

### V12.2 Consensus3 — 0.65856

Hanya delapan modul memakai tiny override dari reference weight 0.45:

- M002 0.44;
- M006 0.55;
- M007 0.60;
- M010 0.40;
- M011 0.55;
- M012 0.55;
- M015 0.44;
- M017 0.53.

Consensus3 menjadi immutable anchor untuk eksperimen selanjutnya.

## V13–V15: routers, pairwise, and abstention

### V13.1 — 0.65754

Selective dual-expert router terlihat kuat lokal, tetapi public turun. Ditemukan second-level non-nested leakage dan OOF/full-fit geometry mismatch.

### V14

Fully nested Top-6 pairwise ranker. Honest nested validation negatif; generic boundary reversal AUC sekitar 0.52.

### V15

Fully nested surgical utility router menghasilkan zero actions. Ini merupakan fail-closed yang benar: jangan memaksa coverage jika action utility tidak learnable.

## V16–V20: large semantic exploration

### V16

Frozen Qwen3-Embedding-8B. Tidak ada kandidat yang lolos gate.

### V17

Top-5-aware module semantic representation. Gain kecil dan tidak stabil; tidak dipromosikan.

### V18 — 0.65829

Multi-intent prototype/metric semantic. Hampir anchor tetapi tetap turun.

### V19 — 0.65791

Ordinary-first stable semantic. Local views terlihat baik, public turun.

### V20

Contrastive late-interaction + BGE auxiliary. Gagal gate; evidence BGE untuk beneficial corrections sekitar chance dan mendilusi Qwen.

## V21 family: QLoRA and ranking objectives

### V21 — 0.65786

Qwen3-Embedding-8B 4-bit QLoRA, relevance-first, semantic-aware module calibrators. Untouched LOCK sempat terlihat positif, tetapi deployment surface tidak faithful: residual dinilai pada weaker ADAPT anchor lalu dipasang ke full Consensus3.

### V21.1 — 0.65869

Bagged lower-capacity stable-module calibration. Hanya sekitar 32 test users berubah; public naik kecil `+0.00013`. Ini kemudian menjadi sumber action family untuk public decomposition dan V25.

### V21.2 — 0.65776

Anchor-initialized semantic LambdaRank dengan trust-region/rank-safe. CAL tidak stabil dan public turun. Objective NDCG yang benar tidak membuat residual yang lemah menjadi learnable.

## V22: exact public decomposition

### V22.1 FIRSTSHOT — 0.65846

Menjaga behavior M003/M014 dari V21.1. Hasil lebih buruk dari Consensus3, sehingga bulk M003/M014 bukan sumber gain.

### V22.2 four changes — 0.65878

Empat exact changes: U4047, U4498, U4876, U4953.

### V22.3 two changes — 0.65912

Hanya U4047 dan U4953. Ini membuktikan dua action lain mempunyai combined effect sekitar `-0.00034` relative terhadap pair winner, dengan batas pembulatan.

## V23: F2LLM direct-action utility corrector

Anchor: exact PB `0.65912`. Model membentuk local Top-7 score-swap candidates, novel Top-1 lock, structured utility branch, serta F2LLM-v2-4B hybrid utility branch.

Hasil:

- conservative OOF delta `+0.00000121`, tetapi worst fold negatif dan gate gagal;
- balanced OOF delta `-0.00001911`;
- confirmed OOF delta `-0.00000659`, precision 0;
- raw prerequisite actions negatif;
- `primary` fail-closed menjadi byte-identical PB reference.

Tidak ada alasan deployment/public submission dari model V23.

## V24: causal micro-probes

V24 berhenti mencari embedding baru dan mengekspor exact single-hypothesis swaps:

- U4047-only;
- U4953-only;
- PB + U4498;
- PB + U4876.

Yang disubmit adalah PB + U4498 dan public tetap `0.65912`. Makna aman: U4498 memberi displayed public delta nol; tidak diketahui apakah private-only, relevance tie, atau delta di bawah rounding.

## V25: public-action distillation

V25 menyeleksi enam action V21.1 dengan exact latest-skeleton support, pairwise label evidence, dan tiny Consensus3 margin. Core-6 dipasang di atas two-user PB.

Public:

- PB + core-6: **0.65919**;
- PB + core-6 + relaxed-3: **0.65919**.

Core-6 net displayed gain: `+0.00007`. Relaxed-3 displayed incremental gain: `0.00000`.

## Thesis akhir snapshot

Semakin luas dan bebas model mengubah ranking, semakin buruk transfer. Semua progress publik setelah Consensus3 datang dari tiny module calibration atau few-user exact score swaps. Headroom masih ada, tetapi evidence density per submission sangat rendah.

