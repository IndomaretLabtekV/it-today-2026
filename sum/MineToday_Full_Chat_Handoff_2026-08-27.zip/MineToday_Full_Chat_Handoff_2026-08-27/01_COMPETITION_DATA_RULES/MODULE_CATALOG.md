# Module Catalog

| ID | Modul | Level/prerequisite ringkas |
|---|---|---|
| M001 | Pengolahan data dengan MS Excel | pemula |
| M002 | Python Programming | pemula |
| M003 | SQL | pemula |
| M004 | Web Scraping | menengah; butuh Python |
| M005 | Version Control | menengah |
| M006 | Statistik | menengah |
| M007 | EDA | menengah; butuh Python dan statistik |
| M008 | Dashboard | menengah; butuh SQL/Excel |
| M009 | Machine Learning | lanjutan; butuh EDA dan statistik |
| M010 | Computer Vision | lanjutan; butuh ML/deep learning |
| M011 | NLP | lanjutan; butuh ML |
| M012 | Generative AI | lanjutan; butuh NLP |
| M013 | Prompt Engineering | menengah |
| M014 | AI Automation | menengah |
| M015 | Pemanfaatan AI / No Code | pemula |
| M016 | MLOps | ahli; butuh ML, Python, Version Control |
| M017 | Pengembangan Karier dan Portofolio | semua level |

## Graph yang paling relevan

- M002/M006 -> M007.
- M006/M007 -> M009.
- M009 -> M010/M011.
- M011 -> M012.
- M002/M005/M009 -> M016.
- M001/M003 -> M008.

Graph ini berasal dari katalog organizer, sehingga legal digunakan. Namun broad rule “selalu taruh prerequisite di atas destination” terbukti negatif secara OOF. Graph hanya layak sebagai context/candidate generator, bukan universal ranking constraint.

