# Technical Meeting Rules and Compliance

## Aturan resmi yang relevan

- Akun/email dan nama tim Kaggle harus sesuai registrasi; merge team sebelum submit.
- Maksimal 3 submissions per tim per hari.
- Tidak boleh menggunakan data eksternal; hanya dataset panitia.
- Boleh menggunakan lebih dari satu model machine learning.
- Boleh menggunakan Python, R, atau bahasa sejenis.
- Tidak boleh kerja sama antar-tim.
- Pretrained model diperbolehkan hanya jika open source; pretrained berbayar dilarang.
- LLM/Generative AI tidak boleh dipakai untuk langsung meminta nilai/prediksi test.
- AI coding assistant diperbolehkan.
- Notebook prediksi dan seed randomness wajib dikumpulkan.
- Notebook harus sesuai output; toleransi perbedaan skor yang disebut TM adalah `0.001`.

## Compliance eksperimen

### V23

- Memakai `codefuse-ai/F2LLM-v2-4B` open source sebagai frozen feature extractor.
- Tidak memakai `.generate()`.
- Tidak meminta LLM menebak test labels.
- Hanya meng-encode chat, assessment, dan katalog resmi.
- Secara desain sesuai aturan pretrained model/LLM yang dijelaskan TM.

### V24 dan V25

- Tidak memakai external task data.
- Tidak meminta prediksi test dari LLM.
- V24/V25 menggunakan sparse sklearn + LightGBM dan deterministic score swaps.
- Paper eksternal hanya dipakai untuk ide metodologi, bukan sebagai source label/data.

## Risiko compliance/reproducibility yang masih harus ditutup

- Canonical V25 CSV dibangun dari exact V24 Consensus3 reference dan action list, sedangkan notebook merecompute backbone. Pastikan run notebook final di image Kaggle menghasilkan ranking/action yang sama.
- Pin seluruh package yang memengaruhi score geometry, bukan hanya LightGBM, atau simpan environment version log di notebook.
- Simpan seed `42` dan deterministic config.
- Jangan menyerahkan CSV yang notebook finalnya tidak bisa reproduksi dalam toleransi panitia.

## Kesimpulan

Metode V23–V25 tidak menyalahi larangan external data atau direct LLM test inference. Risiko nyata bukan legalitas model, melainkan **reproducibility exact output** lintas versi environment.

