# Competition and Metric

## Use case

MineToday meminta peserta membangun **AI Course Advisor** untuk merekomendasikan lima modul Intelligo paling relevan bagi setiap user. Sistem harus menggabungkan profil kemampuan, assessment, perjalanan chat, intent terkini, serta hubungan kemampuan saat ini dengan target belajar/karier.

Output bukan satu kelas, melainkan ranking skor untuk seluruh 17 modul. Evaluasi mengambil lima modul teratas per `user_id`.

## Dataset resmi

- `chat_history.csv` — riwayat percakapan user.
- `modules_catalog.csv` — katalog 17 modul, syllabus, dan prerequisite level.
- `user_assessments.csv` — assessment 10 skill per user.
- `train_relevance.csv` — target relevance 17 modul untuk 4,000 user train.
- `test.csv` — 1,000 user yang harus diprediksi.
- `sample_submission.csv` — schema submission.

## NDCG@5

Untuk setiap user, prediksi diurutkan dari skor terbesar. Discounted Cumulative Gain:

`DCG@5 = sum(relevance_at_rank_i / log2(i + 1)), i=1..5`

Kemudian:

`NDCG@5 = DCG@5 / IDCG@5`

Skor kompetisi adalah rata-rata user-level NDCG@5. Konsekuensinya:

- urutan di Top-5 penting, walaupun membership sama;
- swap dua skor hanya memengaruhi user tersebut;
- contribution action antar-user bersifat additive pada skor mean sebelum pembulatan leaderboard;
- action di luar Top-5 tidak berpengaruh sampai mengubah ordering/membership Top-5;
- public few-user probes bisa dianalisis dengan score algebra, tetapi tetap tunduk pada subset dan rounding.

## Jadwal penting dari Technical Meeting

- Kaggle: 19 Agustus–9 September 2026.
- Pengiriman notebook: 10–14 September 2026.
- Penilaian submission/notebook: 15–19 September 2026.
- Pengumuman finalis: 20 September 2026.
- Lima tim teratas lolos final jika notebook dan output sesuai aturan.

