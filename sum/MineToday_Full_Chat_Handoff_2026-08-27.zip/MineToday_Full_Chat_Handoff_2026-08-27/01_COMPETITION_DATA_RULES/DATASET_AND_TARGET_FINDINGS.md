# Dataset and Target Findings

## Shape dan coverage

- Train relevance: `(4000, 18)` termasuk `user_id`.
- Test: `(1000, 1)`.
- Modules catalog: 17 modul.
- Chat: 14,573 baris untuk 4,940 user.
- Assessment: 5,000 user × satu serialized result berisi 10 skill.
- 117 train user dan 33 test user tidak memiliki chat.
- Assessment mengandung sekitar 251 invalid cells dari 50,000; pipeline V3.1 melakukan robust parsing dan median repair.

## Template structure

- Sekitar 69.9% normalized test chat rows exact-match dengan normalized train chat.
- Sekitar 95.8% test users yang memiliki chat mempunyai setidaknya satu message yang pernah terlihat di train.
- High text repetition tidak berarti target deterministic.
- Topic substitution dan skeleton template membantu sparse model, tetapi direct template-to-label lookup gagal transfer.

## Target structure

- Setiap train user memiliki tepat 4, 5, atau 6 positive modules.
- Relevance values tersusun dalam band yang rigid, sekitar `1.00`, `0.80–0.90`, `0.65–0.75`, `0.50–0.60`, `0.35–0.45`, dan `0.20–0.30`.
- Sekitar 3,960 ordered positive sequences unik dari 4,000 user.
- Prediksi jumlah positive modules 4/5/6 mendekati chance.
- Exact within-band jitter tampak lebih dekat ke latent/stochastic component daripada target yang bisa dipelajari stabil.

## Intent and learnability

- Explicit current/recent module mentions sangat mudah bagi sparse lexical anchor.
- Consensus3 mempunyai Top-5 recall sangat tinggi pada current-topic modules.
- Sekitar 95.6% missed-positive module events adalah modul yang tidak disebut eksplisit.
- Remaining signal kemungkinan berasal dari latent curriculum, readiness, prerequisite, career path, dan generator behavior yang tidak sepenuhnya terobservasi.

## Train/test behavior

- Train dan test mengikuti ID berurutan; beberapa versi mengeksplorasi potential ID/time drift.
- Module prevalence/calibration cukup stationary untuk memberi public gains.
- Conditional residual action utility jauh kurang stationary.
- Exact template groups dapat memiliki target heterogeneity besar, sehingga group lookup harus dianggap feature, bukan oracle.

## Implikasi modeling

1. Pertahankan word/char sparse representation.
2. Bedakan latest, recent, dan older intent.
3. Gunakan assessment sebagai readiness, bukan sekadar dense feature dump.
4. Fokus pada relevance probabilities dan Top-5 boundary.
5. Jangan mengharapkan embedding lebih besar mengungkap modul latent yang tidak tertulis.
6. Residual action harus selective dan deployment-matched.

