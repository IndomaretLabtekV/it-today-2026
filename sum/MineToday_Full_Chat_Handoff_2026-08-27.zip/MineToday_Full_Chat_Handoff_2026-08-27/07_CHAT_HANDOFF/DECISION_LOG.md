# Decision Log

| Tahap | Keputusan | Evidence/alasan | Konsekuensi |
|---|---|---|---|
| Pra-V23 | Pertahankan lexical/calibrated ensemble sebagai anchor | V12–V22 menunjukkan model ringan plus targeted correction paling kuat | Model baru harus membuktikan incremental lift |
| V23 design | Pakai F2LLM-v2-4B sebagai frozen local-action evidence | Embedding global lama gagal; local correction lebih sesuai gap kecil | GPU dipakai untuk kandidat terbatas, bukan global rewrite |
| V23 validation | Outer-fold isolation dan fail-closed gate | Risiko leakage dan high variance | Primary kembali persis ke PB ketika gate gagal |
| V23 result | Jangan promote semantic corrector | Lift ~1e-6, precision 0.4, worst fold negatif | Tidak membakar submission untuk model tanpa evidence |
| Rules audit | V23/V24/V25 dinilai compliant | Open-source pretrained diperbolehkan; tidak direct LLM prediction | Tetap wajib provenance, seed, dan notebook correspondence |
| V24 | Pivot ke few-user causal probe | Broad modeling stagnan, quota terbatas | U4498 diuji di atas PB |
| V24 result | Jangan klaim private dari equal score | 0.65912 dapat dijelaskan beberapa mekanisme | Evidence ditandai censored/ambiguous |
| V25 false lead | Tolak Calibration@5 spike | Ditemukan label construction bug; fixed version gagal LOCK | Angka bug tidak boleh dipakai lagi |
| V25 validation | Tolak near-tie family rule | CAL positif, LOCK negatif | LOCK menjadi hard gate |
| V25 design | Distill sembilan actions menjadi core-6 dan relaxed-3 | Analog support dan harm filtering lebih presisi | Dua kandidat berbeda coverage dibuat |
| Repro incident | Bekukan margins, buat promotion idempotent, materialisasi dari V24 reference | Package drift mengubah sparse/Ridge geometry | Output kanonis tidak bergantung trigger lokal |
| V25 submit 1 | Submit PB+core-6 | Kandidat paling konservatif | Public naik 0.65912 → 0.65919 |
| V25 submit 2 | Submit core-6+relaxed-3 | Mencari tambahan upside/information | Public tetap 0.65919 |
| Post-V25 | Primary menjadi anchor sementara | Public terbaik dan lebih sedikit action daripada lastshot | Lastshot bukan default private choice |
| Next direction | Prioritaskan action attribution + selective counterfactual teacher | Aggregate package signal ada, global model ceiling jelas | Hindari another giant embedding blend |

## Keputusan yang belum dibuat

- Subset terbaik dari core-6.
- Apakah relaxed-3 dibuang permanen atau diuji ulang hanya lewat OOF evidence.
- Model open-source mana yang dipakai bila cross-encoder teacher benar-benar diperlukan.
- Candidate final kedua untuk hedge private.
- Package lock final untuk notebook Kaggle submission.
