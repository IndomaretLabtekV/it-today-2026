# Open Questions

## Highest priority

1. Dari enam core actions, action mana yang menyumbang lift +0.00007 dan mana yang mungkin harm/nol?
2. Apakah output `notebooks/v25.ipynb` dapat direproduksi byte-identical pada Kaggle T4x2 dengan package lock eksplisit?
3. Apakah counterfactual swap classifier mempunyai positive lower confidence bound pada untouched LOCK?
4. Candidate mana yang memberi error diversity terbaik terhadap V25 primary untuk private final?

## Validation

- Seberapa stabil action precision pada alternate user splits dan bootstrap?
- Apakah neighbor support berasal dari banyak user independen atau template cluster yang sama?
- Apakah LOCK sudah terlalu sering dilihat sehingga tidak lagi benar-benar untouched?
- Apakah module-pair imbalance membuat support count menyesatkan?
- Berapa risk-coverage threshold yang bisa dipilih tanpa memakai LOCK?

## Semantics and features

- Apakah joint cross-encoder scoring lebih baik dari cosine embeddings untuk pasangan near-tie?
- Bagian chat mana yang paling informative: latest intent, career goal, atau seluruh history?
- Bisakah assessment gap dan prerequisite relation menambah precision bila dipakai sebagai soft feature?
- Apakah M002/M003 dan M012/M014 memerlukan specialist rules/models?

## Leaderboard interpretation

- Apakah displayed +0.00007 berasal dari satu public user atau beberapa delta kecil?
- Apakah relaxed-3 benar-benar tidak berpengaruh, atau efeknya tersensor pembulatan?
- Seberapa besar risiko PB/core actions overfit public split?

## Operational

- Berapa submission slot/final selection yang tersisa menurut aturan Kaggle terkini?
- Model revision dan package versions apa yang tersedia offline di Kaggle pada final rerun?
- Apakah notebook final menghasilkan file dengan nama, row order, dan ranking identik?

Pertanyaan leaderboard yang tidak bisa dijawab dari data lokal harus ditandai sebagai unknown; jangan diisi dengan cerita yang terasa masuk akal.
