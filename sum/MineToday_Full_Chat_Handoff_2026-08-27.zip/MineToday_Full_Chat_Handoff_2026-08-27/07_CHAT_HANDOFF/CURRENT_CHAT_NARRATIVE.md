# Current Chat Narrative

Dokumen ini merekonstruksi percakapan dan pekerjaan aktif yang melahirkan V23–V25. Detail sebelum fase ini tersedia lengkap di arsip handoff 26 Agustus.

## Titik awal

User menjelaskan kompetisi **MineToday: Data Mining Competition – IT Today 2026**: membangun AI Course Advisor yang merekomendasikan top-5 modul per user dan dinilai dengan NDCG@5. User meminta seluruh folder `sum/`, `notebooks/`, `results/`, dan `data/` dibaca agar konteks eksperimen V1–V22 tidak hilang.

State saat itu:

- public score terbaik 0.65912;
- peringkat sekitar top 4, kemudian turun ke top 5;
- top-1 0.66083;
- gap sangat kecil tetapi eksperimen global sudah stagnan;
- tersedia tiga submission harian baru.

## Permintaan fresh approach

User awalnya meminta notebook V23 setelah deep analysis terhadap seluruh eksperimen. Fokus yang diminta:

- cari penyebab skor naik/turun;
- evaluasi kegagalan versi lama;
- riset paper dan embedding lebih kuat;
- buat notebook Kaggle-ready untuk GPU T4x2;
- jangan puas dengan increment kecil; target mengalahkan 0.66083.

Terjadi beberapa koreksi penamaan: user sempat menyebut V25, lalu menjelaskan seharusnya V23, kemudian meminta output berikutnya menjadi V24 karena V23 sudah dibuat. Interpretasi akhir yang dipakai adalah: **evaluasi V23 yang sudah ada, lalu buat V24 dari temuannya**. Setelah V24 selesai dan stagnan, fresh approach berikutnya dinamai **V25**. Jangan mengubah nomor ini lagi.

## V23 — semantic local-action corrector

V23 memakai `codefuse-ai/F2LLM-v2-4B` sebagai frozen embedding model, bukan meminta LLM menebak jawaban test secara langsung. Rancangannya:

- baseline kuat tetap menjadi anchor;
- model semantik mencoba memperbaiki pasangan modul lokal;
- fitur structured dan hybrid ikut diuji;
- retrieval/action evidence dibuat outer-fold isolated;
- primary memakai fail-closed gate: bila validation tidak cukup kuat, output kembali persis ke PB.

Hasil utamanya:

- conservative OOF lift hanya sekitar +0.00000121;
- precision action 0.4;
- 3 dari 5 fold menang;
- worst fold negatif;
- balanced variant sekitar -0.00001910;
- confirmed subset sekitar -0.00000659 dengan precision nol pada evaluasi terkait;
- structured dan hybrid berbagi sekitar 93% fitur dan prediksinya berkorelasi sekitar 0.79;
- prerequisite-derived actions sangat negatif.

Kesimpulan: representasi semantik yang lebih besar tidak otomatis menyelesaikan keputusan top-5. Gate gagal, sehingga primary V23 sengaja byte-identical dengan PB. Itu adalah perilaku benar, bukan crash.

## Audit peraturan

User mengunggah `docs/TM MINETODAY.pdf` dan meminta jawaban singkat apakah notebook masih patuh. PDF kemudian diaudit. Aturan relevan:

- maksimal tiga submissions per hari;
- dilarang external data;
- multiple ML models diperbolehkan;
- pretrained open-source diperbolehkan, paid pretrained tidak;
- tidak boleh meminta LLM/GenAI secara langsung memprediksi data test;
- AI coding assistant diperbolehkan;
- notebook dan seed wajib;
- final notebook output harus sesuai dengan submission dalam toleransi 0.001.

V23 dinilai masih sesuai karena menggunakan frozen open-source embeddings sebagai komponen ML. V24/V25 juga sesuai. Risiko yang harus tetap dijaga adalah provenance model, tidak adanya external enrichment, serta exact reproducibility notebook-output.

## V24 — causal micro-probe

Karena model baru tidak lolos gate dan waktu submission sudah malam, V24 berpindah dari broad modeling ke causal probing. Kandidat dibangun sebagai perubahan minimal terhadap PB:

- U4047-only;
- U4953-only;
- PB + U4498;
- PB + U4876.

Tujuannya memperoleh information gain leaderboard per perubahan, bukan membuat ensemble besar lagi. User kemudian men-submit PB+U4498. Public score tetap **0.65912**, identik dengan PB.

Interpretasi yang benar: probe tidak menghasilkan displayed lift. Skor sama tidak cukup untuk menyimpulkan U4498 berada di private split.

## Dari stagnasi ke V25

User menyatakan frustrasi karena score stagnan, rank turun ke 5, dan meminta approach lain. Permintaan menyebut “buatkan v24”, tetapi konteks dan koreksi sebelumnya menetapkan notebook baru sebagai V25. User dua kali menegaskan agar pendekatan fresh langsung dikerjakan selama memang berpotensi melampaui 0.66083.

Analisis tambahan menemukan bahwa banyak pendekatan global telah mencapai ceiling. Fokus digeser ke **distilled analog local actions**:

- pertahankan PB;
- cari test action dengan analog train yang directionally mendukung swap;
- gunakan support, positive/harm counts, margin, dan stabilitas;
- bagi kandidat menjadi conservative core dan relaxed extension;
- materialisasi submission deterministik.

## Bug/false lead selama V25

Sebuah eksperimen Cross-module Calibration@5 sempat menunjukkan spike. Audit target menemukan bug: user dengan empat positive modules diberi zero-label arbitrer sebagai item kelima “relevan”. Setelah label diperbaiki, konfigurasi fixed `C=1`, `alpha=0.04` gagal pada untouched LOCK. Branch itu ditolak dan tidak menjadi V25.

Near-tie exact-template family juga CAL-positive tetapi LOCK-negative. Ini memperkuat keputusan untuk tidak memilih kandidat berdasarkan CAL saja.

## Reproducibility incident

V24 Kaggle merekam NumPy 2.0.2, pandas 2.3.3, LightGBM 4.6.0. Environment lokal V25 memakai NumPy 2.5.2 dan pandas 3.0.5, serta sempat LightGBM 4.7 sebelum dipin ke 4.6. Sparse/Ridge geometry berubah; action trigger yang seharusnya 6 hanya muncul 4.

Perbaikannya:

- action promotion dibuat idempotent;
- frozen margins/evidence dicatat;
- submission kanonis dibangun dari exact V24 reference;
- test kontrak ditambahkan;
- hash notebook dan submissions dicatat.

Insiden ini penting: perubahan package dapat mengubah ranking near-tie walau kode dan seed tampak sama.

## V25 yang disubmit

Primary adalah PB plus core-6: U4074, U4176, U4491, U4567, U4836, dan U4929. Public score **0.65919**, naik **0.00007**.

Lastshot menambah relaxed-3: U4030, U4650, dan U4731. User bertanya apakah tetap perlu submit setelah primary hanya 0.65919; arahan singkat saat itu adalah evaluasi berbasis slot/information value. Lastshot akhirnya disubmit dan juga memperoleh **0.65919**.

User menanggapi bahwa hasil sama berarti private. Koreksi konseptual yang harus diteruskan: itu salah satu kemungkinan, bukan satu-satunya. Pembulatan, zero-effect, relevance tie, atau cancellation juga mungkin.

## Kondisi saat handoff dibuat

- Public terbaik: V25 primary/lastshot, 0.65919.
- Top-1 terakhir diketahui: 0.66083.
- Gap: 0.00164.
- Hari submission yang dibahas kemungkinan sudah memakai 3/3 slot: V24, V25 primary, V25 lastshot.
- Belum ada bukti bahwa relaxed-3 layak dipertahankan untuk private.
- Pekerjaan berikutnya harus memisahkan attribution core-6, mengunci environment, lalu menguji selective counterfactual/action teacher dengan untouched LOCK.

## Permintaan handoff terakhir

User meminta satu `.zip` di `sum/` yang menjelaskan seluruh progress, sisa kerja, state sekarang, research, temuan, eksperimen, faktor tidak efektif/salah, dan rekomendasi—selengkap mungkin, dibagi beberapa folder, tanpa notebook atau results mentah. Paket 27 Agustus ini adalah jawaban atas permintaan tersebut dan menyertakan dokumentasi handoff lama sebagai arsip internal.
