# Priority Plan

Target berikutnya bukan membuat model paling kompleks. Targetnya adalah menutup gap public **0.00164** tanpa menghancurkan anchor 0.65919 dan tanpa mengulang selection bias yang sama.

## P0 — bekukan state dan pulihkan reproducibility

Sebelum eksperimen model baru:

1. Jadikan V25 primary 0.65919 sebagai anchor aktif; simpan byte-identical CSV dan checksum.
2. Jalankan notebook V25 di Kaggle T4x2 dengan versi package dicatat lengkap.
3. Pastikan output primary dan lastshot identik dengan artefak kanonis, bukan sekadar mempunyai nama/ranking yang mirip.
4. Verifikasi 1.000 user, tepat lima modul unik per user, seluruh modul valid, tidak ada user hilang/duplikat.
5. Catat seed, model revision, tokenizer revision, CUDA/PyTorch/Transformers/NumPy/pandas/scikit-learn/LightGBM.

Alasan: eksperimen lanjutan tidak berguna bila perubahan skor ternyata berasal dari drift environment.

## P1 — attribution, bukan paket baru besar

Public result V25 hanya mengidentifikasi core-6 sebagai paket. Gunakan OOF counterfactual dan bootstrap user untuk mengurutkan enam tindakan berdasarkan:

- mean delta NDCG@5;
- lower confidence bound;
- jumlah analog independen;
- stability antar seed/fold/environment;
- disagreement antar lexical, structured, dan semantic evidence.

Tujuannya menemukan subset core yang lebih presisi. Jangan memakai leaderboard untuk brute-force seluruh kombinasi. Dengan kuota tiga per hari, maksimal satu probe yang benar-benar membedakan hipotesis dan sisanya untuk kandidat final terkuat.

## P2 — build selective teacher, bukan global replacement

Fresh approach yang paling masuk akal adalah **cross-encoder/listwise teacher untuk candidate reranking dengan abstention**:

1. Anchor tetap menghasilkan top-5/top-7.
2. Teacher hanya menilai pasangan near-tie pada boundary dan pasangan action yang mempunyai analog support.
3. Training menggunakan train-only user folds; seluruh fitur target-derived dibuat OOF.
4. Calibrate probability bahwa swap menaikkan user-level NDCG, bukan probability relevansi modul secara global.
5. Terapkan hanya jika lower confidence bound positif dan model-family agreement cukup tinggi.

Teacher bisa memakai encoder open-source yang diizinkan aturan. Embedding besar sendiri bukan objective; objective adalah prediksi **delta ranking action**.

## P3 — robust local-action validation

Bangun evaluation protocol tetap:

- grouped repeated CV pada user;
- fold isolation untuk retrieval/neighbor selection;
- report mean, median, worst-fold, win rate, precision, harm rate, coverage;
- bootstrap CI pada aggregate delta;
- untouched LOCK set yang tidak dipakai tuning;
- gate konservatif dan default exact anchor ketika gate gagal.

Satu eksperimen dinyatakan layak hanya jika menang di CAL dan LOCK, bukan karena satu angka CV.

## P4 — submission strategy

Setiap hari:

- Submission A: kandidat paling konservatif dan reproducible.
- Submission B: satu ablation/informative probe yang membedakan dua hipotesis penting.
- Submission C: kandidat diversified untuk risiko private, bukan variasi hampir identik tanpa tujuan.

Catat hash, exact diff terhadap anchor, hipotesis, expected sign, hasil public, dan interpretasi alternatif.

## Stop conditions

Jangan submit kandidat bila:

- mengubah ratusan user tanpa LOCK lift yang stabil;
- hanya menaikkan in-sample/CAL;
- evidence dibangun menggunakan target validation user;
- output bergantung package drift;
- tidak ada exact diff ledger;
- gagal mengalahkan anchor dalam lower-confidence-bound atau tidak memberi diversifikasi private yang jelas.
