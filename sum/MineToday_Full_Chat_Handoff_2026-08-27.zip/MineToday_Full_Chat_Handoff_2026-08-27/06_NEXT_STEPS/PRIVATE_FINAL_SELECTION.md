# Private Final Selection

Public-best bukan otomatis private-best. Setelah banyak few-user probes, risiko public overfitting meningkat. Pemilihan final harus mempertahankan dua tujuan: kualitas expected private dan diversifikasi model error.

## Kandidat yang saat ini tersedia

| Kandidat | Public | Sifat | Risiko |
|---|---:|---|---|
| V22.3 PB | 0.65912 | Dua public-validated targeted actions | Dapat terlalu bergantung pada public split |
| V25 primary | 0.65919 | PB + core-6 | Public terbaik saat ini; attribution core belum diketahui |
| V25 lastshot | 0.65919 | PB + core-6 + relaxed-3 | Lebih agresif, tidak memberi displayed public lift |
| Consensus/OOF anchor family | sekitar 0.65856 untuk Consensus3 | Lebih sedikit public-derived correction | Public lebih rendah tetapi bisa menjadi hedge private |

## Rekomendasi saat ini

Jika final submission slot memungkinkan lebih dari satu pilihan, jangan memilih primary dan lastshot sebagai satu-satunya portfolio karena keduanya hampir identik. Prioritas sementara:

1. **V25 primary** sebagai public champion.
2. **Satu conservative validation champion** yang dipilih tanpa public micro-probe berlebihan sebagai hedge private.

Lastshot layak menggantikan hedge hanya jika evidence OOF baru mengisolasi relaxed-3 sebagai stabil positif. Skor sama 0.65919 saja tidak cukup.

## Checklist sebelum final lock

- Konfirmasi jumlah final submissions yang diizinkan oleh Kaggle/aturan pada saat itu.
- Re-run notebook terkait pada Kaggle dan cocokkan checksum/ranking.
- Audit exact diff antar kandidat; pilih error diversity nyata.
- Jangan menggunakan private leaderboard—tidak tersedia—sebagai alasan imajiner.
- Nilai ulang candidate berdasarkan untouched LOCK, worst-fold, bootstrap CI, dan coverage.
- Pastikan setiap submission mempunyai notebook dengan seed dan output yang bersesuaian dalam toleransi aturan 0.001.

## Prinsip keputusan

Public score adalah evidence, bukan oracle. Candidate final terbaik adalah kombinasi skor, reproducibility, validation stability, dan error diversity. Dengan gap public hanya 0.00164, satu portfolio yang robust lebih rasional daripada mengejar puluhan swaps yang dipilih dari noise.
