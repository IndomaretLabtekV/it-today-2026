# Do Not Repeat

Daftar ini menghemat GPU, submission quota, dan waktu analisis.

## Eksperimen yang sudah gagal atau tidak stabil

- **Global semantic replacement/blend:** embedding yang secara intuitif lebih pintar mengubah terlalu banyak ranking dan tidak mengalahkan lexical anchor.
- **Qwen 8B frozen embedding:** biaya tinggi, tidak memberi public lift yang dibutuhkan.
- **BGE auxiliary branch:** tambahan semantic signal tidak stabil sebagai global ranker.
- **Broad QLoRA residual:** scope koreksi terlalu lebar; variance dan validation mismatch besar.
- **V23 F2LLM local corrector apa adanya:** conservative lift hanya +1.21e-6 dengan precision 0.4 dan worst fold negatif; balanced dan confirmed variants negatif.
- **LambdaRank/listwise global models:** objective tidak otomatis menyelesaikan data kecil, sparse label, dan candidate instability.
- **Borda/foldbag/repeated broad ensembles:** konsensus sering mengencerkan calibration anchor; public scores di bawah best targeted variants.
- **Routers/regime models:** routing errors lebih mahal daripada benefit lokal.
- **Exact-template lookup/family-wide template rules:** CAL dapat positif tetapi LOCK negatif; memorization tidak generalize.
- **Positive-count prediction:** target count tidak cukup untuk menentukan urutan modul.
- **Broad prerequisite rules:** raw prerequisite actions sekitar -0.01090; bahkan margin-filtered variant sekitar -0.00658.
- **Generic top-6 or #5/#6 pair correction:** boundary alone bukan evidence bahwa swap benar.

## Bug/false lead yang tidak boleh hidup lagi

**Cross-module Calibration@5 spike** sempat tampak menjanjikan, tetapi target construction salah. Untuk user dengan empat positive labels, pipeline mengisi item kelima dengan zero-label arbitrer sebagai “relevant”. Setelah target diperbaiki, fixed `C=1`, `alpha=0.04` gagal pada untouched LOCK. Implementasi itu ditolak/dihapus; jangan menghidupkan kembali angka dari versi bug.

## Pola proses yang harus dihentikan

- Menyimpulkan “private user” dari skor leaderboard yang sama.
- Memilih threshold setelah melihat LOCK berkali-kali.
- Menggabungkan banyak perubahan dalam satu submission tanpa ablation plan.
- Menganggap aggregate package lift sebagai bukti setiap action.
- Membandingkan output dari environment package berbeda tanpa exact hash/diff.
- Memakai test target/leaderboard response sebagai fitur atau label model.
- Menjalankan paper/model baru sebelum mendefinisikan failure mode yang hendak diperbaiki.
- Mengoptimalkan CV hanya sampai digit keenam lalu berharap public lift besar.

## Kapan sebuah ide lama boleh dicoba lagi

Hanya bila desain barunya mengubah penyebab kegagalan, misalnya:

- semantic encoder sebagai **selective action teacher**, bukan global replacement;
- learning-to-rank pada **delta swap/candidate slate**, bukan seluruh 17 modul tanpa uncertainty;
- prerequisite sebagai fitur lemah di model terkalibrasi, bukan hard rule;
- ensemble untuk uncertainty/abstention, bukan average semua ranking.
