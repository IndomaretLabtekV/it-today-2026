# Experiment Backlog

Backlog ini diurutkan berdasarkan expected information gain dan risiko, bukan berdasarkan kemewahan model.

## 1. Core-6 attribution via OOF bootstrap

**Pertanyaan:** tindakan core mana yang benar-benar membawa +0.00007?

**Desain:** hitung delta setiap action pada analog OOF yang benar-benar terisolasi, bootstrap di level user, ukur stabilitas fold/seed, lalu pilih subset dengan lower bound terbaik.

**Output wajib:** tabel per-action mean delta, CI, support, harm rate, module-pair family, dan exact test rank change.

**Keputusan:** subset harus mengalahkan core-6 pada LOCK atau memberikan variance jauh lebih rendah.

## 2. Counterfactual swap teacher

**Pertanyaan:** bisakah model belajar kapan `module_a > module_b` meningkatkan NDCG, bukan sekadar memprediksi relevance?

**Desain minimum:** buat contoh train dari candidate ranking OOF; label delta swap aktual; gunakan fitur anchor margin, ranks, assessment gap, lexical alignment, chat recency, prerequisite relation, dan semantic pair score. Mulai dengan logistic/LightGBM yang sudah ada. Cross-encoder hanya ditambahkan bila baseline tabular menunjukkan signal.

**Anti-leakage:** candidate generator, neighbors, thresholds, dan calibration semuanya train-fold only.

## 3. Cross-encoder near-tie reranking

**Pertanyaan:** apakah joint encoding `[user profile/chat] + [module description]` lebih diskriminatif daripada cosine embedding untuk 2–3 pasangan boundary?

**Desain:** open-source small multilingual/Indonesian-capable encoder, hard negatives dari module rank 5–8, train atau distill pada fold train, scoring hanya kandidat anchor. Batasi scope agar T4x2 realistis.

**Gate:** harus memperbaiki action precision dan LOCK; peningkatan embedding retrieval saja tidak cukup.

## 4. Conformal/selective abstention

**Pertanyaan:** bisakah coverage diturunkan sampai swap precision cukup tinggi?

**Desain:** calibration set menentukan threshold berdasar lower confidence/probability of benefit; evaluation set tidak disentuh. Ukur risk-coverage curve. Pilih threshold sebelum LOCK dibuka.

## 5. Rank uncertainty ensemble

**Pertanyaan:** apakah disagreement antar anchor variants dapat mengidentifikasi user yang aman untuk diedit?

**Desain:** gunakan model yang sudah ada—word/char TF-IDF, structured, assessment, semantic teacher—tanpa menambah family baru. Hanya action dengan pair direction agreement tinggi dan boundary uncertainty rendah yang diterapkan.

## 6. Exact module-pair specialist

**Pertanyaan:** apakah pasangan berulang seperti M002/M003 atau M012/M014 memiliki decision rule yang konsisten?

**Desain:** satu specialist per pair hanya jika support mencukupi. Features harus menjelaskan skill gap dan intent; evaluasi leave-cluster-out agar template/chat paraphrase tidak bocor.

## 7. Private-risk portfolio

**Pertanyaan:** jika public probing overfit, submission mana yang paling mungkin generalize private?

**Desain:** siapkan tiga family yang benar-benar berbeda:

- anchor public 0.65919;
- conservative OOF/LOCK champion dengan sedikit/no manual public-derived actions;
- diversified semantic-selective candidate yang lolos gate.

Portfolio ini untuk final selection, bukan tiga variasi random setiap hari.

## Eksperimen yang sengaja tidak diprioritaskan

- Mengganti anchor dengan embedding 7B/8B secara global.
- Menjalankan model learning-to-rank besar tanpa objective/action diagnostics.
- Grid search bobot blend yang luas.
- Menambah lebih banyak manual swaps dari similarity saja.
- Mencoba lagi exact-template retrieval yang tidak stabil.

Kandidat itu baru kembali ke backlog bila ada bukti baru yang menjawab penyebab kegagalan lama.
