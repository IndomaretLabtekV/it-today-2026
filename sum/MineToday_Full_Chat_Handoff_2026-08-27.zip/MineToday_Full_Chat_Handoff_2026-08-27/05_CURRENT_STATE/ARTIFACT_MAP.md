# Artifact Map

ZIP ini tidak membawa notebook, dataset, model, atau CSV hasil. Peta berikut memberi tahu chat berikutnya apa yang harus dibuka di workspace asli.

## Dataset dan aturan

| Lokasi | Isi/kegunaan |
|---|---|
| `data/chat_history.csv` | Riwayat chat per user |
| `data/modules_catalog.csv` | Katalog 17 modul |
| `data/user_assessments.csv` | Skor assessment user |
| `data/train_relevance.csv` | Target relevance train |
| `data/test.csv` | Daftar 1.000 user test |
| `data/sample_submission.csv` | Kontrak format submission |
| `docs/TM MINETODAY.pdf` | Term and mechanism kompetisi |

## Notebook

- `notebooks/v1.ipynb` sampai `notebooks/v22.ipynb`: riwayat eksperimen lama; detail ringkas ada di `02_EXPERIMENT_HISTORY/MASTER_TIMELINE_V1_V25.md` dan arsip handoff lama.
- `notebooks/v23.ipynb`: F2LLM-v2-4B frozen local-action corrector dengan fail-closed gate.
- `notebooks/v24.ipynb`: causal micro-probe dari public-best.
- `notebooks/v25.ipynb`: distilled analog actions, core-6 dan relaxed-3, plus output submission kanonis.

## Results

- `results/v23/`: audit, OOF evidence, dan submission V23; primary akhirnya mempertahankan PB karena gate gagal.
- `results/v24/`: micro-probe submissions dan diagnostic tables.
- `results/v25/`: primary core-6, lastshot aggressive-9, manifests, evidence tables, dan checksum terkait.

Nama file kanonis V25:

- `results/v25/submission_v25_primary_distilled6_pb.csv`
- `results/v25/submission_v25_lastshot_distilled9_pb.csv`

## Tests

- `tests/test_v25_notebook_contract.py`: pemeriksaan kontrak notebook V25, materialisasi submission, dan properti penting yang dibuat selama debugging reproducibility.

## Handoffs

- `sum/IT_Today_MineToday_Full_Handoff_2026-08-23.zip`
- `sum/MineToday_Full_Chat_Handoff_2026-08-24.zip`
- `sum/MineToday_Full_Chat_Handoff_2026-08-26.zip`
- Paket ini: `sum/MineToday_Full_Chat_Handoff_2026-08-27.zip`

Arsip 26 Agustus sudah membawa dokumentasi 23 dan 24 Agustus. Salinan dokumentasinya ditempatkan di `09_ARCHIVE_PRIOR_HANDOFFS/2026-08-26/` di dalam paket ini agar riwayat tetap self-contained.

## Hash artefak V25 yang tercatat

| Artefak | SHA-256 |
|---|---|
| `notebooks/v25.ipynb` | `9cfcd6ddfdcbf8adf3186981303b92a83e43290302e6754b8c8fd1f98990b968` |
| V25 primary | `2e9d9553db483d68d98a2a97cc421bc9c996a22e77be755c2b652e7d3f481d4a` |
| V25 lastshot | `db78bb7d03bf978113e1973aa48cf78414d71b608bb504324683638d69fd4fd4` |

Hash adalah snapshot yang tercatat saat V25 selesai. Hitung ulang jika file workspace berubah.
