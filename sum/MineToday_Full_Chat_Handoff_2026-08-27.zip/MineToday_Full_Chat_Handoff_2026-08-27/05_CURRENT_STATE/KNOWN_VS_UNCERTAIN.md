# Known vs Uncertain

Tujuan dokumen ini adalah mencegah chat berikutnya mengubah dugaan menjadi fakta.

## Fakta yang terverifikasi

- Kompetisi mengevaluasi top-5 per `user_id` dengan NDCG@5.
- Data yang diaudit berisi 4.000 user train, 1.000 user test, dan 17 modul.
- Chat history berisi 14.573 baris untuk 4.940 user; 117 train dan 33 test user tidak mempunyai chat.
- Assessment matrix mempunyai 251 sel invalid/missing dari 50.000 sel yang diaudit.
- Public-best pra-V25 adalah PB dua perubahan dengan skor 0.65912.
- V24 PB+U4498 juga mendapat 0.65912.
- V25 PB+core-6 mendapat 0.65919.
- V25 PB+core-6+relaxed-3 mendapat 0.65919.
- Leader terakhir yang disebut user adalah 0.66083; gap terhadap 0.65919 adalah 0.00164.
- V23 conservative gate tidak lolos: lift OOF sekitar +0.00000121, precision 0.4, 3/5 fold menang, worst fold negatif.
- V23 balanced/confirmed variants negatif.
- V24 dijalankan dengan NumPy 2.0.2, pandas 2.3.3, LightGBM 4.6.0 menurut output notebook.
- Reproduksi lokal V25 sempat memakai NumPy 2.5.2 dan pandas 3.0.5; geometri sparse/Ridge berubah dan hanya 4/6 tindakan core terpicu sebelum proses dibuat deterministik.
- Notebook V25 kemudian dibuat idempotent, margin pilihan dibekukan, dan submission kanonis dimaterialisasi dari referensi V24 yang tepat.
- Test kontrak V25 lulus pada pemeriksaan terakhir sebelum pembuatan handoff ini.
- Tiga submission yang dibahas sebagai submission hari itu adalah V24, V25 primary, dan V25 lastshot; jika semuanya memang diajukan pada tanggal leaderboard yang sama, kuota 3/3 telah terpakai.

## Inferensi kuat, tetapi bukan fakta kausal

- Dua tindakan PB kemungkinan mengandung signal public yang nyata karena paketnya menaikkan skor +0.00034.
- Sebagian core-6 kemungkinan positif karena paketnya menambah +0.00007, tetapi pembulatan dan interaksi ranking membuat attribution tidak pasti.
- Kinerja sudah masuk rezim local ranking correction: model global baru lebih sering mengubah terlalu banyak user daripada memperbaiki sedikit kasus sulit.
- Validation-to-public mismatch terutama dipicu distribusi split, target sangat sparse, ketidakstabilan top-5, dan selection bias setelah banyak eksperimen.
- Lexical/structured model lebih cocok sebagai anchor daripada embedding besar, karena data kecil dan module universe hanya 17.
- Model semantik masih bisa berguna sebagai teacher/evidence generator atau tie-breaker yang sangat selektif, bukan pengganti ranking global.

## Hal yang belum diketahui

- User mana yang berada di public atau private test split.
- Kontribusi individual U4047 dan U4953.
- Kontribusi individual keenam core action.
- Apakah relaxed-3 semuanya private, semuanya nol, atau efek positif-negatifnya saling hapus.
- Presisi sebenarnya dari nearest-neighbor analog evidence pada test distribution.
- Apakah public leaderboard memakai label graded atau bentuk relevance lain di balik target train yang tersedia.
- Berapa banyak perubahan user yang diperlukan untuk menutup gap 0.00164; ini bergantung split dan besar perubahan DCG setiap user.
- Correlation antara public dan private leaderboard.
- Apakah top-1 public juga overfit terhadap probing.

## Pernyataan yang dilarang tanpa bukti baru

- “Skor sama berarti user ada di private.”
- “Semua core-6 benar karena paketnya naik.”
- “Embedding lebih besar pasti lebih baik.”
- “CV lebih tinggi berarti public pasti naik.”
- “Satu paper state-of-the-art akan memberi lompatan besar pada dataset ini.”
- “Tidak ada lagi ruang perbaikan.”

Gunakan bahasa probabilistik untuk semua hipotesis tersebut dan rancang eksperimen yang bisa memisahkan alternatif penyebabnya.
