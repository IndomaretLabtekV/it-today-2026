# Exact Action Ledger

Dokumen ini adalah sumber utama untuk perubahan ranking yang sudah dibawa ke public leaderboard. Semua notasi `A > B` berarti modul A dipromosikan di atas modul B pada ranking user tersebut. Itu bukan klaim bahwa A pasti label relevan dan B pasti tidak; itu adalah tindakan ranking yang diuji.

## Baseline publik yang dipertahankan

Baseline terbaik sebelum eksperimen V25 adalah `submission_v22_3_LASTSHOT_2CHANGE_U4047_U4953.csv`, public NDCG@5 **0.65912**. Baseline ini disebut **PB** atau **public-best** di seluruh handoff.

PB berbeda dari Consensus3 pada dua user:

| User | Aksi | Status bukti |
|---|---|---|
| U4047 | M007 dipromosikan di atas M009 | Bagian dari paket dua perubahan yang menaikkan skor V22.2 0.65878 menjadi V22.3 0.65912 |
| U4953 | M005 dipromosikan di atas M016 | Bagian dari paket dua perubahan yang menaikkan skor V22.2 0.65878 menjadi V22.3 0.65912 |

Kenaikan **+0.00034** hanya mengidentifikasi manfaat paket U4047+U4953. Kontribusi masing-masing tindakan tidak diisolasi di public leaderboard.

## V24: micro-probe yang diajukan

V24 membangun kandidat berikut dari PB:

| Kandidat | Tambahan terhadap PB | Public score | Interpretasi aman |
|---|---|---:|---|
| PB + U4498 | Satu perubahan untuk U4498 | 0.65912 | Tidak ada perubahan pada skor lima desimal |

Kandidat U4047-only, U4953-only, dan PB+U4876 juga dimaterialisasi/ditelaah dalam alur V24, tetapi hasil public yang tercatat pada chat ini hanya PB+U4498. Skor sama tidak membuktikan U4498 berada di private split; perubahan dapat bernilai nol, saling ekuivalen terhadap label, atau lebih kecil dari resolusi tampilan.

## V25 primary: PB + core-6

Primary V25 menambahkan enam tindakan di bawah ini ke PB. Kolom support/positive/harm berasal dari audit analog OOF V25; margin adalah margin beku dari environment referensi saat tindakan dipilih.

| User | Aksi | Support | Positive | Harm | Frozen margin | Status public |
|---|---|---:|---:|---:|---:|---|
| U4074 | M003 > M014 | 81 | 29 | 20 | 0.000682443 | Diuji hanya sebagai bagian core-6 |
| U4176 | M017 > M003 | 10 | 9 | 1 | 0.000203669 | Diuji hanya sebagai bagian core-6 |
| U4491 | M002 > M003 | 61 | 25 | 20 | 0.001700282 | Diuji hanya sebagai bagian core-6 |
| U4567 | M012 > M014 | 56 | 24 | 14 | 0.000054896 | Diuji hanya sebagai bagian core-6 |
| U4836 | M002 > M003 | 12 | 7 | 3 | 0.000934988 | Diuji hanya sebagai bagian core-6 |
| U4929 | M002 > M003 | 61 | 25 | 20 | 0.000661612 | Diuji hanya sebagai bagian core-6 |

Hasil paket: **0.65919**, atau **+0.00007** terhadap PB pada skor yang ditampilkan. Ini membuktikan paket core-6 tidak lebih buruk pada resolusi leaderboard dan kemungkinan memberi sedikit manfaat. Ini **tidak** membuktikan keenam aksi semuanya benar. Satu atau beberapa aksi dapat positif dan yang lain negatif/nol.

Primary berbeda dari Consensus3 pada total delapan user: dua user PB dan enam user core-6, yaitu 16 sel CSV.

## V25 lastshot: PB + core-6 + relaxed-3

Lastshot menambahkan tiga tindakan:

| User | Aksi | Support | Positive | Harm | Frozen margin | Status public |
|---|---|---:|---:|---:|---:|---|
| U4030 | M003 > M007 | 11 | 6 | 2 | 0.002789915 | Diuji hanya sebagai paket relaxed-3 di atas primary |
| U4650 | M012 > M003 | 9 | 5 | 1 | 0.002036035 | Diuji hanya sebagai paket relaxed-3 di atas primary |
| U4731 | M006 > M014 | 43 | 11 | 6 | 0.001383066 | Diuji hanya sebagai paket relaxed-3 di atas primary |

Hasil paket agresif: **0.65919**, sama dengan primary pada lima desimal. Kesimpulan yang sah hanya bahwa efek bersih ketiga aksi tidak terlihat pada resolusi skor publik. Jangan menulis ketiganya sebagai “pasti private”.

Lastshot berbeda dari Consensus3 pada sebelas user: dua PB, enam core, tiga relaxed, yaitu 22 sel CSV.

## Status yang harus dibawa ke eksperimen berikutnya

- **Anchor terkuat:** PB U4047+U4953; ini adalah paket yang sudah menghasilkan lift nyata.
- **Paket positif kecil:** core-6; aggregate public lift +0.00007.
- **Paket tidak teridentifikasi:** relaxed-3; aggregate displayed delta 0.00000.
- **Belum ada attribution per action:** jangan menganggap tabel support sebagai causal truth.
- **Jangan mengedit urutan lain tanpa ledger:** setiap perubahan baru harus mencatat baseline, user, pasangan modul, posisi sebelum/sesudah, alasan, OOF evidence, dan hasil public bila disubmit.

## Artefak kanonis yang dirujuk

- Notebook: `notebooks/v25.ipynb`
- Primary: `results/v25/submission_v25_primary_distilled6_pb.csv`
- Lastshot: `results/v25/submission_v25_lastshot_distilled9_pb.csv`
- Contract: `tests/test_v25_notebook_contract.py`

File-file itu tidak disertakan dalam ZIP ini; hanya lokasi dan temuan yang didokumentasikan.
