# Score Algebra

## NDCG@5

Untuk ranking lima modul, discounted cumulative gain adalah:

\[
DCG@5 = \sum_{i=1}^{5}\frac{2^{rel_i}-1}{\log_2(i+1)}
\]

dan:

\[
NDCG@5 = \frac{DCG@5}{IDCG@5}
\]

Score kompetisi adalah agregasi user-level NDCG@5. Dengan binary relevance, gain relevan adalah 1; dengan graded relevance, gain mengikuti `2^rel-1`. Notebook/evaluator lokal harus mengikuti bentuk target kompetisi yang sebenarnya.

## Bobot posisi binary relevance

| Rank | Discount `1/log2(rank+1)` |
|---:|---:|
| 1 | 1.000000 |
| 2 | 0.630930 |
| 3 | 0.500000 |
| 4 | 0.430677 |
| 5 | 0.386853 |

Akibatnya, pertukaran relevan/non-relevan rank 1 dan 2 berdampak lebih besar daripada pertukaran rank 4 dan 5. Swap dua modul yang sama-sama relevan atau sama-sama tidak relevan memberi delta nol untuk binary relevance.

## Mengapa few-user change sulit dibaca

Misalkan public split mempunyai `N` user. Satu perubahan user memberi aggregate:

\[
\Delta score = \frac{\Delta NDCG_u}{N}
\]

Tetapi `N`, relevance pattern, dan presisi skor internal tidak diketahui. Score yang ditampilkan lima desimal adalah pembulatan. Karena itu:

- satu action positif kecil dapat tidak mengubah display;
- beberapa action positif dan negatif dapat saling hapus;
- action pada private user tidak memengaruhi public score;
- action yang menukar label setara memberi delta nol.

## Score decomposition yang diketahui

| Transisi | Displayed delta |
|---|---:|
| V22.2 four-change 0.65878 → V22.3 PB 0.65912 | +0.00034 |
| PB 0.65912 → V24 PB+U4498 0.65912 | +0.00000 |
| PB 0.65912 → V25 core-6 0.65919 | +0.00007 |
| V25 core-6 0.65919 → core-6+relaxed-3 0.65919 | +0.00000 |
| V25 best 0.65919 → leader 0.66083 | +0.00164 gap |

Displayed deltas bukan additive causal contributions per user. Hanya paket perubahan yang dibandingkan yang teridentifikasi.

## Aturan attribution

Untuk menyebut action `a` mempunyai causal public delta, dua submissions harus identik kecuali action `a`. Bahkan kemudian, displayed delta dapat tersensor pembulatan. Bila submissions berbeda lebih dari satu action, yang dapat dinilai hanya joint package effect.

## Exact diff contract

Setiap kandidat baru perlu menyimpan:

- reference submission hash;
- daftar user yang berubah;
- ranking before/after;
- pasangan/posisi yang berubah;
- jumlah cell CSV berbeda;
- expected metric direction dan evidence;
- hasil public dengan digit yang tersedia.

Tanpa ini, leaderboard result tidak dapat digunakan sebagai eksperimen yang informatif.
