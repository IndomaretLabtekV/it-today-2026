# V25 Evidence Table

## Anchor actions

| Tier | User | Preferred | Demoted | Public evidence |
|---|---|---|---|---|
| PB | U4047 | M007 | M009 | Bagian paket PB yang memberi +0.00034 vs V22.2 |
| PB | U4953 | M005 | M016 | Bagian paket PB yang memberi +0.00034 vs V22.2 |

## Core-6

| User | Preferred | Demoted | Support | Positive | Harm | Neutral | Positive rate | Harm rate | Frozen margin |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| U4074 | M003 | M014 | 81 | 29 | 20 | 32 | 35.80% | 24.69% | 0.000682443 |
| U4176 | M017 | M003 | 10 | 9 | 1 | 0 | 90.00% | 10.00% | 0.000203669 |
| U4491 | M002 | M003 | 61 | 25 | 20 | 16 | 40.98% | 32.79% | 0.001700282 |
| U4567 | M012 | M014 | 56 | 24 | 14 | 18 | 42.86% | 25.00% | 0.000054896 |
| U4836 | M002 | M003 | 12 | 7 | 3 | 2 | 58.33% | 25.00% | 0.000934988 |
| U4929 | M002 | M003 | 61 | 25 | 20 | 16 | 40.98% | 32.79% | 0.000661612 |

Package public result: PB 0.65912 → core-6 0.65919, displayed **+0.00007**.

## Relaxed-3

| User | Preferred | Demoted | Support | Positive | Harm | Neutral | Positive rate | Harm rate | Frozen margin |
|---|---|---|---:|---:|---:|---:|---:|---:|---:|
| U4030 | M003 | M007 | 11 | 6 | 2 | 3 | 54.55% | 18.18% | 0.002789915 |
| U4650 | M012 | M003 | 9 | 5 | 1 | 3 | 55.56% | 11.11% | 0.002036035 |
| U4731 | M006 | M014 | 43 | 11 | 6 | 26 | 25.58% | 13.95% | 0.001383066 |

Package public result: core-6 0.65919 → core-6+relaxed-3 0.65919, displayed **+0.00000**.

## Cara membaca tabel

- `positive rate` memakai semua support sebagai denominator; neutral tetap dihitung.
- Support besar tidak menjamin transfer ke test user.
- U4176 terlihat paling presisi tetapi support hanya 10.
- M002>M003 muncul untuk dua test user dengan evidence counts identik, sehingga independence/template clustering perlu diperiksa.
- Margin adalah model geometry signal, bukan expected NDCG delta.
- Public evidence hanya tersedia di level package; tabel ini untuk prior, bukan attribution final.

## Audit file-level V25

- Notebook: 19 cells.
- Primary vs Consensus3: 8 user / 16 cell differences.
- Lastshot vs Consensus3: 11 user / 22 cell differences.
- Notebook SHA-256: `9cfcd6ddfdcbf8adf3186981303b92a83e43290302e6754b8c8fd1f98990b968`.
- Primary SHA-256: `2e9d9553db483d68d98a2a97cc421bc9c996a22e77be755c2b652e7d3f481d4a`.
- Lastshot SHA-256: `db78bb7d03bf978113e1973aa48cf78414d71b608bb504324683638d69fd4fd4`.

Hitung ulang angka file-level bila artefak workspace diedit setelah handoff.
