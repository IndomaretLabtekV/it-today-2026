# Archive Content Policy

## Yang disertakan

- Ringkasan kompetisi, data, metric, dan aturan.
- Timeline dan public scores V1–V25 yang pernah tercatat.
- Postmortem V23, V24, dan V25.
- Riset paper/metode/embedding dan keputusan yang diambil darinya.
- Root-cause diagnosis, failure catalog, dan reproducibility incident.
- Exact action ledger, hashes yang tercatat, artifact map, serta next-step plan.
- Narasi chat, decision log, open questions, dan prompt bootstrap.
- Salinan dokumentasi handoff 26 Agustus, yang sudah mengarsipkan dokumentasi 23/24 Agustus.

## Yang sengaja tidak disertakan

- File notebook `.ipynb`.
- CSV submission dan diagnostic results mentah.
- Dataset kompetisi.
- Model weights, embedding arrays, caches, logs besar, atau environment binaries.
- PDF peraturan asli.

Alasannya sesuai permintaan user: ZIP adalah paket konteks/chat handoff, bukan duplikasi workspace. `ARTIFACT_MAP.md` menunjukkan lokasi semua artefak asli.

## Batas epistemik

Paket ini membedakan fakta, hasil terukur, inferensi, dan pertanyaan terbuka. Informasi public leaderboard berasal dari angka yang user laporkan dalam chat. Tidak ada klaim bahwa public score menjamin private score.

## Kebijakan arsip lama

Dokumentasi 26 Agustus dimasukkan sebagai tree, bukan nested ZIP, agar bisa dibaca langsung. Tree itu mencakup dokumentasi/manifest historis; ia tidak dimaksudkan membawa notebook/results mentah. Beberapa file referensi berformat CSV/JSON dapat ada sebagai ledger teks terstruktur, tetapi bukan submission atau dataset kompetisi.
