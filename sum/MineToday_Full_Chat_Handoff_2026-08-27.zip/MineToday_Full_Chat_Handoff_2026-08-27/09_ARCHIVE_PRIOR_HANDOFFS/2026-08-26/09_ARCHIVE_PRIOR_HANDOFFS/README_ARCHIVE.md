# Prior Handoff Archive

Folder ini menyimpan **dokumen teks/Markdown** dari handoff 23 dan 24 Agustus agar detail early-stage tidak hilang.

Important:

- snapshot ini historis dan beberapa “current best/current plan” di dalamnya sudah outdated;
- jika angka/decision bertentangan dengan folder `00`–`08` tanggal 26 Agustus, gunakan **dokumen current 26 Agustus**;
- notebook/results/raw CSV sengaja tidak ikut disalin.
