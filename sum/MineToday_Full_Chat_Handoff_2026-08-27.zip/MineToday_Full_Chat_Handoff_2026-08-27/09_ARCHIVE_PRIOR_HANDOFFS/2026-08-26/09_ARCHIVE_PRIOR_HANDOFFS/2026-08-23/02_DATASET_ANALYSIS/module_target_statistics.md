# Module Target Statistics

## Top-1 frequency in train

| Module | Top-1 count |
|---|---:|
| M003 SQL | 495 |
| M002 Python | 419 |
| M006 Statistics | 401 |
| M012 GenAI | 376 |
| M009 ML | 354 |
| M017 Career | 285 |
| M015 No-Code AI | 255 |
| M016 MLOps | 252 |
| M007 EDA | 224 |
| M014 Automation | 222 |
| M001 Excel | 192 |
| M010 CV | 156 |
| M008 Dashboard | 137 |
| M005 Version Control | 95 |
| M013 Prompt Engineering | 69 |
| M011 NLP | 40 |
| M004 Web Scraping | 28 |

## Full rank-count patterns remembered from analysis
Ranks 1..6:
- M001: 192,269,290,310,167,89
- M002: 419,370,308,328,189,87
- M003: 495,383,382,329,223,103
- M004: 28,64,116,128,112,46
- M005: 95,126,161,181,137,68
- M006: 401,369,325,296,151,79
- M007: 224,207,197,201,138,67
- M008: 137,198,210,269,171,76
- M009: 354,282,214,203,135,79
- M010: 156,171,173,194,126,86
- M011: 40,97,132,166,135,69
- M012: 376,273,251,228,132,71
- M013: 69,180,219,222,150,105
- M014: 222,274,278,263,208,108
- M015: 255,255,264,242,161,67
- M016: 252,210,202,176,134,63
- M017: 285,272,278,264,169,90

## Implication
Rare modules such as M004/M011/M013 are mostly secondary, not top-1. Global rare-module boosting is therefore dangerous for NDCG@5. Recovery should be conditional on strong evidence.
