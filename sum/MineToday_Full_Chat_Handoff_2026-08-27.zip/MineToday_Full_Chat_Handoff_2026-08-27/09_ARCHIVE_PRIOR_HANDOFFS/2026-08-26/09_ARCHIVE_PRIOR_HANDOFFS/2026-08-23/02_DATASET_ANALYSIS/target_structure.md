# Target Structure

## Number of relevant modules per user
Exactly **4, 5, or 6** relevant modules.

Train counts:
- K=4: **1,362 users**
- K=5: **1,285 users**
- K=6: **1,353 users**

## Rank/relevance bands
The target is highly structured and ordinal:
- rank 1: exactly **1.0**
- rank 2: roughly **0.80–0.90**
- rank 3: roughly **0.65–0.75**
- rank 4: roughly **0.50–0.60**
- rank 5: roughly **0.35–0.45**
- rank 6: roughly **0.20–0.30**

Each non-top band has small jitter values rather than arbitrary continuous relevance.

Approximate rank means used later:
- rank1 ≈ 1.000
- rank2 ≈ 0.849
- rank3 ≈ 0.700
- rank4 ≈ 0.549
- rank5 ≈ 0.400
- rank6 ≈ 0.250

## Evidence of stochastic / latent target generation
The visible inputs do not deterministically define the final ordered sequence:
- roughly **3,960 unique ordered positive-module sequences among 4,000 train users**.
- predicting K (4/5/6) from visible structured features gave only ~**34.35% accuracy**, vs ~**34.05% majority baseline**.
- exact/similar visible chat profiles can still have different top modules.

Interpretation: there is likely substantial stochasticity, hidden latent variables, or random sampling/jitter in the target generator. Therefore memorizing exact target realizations is dangerous; estimating expected utility/relevance is more appropriate.
