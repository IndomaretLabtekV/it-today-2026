# Intent, Assessment, Prerequisite, and Time Findings

## Assessment acts like a readiness/gap gate
Examples discovered:

### Python score vs M002 relevant
- score0: ~52.1%
- score1: ~49.1%
- score2: ~38.0%
- score3: ~30.6%
- score4: ~19.6%
- score5: ~19.6%

### SQL score vs M003 relevant
- score0: ~54.0%
- score1: ~54.0%
- score2: ~46.2%
- score3: ~33.9%
- score4: ~23.2%
- score5: ~27.0%

### MLOps M016 vs ML score
- ML0/1/2: P(relevant) ~16–18%
- ML3: ~50.9%
- ML4: ~65.3%
- ML5: ~67.3%
- P(top1) around 25% for ML4/5

Interpretation: assessments are not side metadata; they gate whether the next recommended module should fill a gap, move forward in prerequisites, or go advanced.

## Explicit topic parser coverage in V3.1-style analysis
Counts of direct mentions:
- excel 129
- python 1283
- sql 1507
- statistics 1322
- eda 1310
- ml_eval 1320
- mlops 1230
- cv 1482
- nlp 0
- genai 1519
- ml 1369
- business 746
- dashboard 803
- webscrape 0
- git 0
- prompt 0
- automation 980
- nocode 607
- career 1243

Important: M004 Web Scraping, M005 Version Control, M011 NLP, and M013 Prompt Engineering have little/no direct lexical topic mention, so pure semantic/topic matching cannot solve them reliably.

## True calendar-time recency was strongly predictive
Examples from later analysis:

### Python mention age -> M002
- current day: relevant ~89.4%, top1 ~50.6%
- 0–3 days: 83.3%, 32.5%
- 3–14 days: 67.3%, 29.2%
- 14–60 days: 56.0%, 14.2%
- >60 days: 47.6%, 9.5%

### SQL mention age -> M003
- current: relevant ~90.5%, top1 ~53.9%
- 0–3 days: 85.7%, 40.2%
- 3–14 days: 83.7%, 31.2%
- 14–60 days: 73.3%, 23.7%
- >60 days: 65.7%, 14.1%

EDA and GenAI/MLOps showed similar decay patterns.

Train/test time distributions were very similar, e.g. mean history span about 17.9 vs 18.3 days and mean latest gap around 4.7 vs 4.6 days.
