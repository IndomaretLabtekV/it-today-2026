# Dataset Schema and Counts

Organizer data used in the conversation:

1. `chat_history.csv`
2. `modules_catalog.csv`
3. `user_assessments.csv`
4. `train_relevance.csv`
5. `sample_submission.csv`
6. `test.csv`

## Shapes / user counts
- Train labels: **4,000 users** × 17 module targets + `user_id`.
- Test: **1,000 users**.
- Fixed candidate set: **17 modules**.
- Assessments: **5,000 users**.
- Chat: **14,573 rows**, 4 columns.
- Train users with no chat: **117**.
- Test users with no chat: **33**.

## Extra organizer-supplied unlabeled chat users
`chat_history.csv` also contains **90 extra users, U_5001–U_5090**, with **189 chat rows**, outside the 4,000 train + 1,000 test IDs.

They can only be used safely for unsupervised vocabulary/template discovery, not supervised targets.

## Assessment data quality
About **251 invalid/outlier/non-numeric cells** across ~50,000 assessment cells. Examples seen:
- `Nol`
- `Dua`
- `99`
- `12`
- `-1`
- `-3`

The strong V3.1 cleaning strategy:
- normalize number words,
- mark invalid cells,
- impute invalid score with row median,
- preserve invalid flags as features.

## Chat repetition
- Approximately **51% exact duplicate chat messages**.
- Normalized test-message exact/near overlap with train was around **69.9%**.
- Roughly **95.8% of test users with chat** had at least one message/template already represented in train.

This was one of the strongest signals that the dataset is highly synthetic/repetitive and that lexical/template features are valuable.
