# Train/Test Shift Audit

A major concern was whether user IDs/tail blocks implied a different hidden test regime.

## Domain classifier evidence
Using visible structured features to classify train vs test:
- CatBoost/domain CV AUC around **0.504**.

Using word/char TF-IDF textual representation:
- domain AUC around **0.508**.

Earlier ExtraTrees adversarial validation on V3.1 structured features was around **0.494**.

All are essentially random.

## Interpretation
There is **no strong detectable train/test feature-distribution shift**. Sequential/block splits remain useful as stress tests but should not replace repeated random/nested validation as the primary model-selection criterion.

## Important caveat
Small block-to-block differences still exist because this is a small/noisy ranking dataset. Apparent trends across user-ID blocks can arise from sampling variance rather than true regime drift.
