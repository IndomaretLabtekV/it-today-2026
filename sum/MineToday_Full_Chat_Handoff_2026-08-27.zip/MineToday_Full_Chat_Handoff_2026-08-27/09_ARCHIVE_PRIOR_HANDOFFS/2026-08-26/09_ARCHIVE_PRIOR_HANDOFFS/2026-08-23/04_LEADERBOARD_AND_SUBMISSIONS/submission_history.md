# Public Submission History

Current leaderboard top mentioned in chat: **0.65805**.

Our best: **0.65639**.

Gap: **0.00166**.

| Submission / Family | Public LB | Notes |
|---|---:|---|
| V1 ultimate baseline | 0.63629 | semantic/transformer-heavy baseline |
| V2 supervised stack | 0.64413 | stronger sparse + stacking |
| V3.1 sparse-safe | 0.65036 | lexical/structured sparse only |
| V3.1 conservative w=.35 | 0.65540 | first major public breakthrough |
| V3.1/V4/V6 Borda ensemble | 0.65489 | OOF looked ~0.6676; public fell |
| **V7/V3.1 cal045 probe** | **0.65639** | **current public champion** |
| V8 repeated-CV full-fit w=.60 | 0.65577 | OOF looked higher; public lower |
| V8 repeated-CV foldbag w=.60 | 0.65140 | clear failure; undertrained/mismatched calibration |

## Important non-submitted candidates
- V4 LambdaRank 0.664117 OOF — not used as standalone public submission in the current record.
- V5 YetiRank 0.664240 OOF — not submitted.
- V6 nested ranker ~0.664486 OOF — not submitted standalone.
- V7 pairwise — rejected by strict nested validation.
- V9 — rejected for submission because nested gain +0.000854 was below +0.0010 promotion gate.

## Submission process lesson
Do not spend all three daily slots early. Use leaderboard submissions as scarce external experiments, one hypothesis at a time, only after offline paired/nested evidence is strong.
