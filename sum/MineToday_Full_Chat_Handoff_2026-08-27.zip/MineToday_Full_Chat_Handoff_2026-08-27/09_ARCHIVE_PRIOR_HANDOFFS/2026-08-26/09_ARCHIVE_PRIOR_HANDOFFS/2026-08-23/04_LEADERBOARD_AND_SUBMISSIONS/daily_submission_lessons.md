# Daily Submission Lessons

## Day where final ensemble was used
A V3.1/V4/V6 rank/Borda ensemble was selected after attractive OOF analysis. It scored **0.65489**, below the 0.65540 champion.

Lesson: ensemble weight selection had effectively overfit repeatedly inspected OOF predictions.

## Next day: three submissions used too quickly
1. cal045 probe -> **0.65639** (good; clean hypothesis confirmed)
2. V8 repeated full-fit w=.60 -> **0.65577** (down)
3. V8 repeated foldbag w=.60 -> **0.65140** (large drop)

This was explicitly recognized as too aggressive/too fast. The correct process from then on became: do not submit until the offline experiment clears a strict paired nested gate.

## Current day
A new day started before V9. V9 was run but **not submitted** because its strict nested gain was only +0.000854, below the predeclared +0.0010 gate. At the moment of this handoff, no current-day submission has been consumed in the current conversation after the reset.
