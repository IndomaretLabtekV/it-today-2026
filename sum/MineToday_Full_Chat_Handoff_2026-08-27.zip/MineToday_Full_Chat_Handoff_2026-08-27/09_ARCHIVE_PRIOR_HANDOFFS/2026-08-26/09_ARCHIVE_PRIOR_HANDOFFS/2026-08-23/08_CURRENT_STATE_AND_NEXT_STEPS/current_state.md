# Current State

## Leaderboard
- Current top mentioned: **0.65805**
- Our best: **0.65639**
- Gap: **0.00166**

## Current public champion
V3.1 / V7 `cal045` family: seed42-style, full-data per-module relevance calibration, 0.45 calibration weight.

## Current research champion
V9 strict nested residual model:
- nested anchor 0.663316
- nested V9 0.664170
- +0.000854
- 5/5 positive
- CI barely >0
- not enough to submit

## Current day submission status
A new day had started before V9. In the current conversation, no public submission was made after that reset. Treat current-day submission slots as unspent unless the next chat has new information.

## Current unfinished item
The user asked for **V9.1** after V9 analysis, but the handoff/archive request interrupted that work before a V9.1 notebook/result was delivered.

Therefore the exact next technical task is to build and evaluate V9.1, not to submit V9.
