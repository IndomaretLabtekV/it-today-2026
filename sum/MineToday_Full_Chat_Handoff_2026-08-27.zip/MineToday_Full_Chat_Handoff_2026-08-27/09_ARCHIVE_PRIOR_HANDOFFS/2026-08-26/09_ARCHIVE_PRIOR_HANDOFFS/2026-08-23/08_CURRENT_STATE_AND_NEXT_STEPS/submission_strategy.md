# Submission Strategy Going Forward

## Principle
There is no reason to use a slot just because a notebook produced a CSV.

## First submission of a day
Only after an offline candidate clears the paired nested gate against cal045.

## After a public result
Use it as one external hypothesis test, not a gradient signal for immediate weight sweeping.

Good example:
- cal035 -> cal045 was a clean single-mechanism probe and improved public from 0.65540 to 0.65639.

Bad examples:
- OOF-selected Borda ensemble submitted without sufficiently independent evidence.
- repeated-CV .60 followed immediately by foldbag .60 after the first failed, consuming slots too quickly.

## Current recommended action
Do **not** submit V9 as-is. Build V9.1, validate it strictly, and only submit if the improvement is large and stable enough.
