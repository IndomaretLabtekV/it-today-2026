# V9.1 Plan — Adaptive/Shrunk Distribution-Preserving Ordinal Calibration

## Motivation
V9's correction is positive in all 5 nested folds but too small (+0.000854). Module decomposition shows some residuals are consistently useful while others hurt. Hard-coded module rules would overfit.

## Core idea
Keep **cal045 immutable** and keep the V9 distribution-preserving/ordinal residual machinery, but learn **fold-safe shrinkage of residual strength toward zero**.

For each outer fold:
1. Generate cal045-equivalent anchor and V9 residual features without using outer validation labels.
2. Using only the OTHER training folds, estimate how reliable the residual is for each module or low-dimensional module group.
3. Convert reliability into a shrinkage coefficient between 0 and 1.
4. Apply that coefficient to the outer validation residual.
5. Never use outer validation labels to choose that fold's module residual weight.

This is empirical-Bayes/James–Stein style shrinkage: noisy module corrections collapse back to champion; stable corrections survive.

## Do NOT hard-code
Do not write rules such as “turn off M012” or “boost M002”. V9's observed module signs are hypotheses, not final rules.

## Low-capacity variants worth testing
A. Global shrinkage only.
B. Per-module shrinkage with strong regularization toward the global coefficient.
C. Small grouped shrinkage, e.g. beginner/foundation, data/analytics, advanced AI, career/tooling — only if grouping is predefined and not OOF-tuned.

Prefer A/B before C.

## Validation target
Promotion target:
- delta vs exact nested cal045 >= **+0.0015**, ideally +0.0020
- >=4/5, ideally 5/5 positive folds
- bootstrap lower bound >0
- test Top5 change <=8%
- top1 change <=1–1.5%

If V9.1 only reaches +0.0010 or less, keep researching; do not burn a slot.

## If V9.1 fails
Next branch should be generator/expected-utility reconstruction rather than returning to global rankers:
- low-capacity ordinal expected-relevance model,
- champion-preserving residual only,
- strict nested evaluation,
- possibly inspect latent randomness/duplicate-profile target variance more deeply.
