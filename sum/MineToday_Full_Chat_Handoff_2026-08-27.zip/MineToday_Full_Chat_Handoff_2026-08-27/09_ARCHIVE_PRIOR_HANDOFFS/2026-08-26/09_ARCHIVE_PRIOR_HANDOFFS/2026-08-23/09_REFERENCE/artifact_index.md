# Artifact / Notebook Index (Names Only — Files Not Included)

The handoff ZIP intentionally excludes these artifacts, but these names were used in the conversation:

## Competition data
- `mine-today-data-mining-competition-it-today-2026.zip`
- `chat_history.csv`
- `modules_catalog.csv`
- `user_assessments.csv`
- `train_relevance.csv`
- `test.csv`
- `sample_submission.csv`

## Notebooks
- `MineToday_Ultimate_Baseline_ITToday2026.ipynb` — V1
- `MineToday_V2_Supervised_Stack_ITToday2026_FIXED.ipynb` — V2
- `MineToday_V3_Listwise_CrossEncoder_ITToday2026_FIXED_R2.ipynb` — V3
- `MineToday_V3_1_Structured_Sparse_ITToday2026.ipynb` — V3.1
- `MineToday_V4_MultiExpert_LambdaRank_ITToday2026.ipynb` — V4
- `MineToday_V5_GeneratorAware_YetiRank_ITToday2026.ipynb` — V5
- `MineToday_V6_Nested_Ordinal_NDCG_ITToday2026.ipynb` — V6
- `MineToday_V7_ChampionConstrained_Pairwise_ITToday2026.ipynb` — V7
- `MineToday_V8_RepeatedCV_RelevanceCalibration_ITToday2026.ipynb` — V8
- `MineToday_V9_Nested_DistributionPreserving_OrdinalCalibration_ITToday2026.ipynb` — V9

## Important OOF / result artifacts mentioned
- `v31_oof_artifacts.npz`
- V1/V2/V3.1/V4/V5/V6/V7/V8/V9 result ZIPs

## Important submission names mentioned
- `submission_v31_sparse_safe.csv`
- `submission_v31_conservative.csv`
- `submission_v31_primary.csv`
- `submission_v31_cal045.csv`
- `submission_v4_primary.csv`
- `submission_v4_ranker.csv`
- `submission_v5_primary.csv`
- `submission_v5_yetirank.csv`
- `submission_v6_primary.csv`
- `submission_v7_cal045_probe.csv`
- `submission_v7_pairwise.csv`
- `submission_v8_repcal_w0p6.csv`
- `submission_v8_repcal_foldbag_w0p6.csv`
- `submission_v9_distribution_preserving.csv`
- `submission_v9_dist_ordinal.csv`
- `submission_v9_primary.csv`

No notebook/result/submission file is included in this handoff package.
