# Key Numbers Cheat Sheet

## Public leaderboard
- leader: **0.65805**
- our best: **0.65639**
- gap: **0.00166**

## Dataset
- train 4,000
- test 1,000
- modules 17
- relevant modules/user 4–6
- chat rows 14,573
- extra unlabeled chat users 90
- invalid assessment cells ~251
- train no-chat 117
- test no-chat 33
- exact duplicate chat messages ~51%

## Best public sequence
- V1 0.63629
- V2 0.64413
- V3.1 sparse 0.65036
- V3.1 cal035 0.65540
- cross-version ensemble 0.65489
- V3.1 cal045 0.65639
- V8 repeated .60 0.65577
- V8 foldbag .60 0.65140

## V9 strict nested
- anchor 0.663316
- V9 0.664170
- delta +0.000854
- 5/5 positive
- bootstrap CI [+0.000014, +0.001710]
- Top5 change 6.9%
- top1 change 0.8%

## V9.1 desired gate
- delta >= +0.0015, ideally +0.002
- >=4/5 positive
- CI lower >0
- Top5 change <=8%
- top1 change <=1–1.5%
