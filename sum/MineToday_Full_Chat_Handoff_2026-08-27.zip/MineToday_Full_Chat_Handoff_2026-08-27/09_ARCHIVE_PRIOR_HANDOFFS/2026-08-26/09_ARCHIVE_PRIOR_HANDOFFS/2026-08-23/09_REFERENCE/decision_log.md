# Major Decision Log

1. **Abandon semantic-first modeling** after V1/V3 evidence; sparse lexical generator-aware modeling is stronger.
2. **Adopt V3.1 structured sparse + per-module relevance calibration** as the core model after the public jump.
3. **Do not globally boost rare modules**; rare modules are mostly secondary.
4. **Do not trust top1-only optimization**; public gains came from Top5 membership/ranks 2–5.
5. **Deprioritize global rankers** after V4–V6 gains remained small/uncertain.
6. **Reject OOF-selected cross-version ensemble** after 0.65489 public.
7. **Promote cal045** after clean probe scored 0.65639 and became champion.
8. **Reject pairwise surgical V7** due negative nested delta.
9. **Reject repeated seed averaging/foldbagging** after 0.65577 / 0.65140 public and cross-fold-dependency diagnosis.
10. **Move to distribution-preserving ordinal residuals (V9)** with strict nesting.
11. **Do not submit V9** because +0.000854 nested gain is too small.
12. **Next: V9.1 adaptive shrinkage** of V9 residuals toward cal045.
