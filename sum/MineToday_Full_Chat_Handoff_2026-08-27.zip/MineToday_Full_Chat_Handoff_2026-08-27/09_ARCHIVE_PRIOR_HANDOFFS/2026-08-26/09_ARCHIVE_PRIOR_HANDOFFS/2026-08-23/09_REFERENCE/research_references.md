# Research References Mentioned During the Conversation

These were used conceptually during the research phase:

- Microsoft research overview: RankNet -> LambdaRank -> LambdaMART.
- Google: LambdaLoss framework for ranking-metric optimization.
- Google: Wide & Deep Learning for recommender systems.
- Deep & Cross Network V2 (DCN-V2).
- Iterative stratification for multilabel data.
- CatBoost ranking objectives including YetiRank / NDCG-aligned modes / StochasticRank.
- LightGBM ranking objectives including LambdaRank and rank_xendcg.

The final direction moved away from simply using more sophisticated rankers because public evidence favored the simpler V3.1 relevance-calibration family.
