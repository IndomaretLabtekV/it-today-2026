# Why V3.1 Was the Real Breakthrough

V3.1 matched the hidden generator better than generic semantic models.

## Useful ingredients
- word TF-IDF + char TF-IDF
- template/topic-aware text tags
- current/recent/older views
- assessment score tokens
- invalid-assessment flags
- topic counts / recency / last-position / latest indicators
- style counts
- chat count/history length
- per-module nonlinear LightGBM calibration

## V3.1 conservative recall@5 snapshot
- M001 .6614
- M002 .7601
- M003 .7990
- M004 .0020
- M005 .3633
- M006 .7316
- M007 .5435
- M008 .3308
- M009 .7261
- M010 .4338
- M011 .0923
- M012 .7220
- M013 .1101
- M014 .4183
- M015 .6238
- M016 .7155
- M017 .5353

## Why calibration helps
The sparse backbone ranks lexical similarity/intent well. The per-module nonlinear layer learns intent × skill-gap × prerequisite interactions that Ridge cannot represent.

The main public gain came from bringing the right modules into positions 2–5, especially around rank 5, while top1 accuracy changed very little.
