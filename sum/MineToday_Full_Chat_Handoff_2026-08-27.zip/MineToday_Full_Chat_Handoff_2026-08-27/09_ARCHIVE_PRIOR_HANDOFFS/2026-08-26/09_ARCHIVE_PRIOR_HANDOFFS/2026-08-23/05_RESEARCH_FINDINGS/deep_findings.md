# Deep Research Findings

## 1. This is a synthetic-generator problem more than a generic semantic-NLP problem
Repeated phrases/templates, duplicate messages, spelling noise, current/recent wording, and assessment readiness explain why word/char TF-IDF is unusually strong.

Transformers/cross-encoders tend to collapse surface distinctions that are actually informative about the generator.

## 2. Assessment is a gate, not a side feature
Skill scores determine whether a mentioned topic should be recommended directly, treated as already mastered, or used as a prerequisite for a more advanced module.

## 3. Latest intent is strongly relevant but often overused as top-1
Examples of direct latest-topic true top1 probability from analysis:
- Python -> M002 ~50.5%
- SQL -> M003 ~54.4%
- Statistics -> M006 ~49.4%
- EDA -> M007 ~33.4%
- ML -> M009 ~35.8%
- GenAI -> M012 ~42.6%
- Dashboard -> M008 ~32.4%
- MLOps -> M016 ~27.2%

Models often predicted the direct topic as top1 much more frequently. Hard topic->top1 rules therefore hurt.

## 4. Real-time recency matters
Days since topic mention has strong monotonic decay. Message-position recency alone loses information.

## 5. Template/wording identity matters, but exact-template memory is too noisy
Conditional top1 distributions can change drastically between templates even for the same broad topic. However exact-template memory has weak standalone OOF because target generation is partly stochastic/latent.

## 6. There is no strong observable train/test domain shift
Adversarial/domain AUC around 0.49–0.51. Sequential splits should be stress tests, not the primary objective.

## 7. Part of the target is stochastic/unobserved
K=4/5/6 is nearly unpredictable, ordered positive sequences are almost all unique, and duplicate visible profiles can have different targets.

This sets a practical ceiling on deterministic reverse-engineering and favors expected relevance/utility models over exact sequence memorization.

## 8. The strongest public mechanism is relevance-set calibration
The progression sparse -> cal035 -> cal045 is the only clean mechanism repeatedly confirmed by public LB.

## 9. cal045's gain is mainly at the Top-5 boundary
For .35 -> .45, approximate NDCG contribution changes by predicted position were:
- rank1: -0.000548
- rank2: +0.000213
- rank3: -0.000156
- rank4: +0.000042
- **rank5: +0.000736**

This is a central finding: improve membership/cutoff and ranks 2–5 rather than chase top1 accuracy.

## 10. Rare modules should not be globally boosted
M004/M011/M013 have low top1 frequency and are often secondary. Global boosts can sacrifice common high-value modules.

## 11. More complex rankers often over-correct
V4/V5/V6 could improve OOF but often changed too much or learned train-specific ordering patterns. The public champion remains simpler and better calibrated.

## 12. Champion-preserving residual corrections are the right design principle
New models should be allowed to modify only a small percentage of test rankings and should shrink back toward cal045 unless evidence is strong.
