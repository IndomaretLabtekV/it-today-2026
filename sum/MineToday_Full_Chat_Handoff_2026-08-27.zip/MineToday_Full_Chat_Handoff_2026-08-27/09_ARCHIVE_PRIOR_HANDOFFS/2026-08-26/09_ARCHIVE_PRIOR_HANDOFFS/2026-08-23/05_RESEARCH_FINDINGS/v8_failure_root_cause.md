# V8 Failure Root-Cause Analysis

V8 was important because it produced the clearest mismatch between attractive offline evidence and public LB.

## Offline
Repeated calibration w=.60 looked ~+0.0021 better than cal045 with positive bootstrap and leave-one-seed-out stability.

## Public
- repeated full-fit .60: 0.65577 vs cal045 0.65639
- repeated foldbag .60: 0.65140

## Root causes inferred

### A. Cross-fold/second-order stacking dependency
The base OOF was produced using one fold system. Repeated calibration used different fold assignments. A calibration-training row could contain a base-OOF feature produced by a base model whose training set included labels from what is now another calibration-validation user. This is not direct row leakage but breaks clean independence and makes the repeated-seed OOF too optimistic.

### B. Raw probability averaging changed per-module marginal scale
The public-winning seed42/cal045 has an implicitly validated per-module score distribution. Averaging other seeds changed priors/scales as well as user ordering.

### C. Foldbag calibration reduced effective training size
The successful public recipe uses a full-data nonlinear calibrator after the bagged sparse representation. Foldbag calibration trained each nonlinear model on only ~80% of labels, which was expensive with just 4,000 users.

## Consequence
- do not use repeated calibration fold assignments for model selection unless fully nested with matching base folds;
- do not average raw seed probabilities blindly;
- keep full-data final calibrator style for public candidates;
- preserve champion marginal distributions whenever adding diversity.
