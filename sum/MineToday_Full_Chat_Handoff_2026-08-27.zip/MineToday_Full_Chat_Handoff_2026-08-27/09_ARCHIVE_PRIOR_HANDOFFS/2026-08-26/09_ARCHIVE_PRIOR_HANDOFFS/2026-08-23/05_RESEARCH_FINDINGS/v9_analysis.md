# V9 Analysis

V9 was designed after the V8 failure to preserve the public champion's score distribution while using nested ordinal corrections.

## Strict nested results
- cal045-equivalent nested anchor: 0.663316
- V9: 0.664170
- delta: +0.000854
- all 5 folds positive
- bootstrap 95% CI barely positive: [+0.000014, +0.001710]

## Prediction conservatism
- Top-5 membership changed on only 6.9% of test users
- Top1 changed on only 0.8%

This is much safer than earlier global rankers/ensembles.

## Why it was still rejected
The predeclared promotion threshold was +0.0010. The observed +0.000854 is directionally positive but too small relative to the 0.00166 public gap and public noise.

## Module effects
Helpful:
- M002 Python
- M015 No-Code AI
- M007 EDA
- M009 ML
- M003 SQL
- M008 Dashboard

Harmful:
- M012 GenAI (largest negative contribution)
- M010 CV
- M001 Excel

Do not hard-code those module signs. Use fold-safe shrinkage instead.
