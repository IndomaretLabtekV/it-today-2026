# Validation Lessons

## OOF is not automatically unbiased after repeated human/model selection
Even correctly out-of-fold predictions become an implicit validation training set when the same OOF is inspected repeatedly for architecture, weight, feature, and ensemble decisions.

This likely contributed to the V3.1/V4/V6 ensemble appearing ~0.6676 OOF but scoring only 0.65489 public.

## Paired deltas matter more than absolute OOF
The comparison should be:
`NDCG(candidate) - NDCG(cal045)` per user/fold,
not just “candidate OOF = 0.66x”.

## Strict nested evaluation is preferred for stacked/residual models
Outer validation users must not influence:
- sparse/base model training,
- calibration training,
- early stopping,
- alignment/shrinkage fitting,
- blend/residual weight choice.

## Repeated split seeds are for robustness, not necessarily test ensembling
Use repeated seeds to ask “does the delta persist?” Do not automatically average their test probabilities.

## Sequential / ID-tail splits
Useful as a stress test only. Adversarial validation gives no strong evidence of a real train-test regime shift.

## Public LB is noisy
Per-user NDCG variation is large (~0.17–0.18 absolute SD in earlier diagnostics). Tiny public differences should not trigger architecture changes by themselves.

## Promotion rule philosophy
Only submit when:
- paired gain is practically large enough to matter,
- repeated/nested folds are consistently positive,
- bootstrap lower bound is >0 if feasible,
- test changes remain conservative,
- the mechanism is supported by previous public evidence.
