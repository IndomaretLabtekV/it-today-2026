# Recommended Gate Before Any New Submission

Use exact/public-equivalent **cal045** as the immutable champion.

For the next candidate (V9.1 or later), aim for:

1. **Paired nested delta >= +0.0015**, ideally >= +0.0020.
2. Positive in **at least 4/5**, ideally 5/5, outer folds.
3. Paired bootstrap 95% lower bound > 0.
4. No single module/fold contributes nearly all of the gain.
5. Sequential/ID-tail stress split not catastrophically negative.
6. Test Top-5 membership changes <= about **8%** for the first candidate.
7. Test Top-1 changes <= about **1–1.5%**.
8. Final inference uses a **full-data calibrator**, not foldbag calibration.
9. No external precomputed artifact dependency in the final reproducible notebook.
10. Do not submit solely because absolute OOF exceeds 0.667/0.670.
