# What Each Version Taught Us

- **V1:** lexical Ridge beat semantic bells and whistles; semantics alone are a bad proxy.
- **V2:** better OOF does not guarantee proportional LB transfer; stack complexity can mislead.
- **V3:** cross-encoder solves “semantic similarity”, not “next learning step”.
- **V3.1:** the real breakthrough is structured sparse lexical modeling + per-module relevance calibration.
- **V4:** rank-aware candidate modeling has some signal, but small incremental gain.
- **V5:** categorical/template interactions are real, but high-variance categorical rankers do not automatically transfer.
- **V6:** nested design is necessary, but complexity still needs statistically meaningful paired gains.
- **Ensemble:** repeatedly inspected OOF can be overfit by the human/model-selection loop even if each base OOF is technically out-of-fold.
- **V7:** local pairwise swaps are too noisy; ranking corrections must be even more conservative/aggregate.
- **V8:** seed averaging and foldbag inference can destroy public-validated calibration; OOF stability alone was not enough due cross-fold dependency and scale drift.
- **V9:** preserving champion distribution and adding a small nested ordinal residual is directionally correct; next problem is improving effect size without breaking calibration.
