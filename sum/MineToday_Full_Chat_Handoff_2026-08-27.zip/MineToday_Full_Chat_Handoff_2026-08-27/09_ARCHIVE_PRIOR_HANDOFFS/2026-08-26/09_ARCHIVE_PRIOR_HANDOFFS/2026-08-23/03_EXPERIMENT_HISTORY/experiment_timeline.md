# Experiment Timeline: V1–V9

## V1 — Ultimate Baseline
Main ideas:
- LightGBM LambdaRank
- Ridge sparse model
- Qwen3 embedding
- Qwen3 reranker
- template memory

OOF / diagnostics:
- final OOF: **0.640542**
- Ridge: **0.635414**
- LightGBM LambdaRank: 0.613058
- Qwen3 embedding: 0.426644
- Qwen3 reranker: 0.483830
- template memory: 0.504565
- top1 accuracy: 46.75%
- true top1 in predicted top5: 82.03%

Public LB: **0.63629**.

Lesson: expensive semantic components solved the wrong proxy. Sparse lexical signal was already stronger.

---

## V2 — Supervised Stack
Main ideas:
- stronger TF-IDF / sparse heads
- supervised GTE
- direct ranker
- template memory
- assessment trees

OOF:
- final: **0.655324**
- sparse OOF: 0.648442
- raw_rel 0.644171
- ordinal 0.644631
- top1 0.634855
- binary 0.636743
- recent_ordinal 0.636751
- supervised GTE 0.635888
- direct ranker 0.617271

Public LB: **0.64413**.

Lesson: large OOF jump did not transfer proportionally. Complexity and stacking/model-selection noise were already becoming a problem.

---

## V3 — Cross-Encoder
Architecture:
- `Alibaba-NLP/gte-multilingual-reranker-base`
- profile × module cross-encoder
- LoRA
- listwise/ranking losses

The model was slow/fragile, folds around ~0.60–0.62, and not competitive with sparse baselines.

Lesson: semantic relatedness between chat and module is not the target. The task is “next learning step given intent + skill gap + prerequisites + journey”.

---

## V3.1 — Structured Sparse Breakthrough
Architecture:
- word + char TF-IDF
- current/recent/older tags
- discrete assessment tokens
- ~134 structured user features
- topic/style/history features
- five sparse Ridge heads
- per-module LightGBM binary relevance calibration

Executed sparse/head scores:
- raw 0.657337
- ordinal 0.656858
- top1 0.630534
- binary 0.649695
- recent 0.646070
- sparse backbone (0.90 raw + 0.10 top1): **0.658254**

Calibration blends:
- w=.20 0.661777
- w=.35 **0.662358**
- w=.40 0.662386
- w=.45 **0.662646**
- w=.50 0.662222
- w=.60 0.662001

Public:
- sparse-safe: **0.65036**
- conservative w=.35: **0.65540**
- later cal045 w=.45: **0.65639**

This remains the key breakthrough and current public champion family.

---

## V4 — Multi-Expert Structured LambdaRank
Architecture:
- V3.1-like sparse multi-expert features
- message-max/history/current intent experts
- candidate-level LambdaRank
- structured/calibration features

Run results:
- sparse multi-expert: 0.658623
- V3.1-like anchor: 0.662608
- LambdaRank: **0.664117**
- gated mixture: 0.663857
- robust mixture: 0.663826
- top1 accuracy ~49.40%

LambdaRank beat anchor 5/5 folds in that run, but it was not directly public-tested as the main candidate.

Important implementation issue discovered: OOF used per-fold best iterations while test initially used a single full-data model at median iterations, creating inference mismatch.

Lesson: ranking layer adds some signal, but gain was small and later ensemble use did not transfer.

---

## V5 — Generator-Aware Categorical YetiRank
Ideas:
- CatBoost YetiRank
- categorical module/topic/template interactions
- absolute-rank target
- true-time recency
- fold-bagged test inference

Run:
- sparse V5: 0.657001
- structured anchor: 0.661854
- YetiRank: **0.664240**
- blend90: 0.663865

Lesson: YetiRank itself was better than the V5 anchor, but the sparse/backbone regressed. Improvement over V4 was essentially sideways (~+0.00012).

---

## V6 — Nested Ordinal Multi-Expert NDCG Stack
Ideas:
- stricter nested stacking
- absolute-rank/ordinal experts
- top1 expert
- NDCG-aligned ranker
- 5-fold bagged inference

Run:
- V6 nested ranker: about **0.664486**
- V6 primary: ~0.664455
- nested anchor: ~0.662909
- tail diagnostic around ~0.65999
- ranker beat anchor only 3/5 folds; notebook marked REVIEW.

Lesson: more rigorous than prior rankers but still not clearly enough better than V3.1 to justify public submission.

---

## Cross-Version Borda Ensemble (V3.1 + V4 + V6)
Chosen from OOF analysis:
- ~20% V3.1 conservative
- ~40% V4 ranker
- ~40% V6 ranker
- within-user rank/Borda normalization

OOF appeared around **0.6676**, with stable-looking folds.

Public LB: **0.65489**, below V3.1 conservative.

Lesson: model-selection overfitting to repeatedly inspected OOF is real. OOF predictions can be row-safe yet still become an implicit training set for human weight/architecture decisions.

---

## V7 — Champion-Constrained Pairwise Surgical Reranker
Idea:
- freeze V3.1 champion
- permit only local/adjacent Top-5 and boundary swaps
- high-confidence pairwise classifier
- max one swap/user

Results:
- V3.1 champion OOF: 0.662358
- cal045: 0.662646
- strict nested champion: 0.663534
- strict nested surgical: **0.663150**
- delta surgical vs fair anchor: **-0.000384**
- only 2/5 folds positive
- bootstrap CI crossed zero
- sequential stress negative

Lesson: user-level swap correctness is too noisy. Pairwise surgical reranking was rejected.

Positive side-result: cal045 probe was a clean low-risk hypothesis and later scored **0.65639 public**, becoming the public champion.

---

## V8 — Repeated-CV Relevance Calibration Bagging
Idea:
- keep V3.1 backbone
- run relevance calibration over 5 CV seeds
- average probabilities
- test weights around .50–.675

Offline looked excellent:
- cal045 ref: 0.662646
- w=.50 ~0.664253
- w=.55 ~0.664437
- w=.60 ~0.664735
- w=.675 ~0.664926
- paired bootstrap for w=.60 looked positive

Public:
- repeated full-fit w=.60: **0.65577**
- repeated foldbag w=.60: **0.65140**

Later diagnosis:
- cross-fold dependency/second-order stacking contamination made repeated-seed OOF too optimistic;
- averaging seeds altered per-module marginal calibration/prior scale that seed42/cal045 had already validated publicly;
- foldbagging weakened both base and nonlinear calibrator effective training size.

Lesson: do not average calibration seeds or foldbag calibrators just because OOF rises.

---

## V9 — Nested Distribution-Preserving Ordinal Calibration
Goal:
- exact cal045 anchor
- preserve public-validated per-module distribution/scale
- use same-split diversity and a small ordinal residual
- strict nested outer validation

Strict nested result:
- anchor: **0.663316**
- V9: **0.664170**
- gain: **+0.000854**
- fold deltas: +0.000625, +0.000418, +0.001353, +0.001169, +0.000706
- **5/5 positive**
- bootstrap 95% CI: **[+0.000014, +0.001710]**
- test Top-5 change: **6.9%**
- top1 change: **0.8%**

Promotion gate required +0.0010, so V9 was not promoted/submitted.

Diagnostics:
- distribution-preserving-only candidate ~0.662541 (below cal045 diagnostic)
- dist+ordinal diagnostic ~0.663463

Module behavior:
- helped: M002, M015, M007, M009, M003, M008
- hurt: M012 notably, then M010 and M001

Lesson: V9 is the cleanest post-cal045 research success, but effect size is still too small to justify a submission against a 0.00166 public gap.
