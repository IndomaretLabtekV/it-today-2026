# Approaches to Avoid / Deprioritize

## Avoid as primary direction
- transformer/cross-encoder semantic reranking
- global LambdaRank/YetiRank replacement of V3.1
- cross-version weighted/Borda ensemble chosen from repeatedly inspected OOF
- global rare-module boosting
- hard direct-topic -> top1 boosts
- exact template-memory model as final predictor
- KNN/template-nearest-neighbor as final predictor
- pairwise adjacent-swap reranker (V7 result negative)
- repeated-CV raw probability averaging across fold seeds
- foldbagging nonlinear relevance calibrators
- module-specific hand-tuned offsets selected on full OOF
- large handcrafted cross-token explosion

## Why
These either:
- solved the wrong proxy,
- overfit small data,
- changed too many test rankings,
- broke publicly validated probability scale,
- or had unstable paired validation.
