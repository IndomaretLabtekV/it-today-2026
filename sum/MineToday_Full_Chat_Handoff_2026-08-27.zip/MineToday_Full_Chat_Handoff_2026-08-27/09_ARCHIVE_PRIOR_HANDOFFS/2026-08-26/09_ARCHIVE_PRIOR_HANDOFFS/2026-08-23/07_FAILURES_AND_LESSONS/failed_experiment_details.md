# Failed / Low-Value Experiment Details

## Massive explicit cross tokens
Template×topic, topic×skill band, style×topic, transitions, skill-pairs: cross-only ~0.63 and hstacking to full TF-IDF worsened raw OOF to ~0.6505.

## Alternative metric targets
- zeroing rank6: OOF ~0.65677
- rank5 ordinal [5,4,3,2,1,0]: ~0.65698
- discounted-contribution target: ~0.65491
These added little diversity.

## Label graph/profile propagation
Only ~+0.0003–0.0005; not a main direction.

## Per-module calibration weights/biases
Cross-fitted coordinate tuning was unstable; no reliable improvement over global conservative calibration.

## All-score-vector calibrators
Feeding all 17 base scores to meta calibrators did not beat the simpler own-module-score design.

## Message-level expert
Standalone max aggregation around 0.61317; small ~5% blend could add only ~0.00058. Complementary but too weak to be central.

## Candidate LambdaMART
Could add ~0.001–0.002 in some nested pseudo-tests, but public evidence did not justify replacing the champion.

## Global cutoff-aware LightGBM probe after V8
Around 0.66107, worse than cal045; rejected.

## Hurdle / raw regression / fixed-rank / multiclass-rank probes
Mostly ~0.6628–0.6629 range; too small/unstable.

## Cumulative ordinal relevance
Around 0.66326 in one line of analysis; more promising conceptually, eventually folded into V9-style ordinal residual ideas rather than used standalone.
