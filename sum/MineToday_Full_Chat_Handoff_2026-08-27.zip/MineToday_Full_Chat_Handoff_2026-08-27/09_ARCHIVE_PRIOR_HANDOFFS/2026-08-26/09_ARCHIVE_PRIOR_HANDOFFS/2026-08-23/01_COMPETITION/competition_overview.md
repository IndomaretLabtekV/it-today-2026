# Competition Overview

## Competition
MineToday: Data Mining Competition – IT Today 2026

Theme: **Intelligent Learning Path / AI Course Advisor**. For each user, predict/rank the most relevant learning modules.

## Metric
**NDCG@5**.

The task is not merely “predict relevant/not relevant”. Ordering matters heavily, especially top positions, but the strongest public improvement we found came from improving **Top-5 membership and ranks 2–5**, not from top-1 classification alone.

## Core constraints discussed from the rulebook
- Maximum **3 Kaggle submissions per day**.
- No external dataset beyond organizer-provided data.
- Multiple ML models are allowed.
- Open-source pretrained models are allowed.
- Paid pretrained models are not allowed.
- Directly asking an LLM / Generative AI system to generate answers for the test set is prohibited; coding assistants are allowed.
- Final notebook + seed should reproduce the final submission within roughly **0.001 tolerance**.
- Top-5 notebook validation is part of final verification.
- Competition submission deadline discussed: **9 Sep 2026**; notebook/final material follows after that.

## Practical implication
The strongest path should be fully reproducible from raw organizer files, without depending on hidden/precomputed artifacts as external data.
