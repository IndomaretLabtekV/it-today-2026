# Module Catalog

17 fixed candidates:

| ID | Module |
|---|---|
| M_001 | Excel |
| M_002 | Python Programming |
| M_003 | SQL |
| M_004 | Web Scraping |
| M_005 | Version Control |
| M_006 | Statistics |
| M_007 | EDA |
| M_008 | Dashboard |
| M_009 | Machine Learning |
| M_010 | Computer Vision |
| M_011 | NLP |
| M_012 | Generative AI |
| M_013 | Prompt Engineering |
| M_014 | AI Automation |
| M_015 | Pemanfaatan AI / No-Code |
| M_016 | MLOps |
| M_017 | Career / Portfolio |

Prerequisite interpretation used throughout the research:
- M001 beginner
- M002 beginner
- M003 beginner
- M004 needs Python
- M005 medium / tooling
- M006 medium
- M007 needs Python + Statistics
- M008 related to SQL/Excel
- M009 needs EDA + Statistics
- M010 needs ML/DL
- M011 needs ML
- M012 related to NLP/advanced AI
- M013 medium
- M014 medium
- M015 beginner/no-code
- M016 needs ML + Python + Version Control
- M017 broad/all-level career module
