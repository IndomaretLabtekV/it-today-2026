# MineToday IT Today 2026 — Full Conversation Handoff

**Snapshot date:** 2026-08-23 (WIB)

This package is a structured handoff of the work done in the current ChatGPT conversation for the **MineToday: Data Mining Competition – IT Today 2026**. It intentionally **does not include notebooks, result ZIPs, OOF arrays, or submission CSVs**. Instead it documents the entire state of the work: competition setup, dataset findings, experiment history V1–V9, public leaderboard evidence, failed directions, validation lessons, current best model, and the next recommended work.

## Read in this order

1. `00_START_HERE/CURRENT_HANDOFF.md` — the shortest complete handoff for a new chat.
2. `04_LEADERBOARD_AND_SUBMISSIONS/submission_history.md` — what was actually submitted and what happened.
3. `03_EXPERIMENT_HISTORY/experiment_timeline.md` — V1 through V9.
4. `05_RESEARCH_FINDINGS/deep_findings.md` — the strongest dataset/modeling discoveries.
5. `06_VALIDATION_AND_METHODOLOGY/validation_lessons.md` — why several great OOF ideas failed on public LB.
6. `08_CURRENT_STATE_AND_NEXT_STEPS/current_state.md` — exact current status.
7. `08_CURRENT_STATE_AND_NEXT_STEPS/v9_1_plan.md` — the next experiment that was planned but not yet built/run.

## Most important state in one paragraph

The current public champion from this conversation is **V3.1 single-seed full-data relevance calibration with blend weight 0.45**, scoring **0.65639 public NDCG@5**. The current leaderboard leader is **0.65805**, so the gap is **0.00166**. More complex global rankers, cross-version ensembles, repeated-seed calibration, and fold-bag calibration did not beat that public score. V9 finally produced a **strictly nested, 5/5-fold-positive improvement** over a nested cal045 anchor, but the paired gain was only **+0.000854**, below the predeclared +0.0010 promotion gate, so it was **not recommended for submission**. The next planned experiment is **V9.1: adaptive/shrunk distribution-preserving ordinal residuals anchored to cal045**, with module-wise shrinkage learned fold-safely from other folds only.
