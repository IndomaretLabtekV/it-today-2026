# Current Handoff — Paste/Use This First in a New Chat

## Goal
Win or exceed the current MineToday public leaderboard top score. Current top = **0.65805**. Our best public score = **0.65639**. Gap = **0.00166**.

## Current public champion
**V3.1 / V7 cal045 probe**: same V3.1 structured sparse + per-module binary relevance calibration, with **45% relevance-calibration / 55% sparse** blend (conceptually; exact internal implementation is the V3.1 cal045 artifact).

Public LB: **0.65639**.

This is the only modeling mechanism that has repeatedly shown clean public improvement:
- V3.1 sparse: **0.65036**
- V3.1 conservative w=.35: **0.65540**
- V3.1 cal045 w=.45: **0.65639**

## Do NOT submit these again
- V3.1/V4/V6 Borda ensemble: **0.65489**
- V8 repeated-CV full-fit w=.60: **0.65577**
- V8 repeated-CV foldbag w=.60: **0.65140**
- V7 pairwise: failed nested validation; do not submit
- V9 primary: because promotion gate failed, primary falls back to cal045/reference; do not waste a slot

## Current research result: V9
V9 = nested distribution-preserving ordinal calibration anchored to cal045.

Strict nested results:
- nested cal045 anchor: **0.663316**
- V9: **0.664170**
- paired gain: **+0.000854**
- fold deltas: **+0.000625, +0.000418, +0.001353, +0.001169, +0.000706**
- wins: **5/5 folds**
- bootstrap 95% CI: **[+0.000014, +0.001710]**
- test Top-5 membership changed: **6.9%**
- test Top-1 changed: **0.8%**
- promotion gate required +0.0010, so V9 was **not promoted/submitted**.

V9 helped most on M002, M015, M007, M009, M003, M008; hurt notably M012, then M010 and M001.

## Exact next experiment planned
**V9.1: Adaptive/Shrunk Distribution-Preserving Ordinal Calibration**.

Keep cal045 immutable. Keep V9 residual machinery. Learn module-wise residual shrinkage using only the OTHER outer folds so that weak/unstable module corrections shrink toward zero, while consistently useful module corrections retain more weight. No hard-coded “boost Mx” rules.

Target gate before any submission:
- paired nested delta vs exact cal045 **>= +0.0015**, ideally +0.0020
- positive in at least **4/5**, ideally 5/5, outer folds
- paired bootstrap lower 95% bound > 0
- no catastrophic stress split
- test Top-5 change <= about **8%**
- Top-1 change <= about **1–1.5%**

If V9.1 cannot clear that, do NOT submit it.

## Submission discipline
A new day had started before V9 was run, and no public submission was made after that in the current chat. Treat today's slots as precious. Do not submit because absolute OOF looks high. Only submit after paired nested evidence against cal045 is strong enough.
