# Metric, Oracle Ceilings, and Where the Headroom Lives

## Metric

The competition metric used throughout the project is **NDCG@5 at user level**.

Therefore both of these matter:

1. whether a relevant module enters the Top-5,
2. where that module is ordered inside the Top-5.

Mistakes in higher ranks are more expensive because of the NDCG discount.

## Champion retrieval quality

For Consensus3, the average number of truly positive/relevant modules in the predicted Top-5 was diagnosed at roughly:

**2.8435 relevant modules out of 5**.

Observed distribution from the diagnostic used in the project:

- 0 relevant in Top-5: 11 users
- 1: 232
- 2: 1,127
- 3: 1,730
- 4: 802
- 5: 98

Only a small fraction of users have a fully correct relevant set in Top-5. This demonstrates that the largest theoretical headroom is **relevance-set recovery**, not micro-adjusting random within-band target values.

## Oracle results established during research

### Same champion Top-5 set, perfect ordering

If the five modules already selected by Consensus3 were perfectly reordered using the ground truth:

**NDCG ≈ 0.73817**

This shows order matters, but later pairwise experiments showed much of this oracle ordering is not reliably learnable.

### Perfect choose/reorder within champion Top-6

**NDCG ≈ 0.78472**

Top-7 oracle was around **0.82414**.

These are upper bounds, not evidence that a model can learn the oracle choices.

### Perfect relevant-vs-zero identification while mostly preserving champion order

Diagnostic ceiling was about:

**NDCG ≈ 0.9362**

This very high ceiling is one reason the project shifted attention toward **binary relevance estimation**.

### Maximum one membership replacement per user

An oracle allowed to replace at most one false-positive Top-5 module with one outside candidate reached roughly:

**NDCG ≈ 0.8583**

Again, the challenge is not existence of headroom; it is selecting beneficial corrections without introducing harmful ones.

## Expert-family oracle ceilings

### Exact Consensus3 + V9.1 + V10-C family

A perfect per-user oracle choosing among those three whole-user experts reached only:

**0.6732083**

Therefore this exact family cannot reach 0.70 even with a perfect router.

### Broader previously-built expert pool

Perfect whole-user selection over the larger pool of V9/V10/V10.1-style experts reached about:

**0.69861056**

Even a perfect selector over that existing family remained just below 0.70.

This was a decisive reason to stop treating expert routing as the route to the 0.7 target.

## Learnability vs oracle warning

A large oracle gap does **not** imply an actionable model opportunity.

Example: Top-6 oracle is huge, but rank #5 vs #6 reversal classification was approximately AUC **0.52**, close to random. The project repeatedly learned that many oracle opportunities are not predictable from available features.

The correct question is always:

> Is the correction not only valuable if known, but **learnable and stable under honest validation**?
