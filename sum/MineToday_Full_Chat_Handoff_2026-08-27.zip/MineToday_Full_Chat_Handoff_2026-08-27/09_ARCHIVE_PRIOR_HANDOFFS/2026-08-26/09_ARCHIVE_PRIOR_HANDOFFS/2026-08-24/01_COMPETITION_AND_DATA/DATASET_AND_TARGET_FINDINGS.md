# Dataset and Target Findings

## Organizer files

The competition data used throughout the project consists of:

- `chat_history.csv`
- `modules_catalog.csv`
- `user_assessments.csv`
- `train_relevance.csv`
- `test.csv`
- `sample_submission.csv`

## Shapes and coverage established during analysis

- `train_relevance.csv`: **4000 × 18**
  - `user_id`
  - 17 target columns for modules
- `test.csv`: **1000 × 1**
  - test `user_id`
- `sample_submission.csv`: **1000 × 18**
- `user_assessments.csv`: **5000 users** with 10 assessment-question fields represented in JSON-like/raw mixed formats
- `chat_history.csv`: **14,573 rows**, **4,940 users** observed in chat
- `modules_catalog.csv`: **17 modules**

Additional chat IDs beyond train/test were observed in the organizer data (90 organizer unlabeled users U5001–U5090 in the analysis). These were not treated as labeled external data.

Train and test user IDs are disjoint.

Missing chat coverage observed:

- **117 train users** without chat
- **33 test users** without chat

## Chat duplication/template structure

Important repeated-pattern findings:

- about **51.5%** of chat rows are duplicate rows beyond the first copy after normalization/analysis,
- about **69.869%** of test chat rows exact-match a normalized train message,
- about **95.76%** of test users with chat have at least one normalized message previously seen in train.

This initially suggested template memory might dominate. Later diagnostics showed a crucial distinction:

> repeated message/template identity is useful context, but **repeated message does not imply repeated target**.

A leakage-safe cross-fitted exact-normalized-message target prior had high coverage (~92%) but weak standalone ranking quality (~0.498 OOF), and even a tiny direct blend into Consensus3 degraded score. Therefore template identity should be used as a lexical/context feature, not as a direct label lookup.

## Chat signal that repeatedly mattered

**Recency/current intent** is one of the strongest stable ideas in the project.

User goals can change over conversation history. Therefore treating all chat messages equally can blur the latest request. Earlier successful sparse pipelines explicitly encoded recency/latest-message information.

This motivated the V16 three-view semantic design:

1. current intent,
2. recent trajectory,
3. broader learner/profile history.

## Assessment cleaning

Assessment values were observed in mixed forms:

- integers,
- numeric strings,
- Indonesian number words in the 0–5 range,
- invalid/outlier values.

The strong V3.1-era cleaning approach:

- normalize valid values,
- preserve invalid/dirty flags,
- row-median imputation for invalid/missing values,
- retain structured skill/readiness features.

Assessment is interpreted more as **readiness/eligibility/skill gap information** than as a direct ranking order generator.

## Number of positive modules per train user

Every train user has exactly **4, 5, or 6 positive modules**.

Counts:

- K=4: **1,362 users**
- K=5: **1,285 users**
- K=6: **1,353 users**

K itself was found to be difficult to predict reliably from features.

## Target relevance bands

Positive target values follow strongly separated rank bands:

- rank 1: **1.00**
- rank 2: **0.80–0.90**
- rank 3: **0.65–0.75**
- rank 4: **0.50–0.60**
- rank 5: **0.35–0.45**
- rank 6: **0.20–0.30**

The target has only about **57 unique numeric values**.

Within each band, values are quantized to 0.01. Endpoint values occur at roughly half the frequency of interior values. Observed endpoint/interior frequency ratios were approximately:

- rank2: 0.514
- rank3: 0.493
- rank4: 0.525
- rank5: 0.490
- rank6: 0.470

This is statistically consistent with a mechanism similar to drawing a continuous value inside a band and rounding to two decimals. This is an **inference**, not an organizer-confirmed generator.

Practical implication:

> exact within-band magnitude appears to contain substantial stochastic/noisy variation. Predicting `0.83` vs `0.87` is much less promising than predicting which modules are relevant and the broad rank order.

## Sequence/set uniqueness

- about **3,960 unique ordered positive sequences** among 4,000 train users
- about **3,146 unique positive sets**

This makes memorizing complete target sequences unrealistic even though chat templates repeat heavily.

## Distribution shift diagnostic

Train/test adversarial classifiers were around **AUC 0.49–0.53**, so there was no strong broad train/test shift detected in the engineered features.

However, later experiments showed that **conditional model/action utility can still shift**, even when marginal train/test discrimination is weak.

## Module-level stationarity

Module positive prevalence was relatively stable across contiguous 1,000-user blocks. Median maximum deviation from overall module prevalence was around **1.2 percentage points**.

This is one reason global/module-level calibration tends to transfer better than user-specific routing.
