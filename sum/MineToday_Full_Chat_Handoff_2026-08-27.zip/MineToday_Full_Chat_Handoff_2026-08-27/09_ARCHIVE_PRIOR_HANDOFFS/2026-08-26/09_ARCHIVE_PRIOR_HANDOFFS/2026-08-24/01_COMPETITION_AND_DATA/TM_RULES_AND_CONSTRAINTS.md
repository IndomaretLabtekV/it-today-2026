# Technical Meeting Rules and Constraints Used in This Project

This file records the competition constraints as discussed in the chat from `TM MINETODAY.pdf` and the Technical Meeting Q&A. It should be treated as a practical compliance checklist for future notebooks.

## Core competition rules discussed

- Kaggle account/email must correspond to the competition registration.
- Kaggle team name must correspond to registered team name and team merging must be handled correctly.
- Maximum **3 submissions per day**.
- **No external dataset**. Task-specific data should come from organizer-provided files.
- Multiple machine-learning models are allowed.
- Python, R, or similar languages are allowed.
- No collaboration between competing teams during the competition.
- Open-source pretrained models were discussed as allowed.
- Paid pretrained models/services are not allowed.
- The Technical Meeting Q&A was interpreted as having **no explicit pretrained parameter-count limit**.
- Multi-GPU use was discussed as allowed.
- There was no competition-rule runtime ceiling discussed in the TM context used by this project, though Kaggle environment limits still apply operationally.
- LLM/Generative-AI usage is not allowed in the form of **directly asking for test-dataset relevance values / direct submission answers**.
- AI coding assistants are allowed for coding assistance.
- Finalists must provide a reproducible notebook and seed; output is expected to reproduce within the stated tolerance (discussion used tolerance **0.001**).
- Top 5 teams advance to the final stage according to the discussed TM schedule/rules.

## Practical interpretation adopted by this project

### Clearly safe pattern

```text
Organizer-provided text
    -> open-source frozen pretrained embedding model
    -> numeric embeddings/features
    -> supervised model fitted on organizer train labels only
    -> test prediction
```

The pretrained model is used as a **representation/feature extractor**, not as an agent asked to solve the competition test labels.

### Pattern intentionally avoided

```text
Prompt an LLM:
"Here is test user U4001 and 17 modules. Return relevance values M001...M017."
```

That is considered too close to the explicit prohibition on asking an LLM/GenAI directly for test values.

## Qwen-specific decision

For V16 the project chose **Qwen3-Embedding-8B**, not a general causal LLM, because:

- embedding is the intended model function,
- no generative output is needed,
- the model produces representations rather than submission labels,
- it can be frozen,
- downstream supervision uses organizer labels only,
- this approach is easier to defend under the Technical Meeting constraints than direct LLM ranking prompts.

A large reranker/cross-encoder can be technically attractive, but it was treated more cautiously because a pretrained reranker directly outputs query-document relevance and could be perceived as closer to “directly requesting test relevance.” If future work wants to use an 8B reranker, getting organizer clarification first would reduce rule ambiguity.

## Final compliance checklist for future notebooks

Before submission, verify all of the following:

1. No external task-specific data entered the pipeline.
2. Any pretrained model is open-source under the competition interpretation.
3. No paid API/service produced features or labels.
4. No LLM was asked to output test target values directly.
5. Train labels are used only on train users.
6. Cross-validation feature generation is leakage-safe.
7. Test representations use the same inference geometry as validated representations.
8. Fixed seeds are recorded.
9. Notebook can run from organizer files plus permitted pretrained weights.
10. Submission shape/columns/user IDs match sample submission exactly.
