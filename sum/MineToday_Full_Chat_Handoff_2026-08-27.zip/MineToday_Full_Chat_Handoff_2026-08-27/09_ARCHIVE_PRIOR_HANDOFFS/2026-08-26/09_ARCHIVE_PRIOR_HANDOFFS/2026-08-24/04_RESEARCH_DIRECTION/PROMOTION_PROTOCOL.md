# Promotion Protocol for Future Experiments

The project needs a stricter protocol because old OOF folds have been inspected many times.

## A. Immutable references

Always retain:

1. exact V12.2 Consensus3 prediction path,
2. candidate prediction path,
3. deterministic comparison on the same users.

No candidate should silently modify the champion path.

## B. Validation layers

A candidate should ideally pass all of these before Kaggle submission.

### 1. Historical ordinary CV

Use for comparability only. It is now partially a development set because the project has inspected it repeatedly.

### 2. New frozen matched audit

Use a new split seed or split regime selected before inspecting candidate results.

This should be treated as higher trust than old folds.

### 3. Chronological/blocked audit

Use multiple blocked splits if chronology is relevant. One tail block is not sufficient evidence.

### 4. Deployment geometry check

Measure:

- Top-5 set change rate,
- Top-5 order change rate,
- Top-1 change rate,
- score-distribution shift,
- train/validation/test behavior of any gate or margin.

The final test representation must look like the representation on which the model was validated.

## C. Second-stage rule

Any learned model whose features include predictions from another trained model must be **fully nested**.

Ordinary OOF base predictions are not automatically safe for training a meta-model evaluated on the same outer folds.

## D. Minimum evidence for promotion

Suggested standard:

- positive aggregate delta on new matched audit,
- majority or preferably 5/5 positive folds,
- bootstrap CI not materially crossing zero,
- positive blocked/chronological behavior if test is believed future-like,
- no single transition/module/subgroup explains nearly all gain,
- no large inference geometry mismatch,
- candidate change rate proportional to evidence,
- result stable to one or two predeclared seeds, not a broad search.

## E. Public submission usage

Public LB should be used as a **measurement**, not a hyperparameter optimizer.

Given 3 submissions/day:

- use one submission for the strongest truly promoted candidate,
- preserve remaining slots for high-information controlled probes only when needed,
- avoid submitting multiple neighboring betas/weights simply to hill-climb public LB.

## F. Fail closed

If evidence is mixed, primary output should equal the known champion.

V15 and V16 correctly implement this philosophy.
