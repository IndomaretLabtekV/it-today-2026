# Blacklist and Guardrails

These are not permanent theoretical bans. They are default “do not spend time here” rules based on repeated negative evidence.

## Blacklisted as default directions

### Whole-user expert routing

Reason: V13.1 public failure, second-level leakage, geometry mismatch, unstable conditional utility.

### Forced route fractions

Reason: top-k/top-percent nomination selects something even when absolute confidence is weak.

### Generic Top-6 pairwise reranking

Reason: V14 negative under honest nested validation.

### #5/#6 swap models

Reason: adjacent reversal AUC around 0.52; close to random.

### Borda / rank-only averaging

Reason: public degradation and loss of useful score-margin geometry.

### Repeated-seed probability averaging as automatic improvement

Reason: V8 public degradation.

### Exact-message target lookup/prior

Reason: repeated templates do not imply repeated target; direct cross-fitted prior was weak.

### Raw within-band relevance regression

Reason: target jitter appears substantially stochastic.

### Free 17-dimensional weight optimization

Reason: very high research-overfit risk on reused folds.

### Public-LB hyperparameter sweeping

Reason: burns daily submissions and overfits public subset.

## Guardrails for any future conditional model

If a conditional model is ever revisited:

- fully nested outer/inner construction,
- absolute abstention threshold,
- no mandatory action quota,
- action scope must match evidence scope,
- fold-matched test representation,
- branch/subgroup utility must be positive independently,
- expected NDCG utility, not just probability of being beneficial,
- tiny intervention rate unless evidence is overwhelming.

## Guardrails for semantic V16 descendants

- start with beta <= 0.25 or equivalent small smooth influence,
- diagnose module/view/novelty concentration first,
- standardize/calibrate semantic scores using train only,
- do not directly use raw cosine as the final relevance score,
- do not let semantics erase lexical/template evidence that is known to work,
- require new audit split evidence before public submission.
