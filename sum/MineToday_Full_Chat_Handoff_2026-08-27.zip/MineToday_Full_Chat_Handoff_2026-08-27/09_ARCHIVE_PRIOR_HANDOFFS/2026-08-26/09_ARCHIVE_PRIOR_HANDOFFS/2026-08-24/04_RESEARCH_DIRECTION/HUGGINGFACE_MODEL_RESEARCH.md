# Hugging Face / Large Embedding Model Research

## Why model size was reconsidered

Early semantic experiments used much smaller models and complex ranking stacks. After the project learned that post-processing/routing was the main source of overfit, large semantic models became attractive as a source of **new first-stage information**.

## Models discussed

### Qwen2.5-3B

The user initially proposed `Qwen/Qwen2.5-3B` as an example of using a larger Hugging Face model.

Decision: not preferred because it is a general causal/base language model, not a dedicated embedding model. Parameter count alone is not the goal.

### Qwen3-Reranker family

Attractive because the task is ranking/retrieval. However, a pretrained reranker directly outputs query-document relevance. The project treated this as a possible rules grey area relative to the TM prohibition on directly asking an LLM/GenAI for test relevance values.

Decision: defer or ask organizer clarification before making it the primary experiment.

### Qwen3-Embedding-4B

Strong dedicated embedding candidate and easier to fit on one/smaller GPU setups.

### Qwen3-Embedding-8B

Selected for V16 because it is the largest practical dedicated Qwen embedding model considered reasonable for Kaggle T4×2 while preserving clean “representation extractor” semantics.

V16 uses it frozen, not fine-tuned.

## Why not use a 32B/70B causal model as an embedding extractor

A larger general LLM is not necessarily a better embedding model. The desired product is:

```text
parameter count
× retrieval/embedding training objective
× multilingual quality
× inference practicality
× competition compliance
```

A dedicated 8B embedding model is more aligned than an arbitrarily larger causal LM.

## Why frozen first

Only 4,000 labeled train users exist.

Fine-tuning 8B immediately would create:

- much larger overfitting risk,
- harder nested validation,
- greater compute cost,
- ambiguity about whether gain came from pretrained semantics or supervised adaptation.

Frozen features make the scientific question clean:

> Does modern large semantic representation add stable complementary signal to the organizer-specific champion?

V16 currently answers: **possibly in future-like subsets, but not robustly enough globally yet.**

## Future large-model rule

Do not move to a larger model until the existing 8B embedding is shown to contain a useful stable signal after proper ablations. Bigger is not the next action by default.
