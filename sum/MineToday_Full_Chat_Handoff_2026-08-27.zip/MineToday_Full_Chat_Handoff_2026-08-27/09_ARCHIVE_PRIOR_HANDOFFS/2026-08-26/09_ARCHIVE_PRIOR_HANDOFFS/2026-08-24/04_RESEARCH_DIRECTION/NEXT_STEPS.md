# Recommended Next Steps

## Current priority: diagnose V16 before building V17

Do not immediately build another large notebook. The highest-value work is to understand why Qwen8B semantics are positive chronologically and negative in ordinary folds.

### Step 1 — semantic view ablation

Using the already-computed V16 embeddings, evaluate fixed first-stage feature sets:

1. current intent only,
2. recent trajectory only,
3. profile/readiness only,
4. current + recent,
5. current + recent + profile.

Keep downstream model/folds fixed. Do not tune per fold.

Goal: determine whether broad history dilutes current intent.

### Step 2 — per-module semantic contribution

For each M001–M017 compute, separately in ordinary, matched-audit, and chronological validation:

- binary relevance AUC,
- binary logloss/Brier if useful,
- difference from Consensus3 relevance calibration,
- effect on Top-5 entry/exit,
- NDCG contribution when semantic signal changes that module.

Goal: identify modules with stable semantic benefit across validation regimes.

### Step 3 — novelty/template stratification

Group users by organizer-data-only novelty features:

- exact normalized latest-message seen/unseen,
- percentage of chat messages seen in train,
- lexical nearest-neighbor similarity,
- chat count,
- presence/absence of chat,
- assessment completeness.

Measure sem025 delta in each group.

Goal: test whether Qwen mainly helps users where sparse template matching is weak.

### Step 4 — rolling chronological validation

Do not rely on one future block. Create multiple predeclared blocks, e.g. train earlier IDs and validate successive later intervals, while preserving leakage-safe feature generation.

Goal: determine whether the semantic advantage is consistently future-like or was a single-block artifact.

### Step 5 — only then define V17

If a stable pattern exists, V17 should be a **small constrained fusion** such as:

- semantics only for a predeclared subset of stable modules, or
- a global tiny semantic coefficient conditioned on a simple organizer-derived novelty feature,
- implemented inside first-stage relevance calibration rather than a post-hoc hard route.

Conditioning should be smooth, not “switch model for this user.”

## What NOT to do next

- do not increase beta above 1,
- do not jump to 32B/70B just because V16 is mixed,
- do not use the 8B model as a direct prompt-based test label generator,
- do not resurrect V13 routing with Qwen features,
- do not freely optimize 17 semantic weights on the same old folds,
- do not submit V16 primary, because it equals Consensus3,
- do not submit sem075/sem100 just because chronology is positive.

## Medium-term branch if V16 semantics prove real

Only after a frozen semantic feature shows robust gain:

1. consider supervised low-rank/contrastive adaptation using organizer train labels,
2. possibly LoRA/metric tuning with strict nested validation,
3. maintain low-dimensional smooth fusion,
4. keep Consensus3 as immutable reference,
5. use new untouched validation seeds before public submission.

## Medium-term branch if V16 semantics fail completely

If view/module/novelty diagnostics fail to find robust semantic value, conclude that the dataset is dominated by organizer-specific lexical/structured generation patterns. Then focus on:

- improved current-intent parsing,
- module-aware assessment interactions,
- prerequisite/readiness features,
- stable global calibration,
- possibly rule-derived features from organizer catalog,

rather than larger language models.
