# Open Questions

These are intentionally unresolved and should guide the next chat.

## V16

1. Why does Qwen8B semantics help chronological validation but hurt ordinary CV?
2. Which semantic view causes the effect: current, recent, profile, or interaction?
3. Is semantic benefit concentrated in a subset of modules?
4. Does Qwen help mainly when chat is novel/unseen lexically?
5. Does the chronological effect persist over multiple rolling blocks?
6. Is semantic score calibration the problem rather than semantic representation itself?

## Competition / leaderboard

7. Exact public/private leaderboard test proportion was not established in the discussion.
8. V16 semantic variants have not been submitted and should not be until promotion evidence improves.
9. The target of reaching 0.70 remains aspirational; no honest local/public candidate currently demonstrates it.

## Modeling

10. Can current-intent semantic embedding provide value if profile/history embedding is removed?
11. Can stable module-specific semantic influence be defined without overfitting 17 free weights?
12. Can organizer catalog prerequisites/readiness be encoded more directly into binary relevance without a post-hoc router?
13. If frozen 8B semantics prove stable, is supervised contrastive/LoRA adaptation worthwhile with only 4,000 labeled users?
14. Would a pretrained reranker be considered allowed under TM, or should organizer clarification be obtained first?
