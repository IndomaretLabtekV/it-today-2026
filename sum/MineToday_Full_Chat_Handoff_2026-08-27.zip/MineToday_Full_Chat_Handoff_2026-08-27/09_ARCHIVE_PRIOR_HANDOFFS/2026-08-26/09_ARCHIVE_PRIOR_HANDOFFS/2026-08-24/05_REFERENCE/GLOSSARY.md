# Glossary

## Consensus3
V12.2 public champion. Smooth per-module calibration profile over the V3.1 backbone.

## cal045
Global ~0.45 blend between sparse/base signal and binary relevance calibrator. Public-proven predecessor of Leader6/Consensus3.

## Leader6
V12 module-specific calibration profile that improved public to 0.65792.

## V9.1
Adaptive/residual expert. Locally attractive but publicly poor (0.65432). Used later only as an expert proposal source.

## V10-C
Boundary utility expert variant. Complementary in oracle analysis but globally weaker than champion.

## OOF
Out-of-fold prediction. Safe for first-level validation but **not automatically sufficient** for training/evaluating a second-level meta-model on the same fold system.

## Fully nested
Outer train/validation split where any first-stage predictions used to train a second-stage model are themselves generated through inner CV strictly inside outer train.

## Geometry mismatch
Difference between score/rank feature distributions seen during meta-model training and those seen at test inference, often caused by fold-trained vs full-data-trained first-stage models.

## Promotion gate
Predeclared rule deciding whether a candidate is allowed to become primary. V15/V16 use fail-closed behavior.

## Surgical action
V15 term for a single constrained Top-5 membership replacement rather than whole-user model replacement.

## Semantic beta
V16 strength of semantic expert influence in smooth fusion. Candidates: 0.25, 0.50, 0.75, 1.00.

## Current intent
Latest or most immediate user learning goal.

## Recent trajectory
Recent conversation context capturing short-term goal evolution.

## Profile/readiness
Broader chat + assessment representation of background and skill readiness.

## Oracle
Hypothetical perfect chooser using ground truth. Useful for measuring theoretical headroom, not evidence of learnability.

## Researcher overfitting
Overfitting caused by repeatedly inspecting the same validation results and selecting new approaches accordingly, even when each individual experiment is technically cross-validated.
