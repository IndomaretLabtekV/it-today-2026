# Artifact / Filename Catalog

No raw artifacts are included in this handoff. This file records names and roles so a future chat can identify uploaded files.

## Competition source files

- `TM MINETODAY.pdf` — Technical Meeting rules/Q&A source
- `mine-today-data-mining-competition-it-today-2026.zip` — organizer dataset package
- `template-nlp.zip` — earlier provided NLP template resource

## Project handoff previously present

- `IT_Today_MineToday_Full_Handoff_2026-08-23(1).zip`

## Early notebook

- `minetoday-v1.ipynb` — early Qwen3-Embedding-0.6B + Qwen3-Reranker-0.6B hybrid ranker

## V12.2

Known output/reference names included:

- `submission_v12_2_consensus3.csv`
- `submission_v12_2_primary.csv`
- `submission_v12_2_leader6_reference.csv`
- `submission_v12_2_cal045_reference.csv`
- `submission_v12_2_stable3.csv`
- `submission_v12_2_m15_only.csv`
- `v12_2_diagnostics.csv`
- `v12_2_second_order.csv`

## V13.1

- `MineToday_V13_1_DualExpertUtilityRouter.ipynb`
- `submission_v13_1_primary.csv`
- `submission_v13_1_dual_router.csv`
- `submission_v13_1_consensus3_reference.csv`
- `submission_v13_1_v91_expert.csv`
- `submission_v13_1_v10c_expert.csv`
- `v13_1_router_diagnostics.csv`
- `v13_1_second_order.csv`
- `v13_1_routed_test_users.csv`
- `v13_1_oof_artifacts.npz`

Important: `submission_v13_1_primary.csv` was verified to be the actual dual-router file and was submitted, producing public **0.65754**.

## V14

- `MineToday_V14_FullyNested_Top6_Pairwise.ipynb`
- `submission_v14_primary.csv`
- `submission_v14_top6_pairwise.csv`
- `submission_v14_consensus3_reference.csv`
- `v14_fold_diagnostics.csv`

V14 primary failed promotion/fell back in the generated workflow.

## V15

- `MineToday_V15_FullyNested_SurgicalUtilityRouter.ipynb`
- `submission_v15_primary.csv`
- `submission_v15_vote3_surgical.csv`
- `submission_v15_vote4_surgical.csv`
- `submission_v15_consensus3_reference.csv`
- `v15_fold_diagnostics.csv`
- `v15_threshold_diagnostics.csv`
- `v15_test_actions_vote3.csv`
- `v15_test_actions_vote4.csv`

All final V15 submission variants were effectively champion fallback due zero accepted actions.

## V16

- `MineToday_V16_Qwen8B_SemanticCalibration.ipynb`
- user-run notebook: `v16.ipynb`
- results archive: `results-v16.zip`
- `submission_v16_primary.csv`
- `submission_v16_consensus3_reference.csv`
- `submission_v16_sem025.csv`
- `submission_v16_sem050.csv`
- `submission_v16_sem075.csv`
- `submission_v16_sem100.csv`
- `v16_diagnostics.csv`
- `v16_summary.json`
- `v16_oof_artifacts.npz`
- cached embeddings for current/recent/profile/module views

Important: V16 primary is checksum-identical to its Consensus3 reference because no semantic candidate passed promotion.
