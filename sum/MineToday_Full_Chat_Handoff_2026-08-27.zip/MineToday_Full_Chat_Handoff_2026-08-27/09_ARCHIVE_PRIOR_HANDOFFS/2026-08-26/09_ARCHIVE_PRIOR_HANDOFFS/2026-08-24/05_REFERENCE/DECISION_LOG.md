# Decision Log

## Decision: calibration family is the champion family

Reason: only family with repeated positive public transfer.

Status: active.

## Decision: V12.2 Consensus3 is current public anchor

Public: **0.65856**.

Status: freeze exact path and keep reference output in every experiment.

## Decision: reject V9.1 as primary

Reason: public **0.65432** despite strong local residual evidence.

## Decision: reject V13.1 as public upgrade

Reason: submitted public **0.65754**, worse than Consensus3. Later validation audit found structural optimism.

## Decision: no more ordinary-OOF-only meta-model claims

Reason: fully nested audit is required whenever model predictions become features for another learned model.

## Decision: reject V14 pairwise branch

Reason: fully nested aggregate negative; #5/#6 boundary nearly unlearnable.

## Decision: keep V15 methodology, reject V15 candidate

Reason: zero robust actions. Fail-closed design is good; candidate adds no score.

## Decision: investigate large semantic embedding as new first-stage information

Reason: previous failures came from manipulating existing predictions rather than adding information.

## Decision: choose Qwen3-Embedding-8B over Qwen2.5-3B

Reason: dedicated embedding objective is more appropriate than generic causal LM parameter count.

## Decision: V16 is not submission-ready

Reason: all promotion gates false; ordinary CV negative; low-beta matched audit only weakly positive; chronology positive but unconfirmed.

## Decision: next work is diagnosis, not another notebook immediately

Priority:

1. V16 semantic view ablation,
2. per-module semantic value,
3. novelty stratification,
4. rolling chronological audit,
5. only then define V17.
