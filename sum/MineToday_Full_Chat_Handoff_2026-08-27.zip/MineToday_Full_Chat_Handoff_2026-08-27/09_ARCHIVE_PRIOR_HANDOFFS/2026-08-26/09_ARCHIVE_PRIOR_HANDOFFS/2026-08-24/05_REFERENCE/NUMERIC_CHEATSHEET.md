# Numeric Cheat Sheet

## Best public results

- V12.2 Consensus3: **0.65856**
- V12 Leader6: **0.65792**
- cal045: **0.65639**
- cal035: **0.65540**
- V13.1 submitted: **0.65754**
- V9.1 submitted: **0.65432**

## V13.1 local (now considered optimistic)

- champion: 0.664965966
- routed: 0.665605756
- delta: +0.000639790
- CI: [+0.000253544, +0.001049067]
- OOF routes: 139/4000
- test routes: 42/1000

## V14

- aggregate delta: **-0.000398**
- fold deltas: +0.000903, -0.001495, -0.001711, +0.000126, +0.000186
- #5/#6 reversal AUC: ~0.521

## V15

- fully nested anchor: ~0.664275
- surgical: same
- accepted OOF routes: 0
- test actions: 0

## V16

Anchors:

- ordinary: 0.66436824
- matched audit: 0.66337742
- chronological: 0.66287236

sem025:

- ordinary delta -0.000708
- audit +0.000724 (4/5; CI slightly crosses 0)
- chrono +0.001237

sem050:

- ordinary -0.000948
- audit +0.000444
- chrono +0.002191

sem075:

- ordinary -0.001605
- audit -0.000177
- chrono +0.003029

sem100:

- ordinary -0.002058
- audit -0.000993
- chrono +0.002508

## Target structure

- users: 4000 train / 1000 test
- modules: 17
- positives/user: 4/5/6
- counts: 1362 / 1285 / 1353
- relevance rank bands:
  - 1: 1.00
  - 2: .80-.90
  - 3: .65-.75
  - 4: .50-.60
  - 5: .35-.45
  - 6: .20-.30

## Oracle numbers

- perfect order same champion Top5: ~0.73817
- perfect choose/order champion Top6: ~0.78472
- broad existing whole-user expert oracle: ~0.69861
- V13.1 exact three-expert oracle: ~0.67321
- one-swap oracle: ~0.8583
- relevance-zero identification diagnostic ceiling: ~0.9362
