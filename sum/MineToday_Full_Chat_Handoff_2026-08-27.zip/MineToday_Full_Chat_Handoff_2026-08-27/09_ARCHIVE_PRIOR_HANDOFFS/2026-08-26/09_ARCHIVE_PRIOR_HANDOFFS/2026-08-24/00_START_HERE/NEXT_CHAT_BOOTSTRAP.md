# Ready-to-Paste Bootstrap for the Next Chat

Paste the text below into a new chat together with this ZIP if needed.

---

I am continuing the MineToday IT Today 2026 Data Mining Competition project. Read this handoff ZIP first and treat it as the project source of truth unless I provide newer artifacts.

Important state:

- Metric: user-level NDCG@5 over 17 modules.
- Organizer-only dataset; no external dataset.
- Open-source pretrained models are allowed per the Technical Meeting discussion, while directly asking an LLM/GenAI to produce test relevance values is prohibited.
- Best public score achieved so far: **V12.2 Consensus3 = 0.65856**.
- V13.1 looked locally strong but public fell to **0.65754**. Later analysis found second-level non-nested stacking leakage, OOF/full-fit geometry mismatch, quota routing, coarse transition evidence, and overly large whole-user expert replacement.
- V14 fully nested Top-6 pairwise reranking was negative locally.
- V15 fully nested surgical routing correctly made zero changes because no conditional action survived strict validation.
- V16 uses frozen **Qwen3-Embedding-8B 4096D** as a semantic first-stage signal. Its ordinary CV is negative, matched audit is mildly positive only at low beta, chronological validation is positive, but all promotion gates are false. V16 primary is exactly the Consensus3 fallback.
- Do not assume old “strict” V13/V13.1 scores are honest. Treat V12.2 as the most credible public anchor.
- Avoid hard user-level routing, pairwise rank5/6 surgery, generic Top-6 tournament, Borda/rank averaging, free high-dimensional blend searches, and raw target-jitter regression unless new evidence overturns the existing failures.
- Core lesson: **improve first-stage relevance information, then use smooth low-variance fusion.**

First task in the new chat: perform a deep diagnosis of V16, especially the discrepancy between ordinary random-fold degradation and chronological gains. Determine whether semantic improvement is concentrated by module, user-history regime, chat novelty, or specific semantic views (current/recent/profile). Propose the smallest trustworthy next experiment; do not make a notebook until the diagnosis justifies it.

---
