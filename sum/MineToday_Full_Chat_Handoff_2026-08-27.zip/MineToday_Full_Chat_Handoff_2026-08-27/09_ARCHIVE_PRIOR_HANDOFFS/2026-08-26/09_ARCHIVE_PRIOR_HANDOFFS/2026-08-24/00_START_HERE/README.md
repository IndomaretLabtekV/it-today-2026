# MineToday IT Today 2026 — Full Technical Handoff

Generated: **2026-08-24 13:46 WIB (UTC+7)**

This package is a continuation handoff for the MineToday IT Today 2026 Data Mining Competition work performed in the current ChatGPT project conversation.

## Purpose

The goal is that a new chat can continue the research without asking for the competition context again. This handoff records the substantive technical state of the project:

- competition rules and constraints discussed from `TM MINETODAY.pdf`,
- dataset structure and discoveries,
- target/metric behavior,
- experiment progression from the early baseline through V16,
- public leaderboard observations,
- validation mistakes and leakage diagnoses,
- what actually transferred to public LB,
- what repeatedly failed,
- oracle analyses and learnability limits,
- the current Qwen3-Embedding-8B experiment status,
- research guardrails and promotion criteria,
- recommended next analyses and experiments.

## What is intentionally NOT included

Per request, this ZIP contains **no notebooks, no raw experiment result ZIPs, no submission CSVs, and no model caches**. Filenames are documented for reference only.

This is a **technical handoff summary, not a verbatim transcript**. It is designed to preserve all substantive competition/research information needed to continue the work. Exact raw notebooks and result artifacts remain outside this handoff.

## Read order for a new chat

1. `00_START_HERE/CURRENT_STATUS.md`
2. `00_START_HERE/NEXT_CHAT_BOOTSTRAP.md`
3. `01_COMPETITION_AND_DATA/TM_RULES_AND_CONSTRAINTS.md`
4. `01_COMPETITION_AND_DATA/DATASET_AND_TARGET_FINDINGS.md`
5. `02_EXPERIMENT_HISTORY/EXPERIMENT_MASTER_TIMELINE.md`
6. `03_DEEP_DIAGNOSIS/WHY_LOCAL_FAILED_TO_TRANSFER.md`
7. `03_DEEP_DIAGNOSIS/WHAT_WORKS_VS_WHAT_FAILS.md`
8. `04_RESEARCH_DIRECTION/NEXT_STEPS.md`
9. `04_RESEARCH_DIRECTION/PROMOTION_PROTOCOL.md`

## One-line state

**Best public score in this conversation remains V12.2 Consensus3 = 0.65856. V13.1 dropped publicly to 0.65754. V14 failed locally. V15 correctly abstained. V16 Qwen3-Embedding-8B shows mixed semantic signal (chronological positive, ordinary CV negative), fails its promotion gate, and its primary submission is an exact Consensus3 fallback.**
