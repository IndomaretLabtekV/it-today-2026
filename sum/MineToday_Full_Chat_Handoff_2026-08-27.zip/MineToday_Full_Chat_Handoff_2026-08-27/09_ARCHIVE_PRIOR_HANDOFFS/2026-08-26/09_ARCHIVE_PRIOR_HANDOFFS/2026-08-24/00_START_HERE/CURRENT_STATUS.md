# Current Status

## Competition state

- Task: personalized learning-module recommendation/ranking.
- Metric: **user-level NDCG@5**.
- Train users: **4,000** (`U0001`–`U4000` style IDs in the work discussed).
- Test users: **1,000** (`U4001`–`U5000`).
- Number of modules: **17**.
- Maximum Kaggle submissions discussed from TM: **3/day**.
- Best public score achieved in this project so far: **0.65856**, from **V12.2 Consensus3**.
- V13.1 was submitted after strong local diagnostics and scored **0.65754**, a public drop of **-0.00102** versus Consensus3.

## Current trusted champion

**V12.2 Consensus3** remains the operational champion.

Consensus3 module calibration weights:

- M002 = 0.44
- M006 = 0.55
- M007 = 0.60
- M010 = 0.40
- M011 = 0.55
- M012 = 0.55
- M015 = 0.44
- M017 = 0.53
- all other modules = 0.45

Interpretation: score per module is a smooth blend between sparse/raw signal and binary-relevance calibration, with small module-specific trust corrections.

## Latest experiment: V16

V16 uses **Qwen/Qwen3-Embedding-8B** as a frozen semantic feature extractor rather than using a generative LLM to directly predict test labels.

Configuration reported by the run:

- full embedding dimension: **4096**
- supervised Matryoshka dimension: **1024**
- KNN Matryoshka dimension: **256**
- primary semantic fusion candidates: beta = 0.25 / 0.50 / 0.75 / 1.00
- organizer data only for task-specific supervision
- no generation
- no direct request for test relevance labels

V16 validation results:

| Candidate | Ordinary increment | Ordinary wins | Matched audit increment | Audit wins | Audit CI | Chronological increment | Promotion |
|---|---:|---:|---:|---:|---|---:|---|
| sem025 | -0.000708 | 1/5 | +0.000724 | 4/5 | [-0.000080, +0.001508] | +0.001237 | FAIL |
| sem050 | -0.000948 | 1/5 | +0.000444 | 3/5 | [-0.000710, +0.001583] | +0.002191 | FAIL |
| sem075 | -0.001605 | 1/5 | -0.000177 | 2/5 | [-0.001638, +0.001204] | +0.003029 | FAIL |
| sem100 | -0.002058 | 1/5 | -0.000993 | 1/5 | [-0.002695, +0.000744] | +0.002508 | FAIL |

Anchors:

- ordinary Consensus3: **0.66436824**
- matched-audit Consensus3: **0.66337742**
- chronological anchor: **0.66287236**

Deployment impact grows rapidly with semantic beta:

- sem025: 8.7% Top-5 set change, 24.0% order change, 1.4% Top-1 change
- sem050: 14.7% set, 40.2% order, 2.5% Top-1
- sem075: 21.7% set, 51.8% order, 3.5% Top-1
- sem100: 28.0% set, 61.8% order, 4.8% Top-1

### V16 decision right now

**Do not submit V16 semantic candidates yet.**

The V16 promotion gate is false for every semantic candidate. `submission_v16_primary.csv` is byte-for-byte identical to the Consensus3 reference, so submitting it would provide no new leaderboard information.

The latest V16 result is not “Qwen 8B is useless.” It says:

1. the frozen 8B semantic signal appears **distribution-dependent**,
2. a small beta (0.25) has the healthiest matched-audit behavior but still has CI crossing zero and ordinary CV is negative,
3. chronological validation is consistently positive, especially at beta 0.50–0.75,
4. larger semantic weights become increasingly disruptive and less robust,
5. the next step should be **diagnosis/ablation of the semantic signal**, not blind submission or larger beta.

## Immediate research question

Why is the 8B semantic signal positive on chronological/future-like evaluation but negative on ordinary random folds?

That is the current highest-value unresolved question.
