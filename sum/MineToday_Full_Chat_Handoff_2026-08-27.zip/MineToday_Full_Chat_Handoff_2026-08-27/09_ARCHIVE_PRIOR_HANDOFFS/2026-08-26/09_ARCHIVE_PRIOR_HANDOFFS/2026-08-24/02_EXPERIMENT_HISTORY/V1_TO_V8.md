# V1 to V8 — Early Systems and the Rise of Calibration

## V1

The early `minetoday-v1.ipynb` was a broad hybrid learning-to-rank system. It included:

- robust assessment parsing and dirty flags,
- chronological chat profiles,
- **Qwen3-Embedding-0.6B**, configured at **256 embedding dimensions**,
- **Qwen3-Reranker-0.6B** zero-shot user-module cross-encoder scores,
- word + character TF-IDF,
- repeated-chat template memory with leakage-safe leave-one-user-out features,
- LightGBM LambdaRank on ordinal ranking labels,
- Ridge diversity model,
- OOF blend-weight search.

Public score recorded: **0.63629**.

Important lesson: merely adding a pretrained Qwen encoder/reranker plus many ranking components did not make the solution competitive. The later project learned to separate **representation quality** from **target/noise structure and validation quality**.

## V2

A larger/generic multilingual pretrained semantic encoder family was explored. The project history references `gte-multilingual-base` (~305M parameters) and supervised encoder work.

Public score recorded: **0.64413**.

This was an improvement over V1, but still below the sparse + calibration family that came next.

## V3 / V3.1

V3.1 became the structural backbone used in later successful models.

Core ingredients:

- word + char TF-IDF,
- recency-tagged/current-intent text,
- template skeleton tokens rather than direct template-target lookup,
- normalized assessment tokens,
- **134 structured organizer-derived features**,
- sparse Ridge raw relevance model,
- sparse top1 model,
- per-module LightGBM binary relevance calibration.

Public sparse-only score: **0.65036**.

### cal035

Smooth blend of sparse/base signal and relevance calibration.

Public: **0.65540**.

This was one of the first major demonstrations that **binary relevance calibration** is much more valuable than increasingly complex rank post-processing.

### cal045

Increasing calibration trust to ~0.45 globally:

Public: **0.65639**.

The calibration family became the central public-proven direction.

## Borda / rank fusion

A Borda/rank-ensemble candidate looked strong locally but scored:

**0.65489 public**.

Lesson:

> high local rank-ensemble score does not necessarily transfer. Converting smooth score geometry into hard ranks discards useful margin/calibration information and can amplify OOF overfitting.

## V8 repeated/fold averaging

Repeated-seed calibration averaging and foldbag-style averaging were tested.

Recorded public results:

- repeated w60: **0.65577**
- foldbag: **0.65140**

Both were worse than cal045.

Lesson:

> variance reduction is not automatically helpful when averaging changes the cross-module score geometry that NDCG depends on.

The project therefore stopped assuming that “more seeds/models averaged” means stronger generalization.
