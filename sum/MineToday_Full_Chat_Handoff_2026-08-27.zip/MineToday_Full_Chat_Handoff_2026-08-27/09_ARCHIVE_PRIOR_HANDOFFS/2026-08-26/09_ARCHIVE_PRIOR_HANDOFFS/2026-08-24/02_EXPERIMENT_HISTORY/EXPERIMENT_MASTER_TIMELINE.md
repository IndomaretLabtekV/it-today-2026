# Experiment Master Timeline

This timeline consolidates the main versions and their lessons. Some versions had multiple internal candidates; only the decision-relevant results are listed.

## Public leaderboard history recorded in the conversation

| Experiment | Public LB | Main lesson |
|---|---:|---|
| V1 | 0.63629 | large hybrid early system, useful baseline but weak |
| V2 | 0.64413 | pretrained semantic encoder helped vs V1 but still far below sparse/calibrated family |
| V3.1 sparse | 0.65036 | sparse + structured backbone became strong |
| V3.1 cal035 | 0.65540 | binary relevance calibration gave a large public jump |
| Borda | 0.65489 | strong-looking rank ensemble failed to transfer |
| cal045 | 0.65639 | more calibration improvement transferred |
| V8 repeated w60 | 0.65577 | repeated-seed averaging did not help public |
| V8 foldbag | 0.65140 | foldbagging materially hurt |
| V9.1 adaptive | 0.65432 | residual/ordinal improvement looked good locally but collapsed public |
| V12 Leader6 | 0.65792 | module-specific calibration transferred |
| **V12.2 Consensus3** | **0.65856** | **best public score in this project** |
| V13.1 Dual Router | 0.65754 | strong local routing evidence reversed sign publicly |

V14, V15 and V16 were not considered worthwhile public submissions based on their promotion rules. V16 primary is the exact Consensus3 fallback.

## Broad progression

### Phase A — build a strong organizer-specific backbone

V1/V2 explored large semantic/ranking stacks. The project gradually learned that direct generic ranking complexity was less effective than carefully engineered organizer-specific signals.

V3.1 became the key backbone:

- word TF-IDF,
- char TF-IDF,
- recency tags,
- template/skeleton lexical features,
- cleaned assessment tokens/features,
- 134 structured organizer-derived features,
- sparse Ridge raw/top1 models,
- per-module LightGBM binary relevance calibration.

### Phase B — discover calibration as the public-transferring family

Global blend between sparse and binary relevance calibration produced the largest reliable public gains.

`cal035 -> cal045 -> Leader6 -> Consensus3`

This is the only family that repeatedly improved the public leaderboard.

### Phase C — attempt residual/ranking intelligence

V8/V9/V10/V10.1/V11 explored:

- seed averaging,
- fold averaging,
- Borda/rank fusion,
- residual learning,
- top5/top6 utility,
- boundary swaps,
- temporal effects.

Several candidates looked positive offline but failed public or failed robustness checks.

### Phase D — user-specific routing

V13/V13.1 tried to route only selected users from Consensus3 to V9.1/V10-C experts.

V13.1 local diagnostics looked extremely convincing, but public score dropped. Later audit found the validation was not fully nested at the router level and deployment geometry differed from training geometry.

### Phase E — fully nested correction experiments

V14 made pairwise Top-6 reranking honestly nested. The previously observed spectacular 0.72+ meta-ranker gains disappeared; honest V14 was negative.

V15 made a highly conservative fully nested one-swap utility router. It correctly selected zero actions.

These experiments demonstrated that the earlier conditional-correction signal was much weaker than ordinary OOF suggested.

### Phase F — add genuinely new semantic information

V16 introduced frozen **Qwen3-Embedding-8B** as a new first-stage semantic representation, intentionally avoiding post-hoc hard routing.

Result is mixed: chronological signal is positive but ordinary CV is negative. This branch is still under diagnosis, not promoted.
