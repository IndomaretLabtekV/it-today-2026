# V16 — Qwen3-Embedding-8B Semantic Relevance Expert

## Why V16 was created

After V13–V15, the project concluded that additional post-processing intelligence was not producing trustworthy gains. The new strategy became:

> introduce genuinely new first-stage information, then fuse it smoothly with the public-proven Consensus3 family.

Large pretrained semantic embedding was revisited because early Qwen usage in V1 was not an adequate test of the modern hypothesis.

## How V16 differs from V1

### V1

- Qwen3-Embedding-0.6B
- 256D embedding
- Qwen3-Reranker-0.6B zero-shot cross-encoder
- all-history/latest profiles
- LambdaRank
- Ridge diversity
- direct ranking/blend search
- many simultaneous components

### V16

- **Qwen3-Embedding-8B**
- full **4096D** frozen semantic representation
- no generative prediction
- no Qwen reranker
- current-intent / recent-trajectory / broader-profile views
- reduced supervised Matryoshka representation (1024D) where needed
- KNN representation at 256D where needed
- semantic features integrated into **binary relevance estimation**
- smooth fusion with Consensus3
- no user-level hard router
- no arbitrary rank tournament
- fold-bagged/matched inference philosophy
- explicit promotion gate

The change is therefore not “same V1 but more parameters.” It tests whether a large modern embedding space contributes orthogonal relevance signal while preserving the low-variance fusion lesson of V12.2.

## Model choice

Chosen model:

**Qwen/Qwen3-Embedding-8B**

Reasoning discussed:

- dedicated text embedding model rather than a causal LM,
- 8B parameters, substantially larger than early 0.6B/305M encoders,
- multilingual semantic representation,
- 4096D full embedding,
- more defensible under TM constraints than directly prompting a generative LLM for test labels,
- intended to fit Kaggle T4×2 via careful frozen inference rather than fine-tuning.

## User semantic views

The V16 design intentionally separates user text into several semantic states:

1. **Current intent** — latest/current learning request.
2. **Recent trajectory** — recent conversation window/context.
3. **Profile/readiness** — broader history plus organizer-provided assessment information.

Module documents are built only from organizer catalog content.

Semantic features include user-module similarity and supervised/derived signals, then feed a relevance model rather than directly becoming the submission score.

## Actual V16 run summary

Model metadata:

- model revision recorded: `1d8ad4c`
- full embedding dim: **4096**
- supervised Matryoshka dim: **1024**
- KNN Matryoshka dim: **256**

Anchors:

- ordinary Consensus3: **0.6643682396**
- matched audit Consensus3: **0.6633774249**
- chronological anchor: **0.6628723579**

### sem025

- ordinary: **0.6636599651**
- ordinary increment: **-0.0007082745**
- ordinary wins: **1/5**
- matched audit: **0.6641009748**
- audit increment: **+0.0007235499**
- audit wins: **4/5**
- audit CI: **[-0.00007967, +0.00150830]**
- chronological: **0.6641094681**
- chrono increment: **+0.0012371102**
- test Top-5 set change: 8.7%
- test Top-5 order change: 24.0%
- Top-1 change: 1.4%
- promotion: **false**

### sem050

- ordinary increment: **-0.0009478688**
- ordinary wins: 1/5
- audit increment: **+0.0004439293**
- audit wins: 3/5
- audit CI crosses zero
- chrono increment: **+0.0021910001**
- test set change: 14.7%
- test order change: 40.2%
- promotion: false

### sem075

- ordinary increment: **-0.0016046441**
- ordinary wins: 1/5
- audit increment: **-0.0001769184**
- audit wins: 2/5
- chrono increment: **+0.0030290794**
- test set change: 21.7%
- order change: 51.8%
- promotion: false

### sem100

- ordinary increment: **-0.0020580887**
- ordinary wins: 1/5
- audit increment: **-0.0009928032**
- audit wins: 1/5
- chrono increment: **+0.0025079433**
- test set change: 28.0%
- order change: 61.8%
- promotion: false

## V16 interpretation

V16 does **not** justify saying “8B is better” yet.

It also does not justify saying “8B is useless.”

The observed pattern is more specific:

- semantic information helps the chronological/future-like holdout,
- the same information hurts ordinary CV in most folds,
- matched audit at low beta shows a weak but interesting positive signal,
- stronger beta becomes less robust,
- larger beta causes much more ranking disruption,
- sem025 is the least aggressive and healthiest candidate but still fails the predetermined promotion rule.

This suggests either:

1. semantic signal is genuinely more useful for later/future-like users,
2. random folds reward organizer-template/lexical behavior that the semantic model partially washes out,
3. semantic value is concentrated in certain modules/user regimes and a global beta dilutes it,
4. some V16 semantic views are useful while others introduce noise,
5. chronology itself may have an artifact, so it cannot override negative random/matched evidence without further diagnosis.

## Submission state

`submission_v16_primary.csv` is byte-for-byte identical to `submission_v16_consensus3_reference.csv` because the promotion gate failed.

Therefore **do not submit V16 primary for information gain**. It is just the known Consensus3 prediction.
