# Why Local Validation Repeatedly Failed to Transfer

The project’s biggest methodological lesson is that “OOF improvement” is not a single concept. Several experiments looked positive locally for different reasons that did not survive deployment.

## 1. Second-level non-nested stacking leakage

This is the most important V13.1 diagnosis.

Suppose outer fold A is being evaluated. The router trains on B+C+D+E. But ordinary OOF features for user B may have been produced by a first-stage model trained on A+C+D+E. Therefore A’s labels influence the representation of B, which then trains the router evaluated on A.

Path:

```text
Outer-validation labels A
    -> first-stage model used to create B/C/D/E OOF features
    -> second-stage router training features
    -> router evaluated on A
```

The held-out fold does not enter the router training rows directly, but it enters **through the models that generated those rows**.

Correct nested design:

```text
Outer fold A

Outer train = B+C+D+E
    -> inner CV only within B+C+D+E
    -> generate inner-OOF first-stage predictions
    -> train second-stage model

Fit first-stage models on full outer train
    -> predict A
    -> apply second-stage model
    -> evaluate A once
```

V14/V15 implemented this philosophy and the large apparent conditional-correction gains mostly disappeared.

## 2. OOF training geometry vs full-fit test geometry mismatch

A second-stage model often learns tiny relationships between score margins/ranks. If train meta-features come from 80%-trained fold models but test meta-features come from a full-data model, their distributions differ.

Symptoms observed in V13.1:

- OOF route rate: 3.475%
- test route rate: 4.2%
- V10-C OOF route rate: 1.0%
- V10-C test route rate: 1.6% (+60% relative)

The router became more aggressive precisely on an expert that was globally weaker.

Future rule: **deployment representation must match validation representation**. Fold-bagged/fold-matched inference is preferable for sensitive second-stage features.

## 3. Reusing the same validation folds for research decisions

Even technically correct CV can become a development set when inspected repeatedly.

The same dataset/folds informed V8, V9, V9.1, V10, V10.1, V11, V12, V12.1, V12.2, V13, V13.1, V14, V15 and later design choices.

The research process itself selected:

- model families,
- module weights,
- route budgets,
- experts,
- thresholds,
- architectures,
- features

based on observed fold behavior.

This produces **researcher overfitting** even when each notebook says “OOF.”

Future work must use new frozen split seeds / matched audits and avoid redesigning repeatedly around the same holdout.

## 4. Conditional utility is much less stationary than marginal relevance

Module prevalence is fairly stable across contiguous user blocks.

But V15 showed that the same proposed action threshold could be:

- positive in one environment,
- negative in another,
- absent entirely in others.

Thus statements like:

> “M007 globally needs more relevance-calibrator trust”

are stable enough to transfer.

Statements like:

> “for user geometry X, replace expert A with expert B / swap module P with Q”

are far less stable.

## 5. High oracle opportunity was confused with high learnability

The project repeatedly found enormous oracle ceilings. But when a decision was trained honestly, predictive AUC often collapsed near chance at the lower Top-5 boundary.

Do not interpret oracle score as expected achievable score.

## 6. Target magnitude noise

Within-band target magnitude appears substantially stochastic. Models that learn fine ordinal residual/jitter can fit train-specific patterns that have little test value.

## 7. Public leaderboard subset variance exists but is not enough to explain V13.1

The exact public/private split proportion was not established in the discussed materials, so a model changing only a few test users can have noisy public movement.

However, diagnostics suggested that a -0.00102 public movement was unlikely under the optimistic OOF route-delta distribution alone. Public randomness might contribute, but the V13.1 design had genuine generalization problems.
