# V13.1 Postmortem — Why the Strong Local Router Dropped Publicly

## Local story

V13.1 appeared unusually strong:

- +0.000640 over Consensus3
- positive bootstrap CI
- 5/5 outer fold deltas positive
- 4/4 chronological quarter deltas positive
- second-order budget selection positive
- only ~3.5% of OOF users routed

Yet public moved:

**0.65856 -> 0.65754**

## Root causes ranked by severity

### 1. Second-stage validation not fully nested

Critical. Router training rows used first-stage OOF predictions whose producing models could have seen the eventual router-validation fold.

### 2. Meta-feature geometry mismatch at deployment

OOF score/rank geometry and test full-fit geometry differed, changing route behavior.

### 3. Transition evidence was global, not conditional on routed population

V13.1 used transition support/mean over broad training occurrences. A transition can be positive globally but negative specifically among users selected by the gate.

Concrete examples diagnosed:

- V9.1 transition with same Top1 M009 had positive global transition mean, but among actually routed OOF users its mean delta was about **-0.00612**; test still routed users with that transition.
- V10-C transition `M017 out -> M014 in` had positive global evidence but about **-0.05147** mean delta in the routed OOF subset; test still executed this action for some users.

### 4. Some test route patterns had no routed-OOF precedent

About **5/42 test routes (~12%)** corresponded to transition behavior that passed broad evidence but had not appeared among actually routed OOF examples.

This is extrapolation, not validation.

### 5. Gain concentrated in very few transition patterns

Approximately the top five transition patterns accounted for about **97% of total local net gain**.

Therefore 5/5 positive folds did not mean broad independent signal. The same few transition families could appear across folds in a highly templated dataset.

### 6. Order-only routing was already bad locally

OOF routes split into:

- membership-changing routes: strong positive average contribution
- order-only routes: slightly negative aggregate contribution

Diagnostic values discussed:

- ~68 membership-change routes, mean about **+0.03875** per routed user
- ~71 order-only routes, mean about **-0.00106**

Yet test included roughly **18 order-only** interventions out of 42 routes.

The system lacked a branch-level promotion condition requiring order-only behavior to be positive by itself.

### 7. Forced nomination quota

Gate logic selected top fractions rather than requiring absolute expected utility. Even a weak test probability distribution still produces a “top 12.5%.”

Routed gate probabilities were often only around **0.4–0.67**, not high-confidence probabilities.

### 8. Classifier target was not the true objective

The gate mainly learned probability that expert delta > 0, with weighting/transition adjustments.

But maximizing `P(delta>0)` is not the same as maximizing `E[delta NDCG]` when positive/negative magnitudes are asymmetric.

### 9. Whole-user replacement was too large an action

Evidence might concern one module transition, but routing copied all 17 expert scores.

This allows collateral changes to:

- Top1,
- internal ordering,
- unrelated module margins,
- Top5 membership beyond the evidence.

The action scope was much larger than the evidence scope.

## Why V15 matters to this postmortem

V15 fixed nearly all of the issues above:

- fully nested,
- fold-matched,
- absolute utility threshold,
- no quota,
- one surgical swap,
- no order-only routes,
- fail closed.

And V15 found **zero robust actions**.

That is strong experimental evidence that V13.1’s conditional-correction signal was substantially overstated by the previous validation setup.
