# Public vs Local Transfer — Empirical Pattern

## Public-proven family

The calibration family repeatedly transferred in the correct direction:

- sparse: 0.65036
- cal035: 0.65540
- cal045: 0.65639
- Leader6: 0.65792
- Consensus3: 0.65856

This is unusually consistent relative to every later complex branch.

## Families that looked good locally but did not transfer

- Borda/rank ensemble: public 0.65489
- V8 averaging: below cal045
- V9.1 adaptive residual: public 0.65432
- V13.1 router: local +0.00064 but public -0.00102 vs champion

## What distinguishes the successful family

### Successful calibration

- low dimensional
- smooth score adjustment
- no per-user hard decisions
- module-level stationarity
- acts on binary relevance signal
- no second-stage stacking layer
- tiny test ranking changes

### Failed complex models

- model residual behavior conditioned on individual score geometry
- hard switching/swapping
- often depend on OOF predictions of other models
- stronger sensitivity to training fraction and fold representation
- exploit fine ordering decisions that are less learnable
- larger per-user perturbation

## Important V13.1 contrast

Local predicted intervention effect for test routes was roughly positive, but actual public movement was negative. This showed that the router’s expected utility calibration was not merely noisy — it was wrong enough to reverse the leaderboard direction.

## Implication for future experiment evaluation

A new model should not be trusted just because:

- mean OOF improves,
- 5/5 folds are positive,
- bootstrap CI is positive.

Those conditions are necessary evidence, not sufficient evidence after repeated experimentation.

Future candidates should also pass:

- new frozen split seed,
- deployment-matched representation,
- chronological/future-like audit,
- low intervention size,
- stable module/user subgroup effects,
- no second-level leakage,
- preferably a mechanism similar to a family already known to transfer.
