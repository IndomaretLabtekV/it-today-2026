# What Works vs What Fails

## Repeatedly supported / promising

### 1. Sparse lexical backbone

Word + char TF-IDF remains very strong on this synthetic/template-heavy organizer dataset.

Why:

- many repeated/near-repeated messages,
- explicit course/skill terminology,
- templated phrasing,
- lexical intent can be highly predictive.

### 2. Recency/current intent

Latest messages and recency weighting repeatedly matter because user goals can shift.

### 3. Assessment/readiness features

Assessment adds a distinct notion of learner capability/readiness and can act as eligibility/gating information.

### 4. Binary relevance calibration

This is the strongest proven idea.

Public-proven progression:

`cal035 -> cal045 -> Leader6 -> Consensus3`

### 5. Small module-specific smooth corrections

Module behavior is sufficiently stationary that small per-module trust weights transfer.

### 6. Low-variance interventions

Consensus3’s changes are tiny and affect very few rankings. Small nudges near ties are much safer than replacing an entire row.

### 7. Honest abstention

V15’s zero-action result is considered a positive methodological behavior. A model should be allowed to say “no evidence to improve.”

### 8. New first-stage representation, if validated carefully

V16’s 8B semantics are not promoted, but the chronological signal suggests there may be useful orthogonal information worth diagnosing.

## Repeatedly unsupported / failed

### 1. Borda / pure rank averaging

Discarded calibrated margin information and failed public.

### 2. Repeated-seed/fold prediction averaging as a default improvement

Averaging changed cross-module geometry and hurt public.

### 3. V9-style residual/ordinal correction

Strong local story, poor public transfer.

### 4. Hard whole-user expert routing

V13.1 public failure plus later nested audit makes this a blacklisted default.

### 5. Forced route quotas

Always selecting a top fraction can create intervention when the model has no absolute confidence.

### 6. Generic Top-6 pairwise reranking

V14 negative when honestly nested.

### 7. Rank5/6 boundary surgery

Boundary learnability is near random.

### 8. Direct exact-message target prior

High template coverage does not equal stable target identity.

### 9. Raw relevance-jitter regression

Within-band values appear noisy/stochastic. Do not optimize fine target magnitude as the main objective.

### 10. Free high-dimensional calibration search

17 freely tuned weights can overfit the same reused folds. The successful calibration changes were tiny and strongly constrained.

### 11. Treating oracle gap as achievable model gain

Oracle selection often relies on decisions that available features cannot predict reliably.

## Central operating principle

> **Improve relevance estimation first. Rank second. Prefer new reliable first-stage information plus smooth fusion over smarter post-hoc correction.**
