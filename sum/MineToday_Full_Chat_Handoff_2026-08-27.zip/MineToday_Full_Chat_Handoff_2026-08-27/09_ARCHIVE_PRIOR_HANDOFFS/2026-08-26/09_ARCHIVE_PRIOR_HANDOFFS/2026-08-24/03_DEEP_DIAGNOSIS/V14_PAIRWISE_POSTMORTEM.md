# V14 Pairwise Postmortem

## Why V14 was important

Before V14, an apparent meta-pairwise Top-6 experiment reached around **0.728–0.729 local NDCG**, suggesting the 0.70 target might have been solved locally.

That result was later proven invalid due to second-level stacking contamination.

A fully isolated chronological experiment showed:

- clean champion: ~0.6625584
- clean score-only Top6 pairwise: ~0.6625230
- delta: **-0.0000355**

Therefore the spectacular 0.728 result must never be cited as a valid local score.

## Clean signal before V14

A more carefully constructed pairwise system did show positive blocks in exploratory diagnostics, with Top6 looking better than Top5/Top7. This justified building V14 fully nested.

## Actual V14 result

Overall delta:

**-0.000398**

Fold deltas:

- +0.000903
- -0.001495
- -0.001711
- +0.000126
- +0.000186

Latest chronological quarter was also negative in the final V14 diagnostics discussed.

## What caused the loss

### Membership changes were harmful

V14 changed Top-5 ordering for about **562/4000 = 14.05%** of users.

Among changed users:

- order-only changes had a small positive mean (~+0.000660 per changed user),
- Top-5 membership changes had a materially negative mean (~-0.005594).

### Rank #5/#6 swap was the biggest repeated problem

The simplest permutation `[1,2,3,4,6,5]` occurred for about **225 users**.

Average delta per such changed user:

**~ -0.005778**

Beneficial fraction was only ~25.8%, harmful ~32.4%, rest neutral.

This was not a good selector of when rank 6 actually deserved entry.

### NDCG loss concentrated around rank 3

Decomposition discussed:

- rank1: +0.000112
- rank2: +0.000030
- rank3: **-0.000730**
- rank4: +0.000309
- rank5: -0.000118

So small gains at rank4 were more than offset by expensive rank3 mistakes.

### Adjacent reversal learnability

Approximate cross-fitted AUC by adjacent rank pair:

- #1 vs #2: 0.668
- #2 vs #3: 0.614
- #3 vs #4: 0.563
- #4 vs #5: 0.530
- #5 vs #6: **0.521**

The most tempting boundary correction is almost random.

## Deployment geometry warning

V14 OOF changed much more than final test predictions. The final full-data pairwise learner became extremely conservative relative to outer-fold behavior.

This is another example of second-stage representation sensitivity.

## Decision

Do not continue generic Top-6 pairwise tournament or #5/#6 surgery without a genuinely new source of information.
