# V16 Mixed-Signal Diagnosis

V16 is the current unresolved branch.

## Observed contradiction

All semantic candidates are negative under the ordinary CV representation, but chronological validation is positive.

At low semantic weight (beta=0.25), matched audit is also mildly positive:

- ordinary: -0.000708, 1/5 wins
- matched audit: +0.000724, 4/5 wins, CI slightly crosses zero
- chronological: +0.001237

As beta increases:

- chronological gain grows initially,
- ordinary performance gets worse,
- matched audit eventually turns negative,
- test ranking changes become much larger.

## Most plausible hypotheses to investigate

### Hypothesis A — semantics generalizes better to later/future-like users

Chronological users may contain more novel paraphrases or less exact template overlap. A strong pretrained embedding can help there while sparse/template features dominate random folds.

Test this by measuring semantic gain as a function of:

- normalized chat novelty,
- fraction of messages seen in train,
- nearest lexical similarity to training chat,
- number of chat messages,
- latest-message novelty.

### Hypothesis B — one V16 view is good and another is noisy

Current intent may be useful while broad profile embedding may mix stale history into the representation.

Required ablation:

- current-only semantic features,
- recent-only,
- profile-only,
- current+recent,
- all three.

No broad hyperparameter search; use frozen candidate definitions.

### Hypothesis C — module-specific semantic benefit

A global beta assumes Qwen helps all 17 modules equally. V12.2 already proved module reliability differs.

Next diagnostic should compute per-module binary relevance AUC/logloss/rank contribution across:

- ordinary folds,
- matched audit,
- chronological block.

A future fusion should only adjust modules whose semantic effect is stable across split regimes. Avoid freely optimizing 17 independent beta values.

### Hypothesis D — semantic score scale is miscalibrated

Cosine/semantic model margins can differ by module and user-profile length. Strong beta may alter Top-5 ordering too much even if semantic rank direction is useful.

Test:

- train-only per-module standardization,
- isotonic/logistic calibration of semantic binary relevance,
- margin calibration, not direct raw cosine blending.

### Hypothesis E — chronological result itself is an artifact

The tail block may differ in target generation or user composition. Positive chronological gain cannot be treated as proof that test will improve.

Need multiple blocked/rolling chronological splits, not just one tail split.

## What V16 already rules out

- large semantic weight is not safe globally,
- frozen 8B embeddings do not automatically outperform the sparse/calibrated champion,
- model size alone is not sufficient,
- V16 should not be submitted merely because chronological delta is positive.

## Most promising V16 candidate for further diagnosis

**sem025**, because:

- smallest disruption,
- best matched audit,
- 4/5 audit wins,
- chronological positive,
- test change still materially smaller than higher beta.

But its ordinary CV is negative and CI crosses zero, so it is **not promotion-ready**.
