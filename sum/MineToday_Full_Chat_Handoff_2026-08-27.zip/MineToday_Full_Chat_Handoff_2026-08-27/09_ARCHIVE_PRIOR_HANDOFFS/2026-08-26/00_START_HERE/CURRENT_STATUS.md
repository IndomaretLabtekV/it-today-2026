# Current Status — Wajib Dibaca di Chat Baru

## Public leaderboard state

| Candidate | Public NDCG@5 | Delta vs Consensus3 |
|---|---:|---:|
| V12.2 Consensus3 | 0.65856 | baseline |
| V21 attack1 | 0.65786 | -0.00070 |
| V21.1 attack1 | 0.65869 | +0.00013 |
| V21.2 attack1 / rank-safe | 0.65776 | -0.00080 |
| V22.1 FIRSTSHOT M003+M014 | 0.65846 | -0.00010 |
| V22.2 public-decomposed 4 changes | 0.65878 | +0.00022 |
| **V22.3 U4047+U4953 only** | **0.65912** | **+0.00056** |

Top leaderboard terakhir yang disebut user:

- Top-1: **0.66083**
- Top-2: **0.66082**

Current gap:

- ke Top-1: **+0.00171** dibutuhkan
- ke Top-2: **+0.00170** dibutuhkan

## Posisi riset saat snapshot ini

Kita sudah berhenti percaya bahwa “lebih besar / lebih semantic / lebih listwise” otomatis lebih bagus. History public justru menunjukkan pola berulang:

> **Anchor yang kuat + correction kecil, low-capacity, module-aware, dan sangat selective jauh lebih transferable daripada ranker/semantic expert yang diberi kebebasan besar.**

Current PB 0.65912 berasal dari **hanya 2 ordering corrections** terhadap Consensus3:

1. **U_4047:** M009 (ML) turun di bawah M007 (EDA).
2. **U_4953:** M016 (MLOps) turun di bawah M005 (Version Control).

Keduanya punya pola yang sangat masuk akal sebagai **prerequisite-first next-step correction**:

- user menyatakan tujuan advanced,
- assessment menunjukkan readiness belum cukup,
- prerequisite/foundation module sudah dekat di ranking anchor,
- correction hanya menggeser destination satu langkah turun / prerequisite satu langkah naik.

## Yang belum diketahui

PB 0.65912 adalah gabungan U_4047 + U_4953. Belum diketahui contribution individual masing-masing karena public subset tidak diketahui.

Next clean information experiments:

1. **Consensus3 + U_4047 only**.
2. **Consensus3 + U_4953 only**.
3. Slot ketiga diputuskan setelah dua score itu: expand archetype yang menang / isolate U_4498 atau U_4876 / controlled analog candidate.

## Submission quota

Tiga slot untuk 26 Agustus 2026 sudah terpakai. Next experiments dilakukan setelah daily reset berikutnya.

## Jangan lakukan dulu

- rerun Qwen hanya demi seed lain,
- BGE / second encoder,
- global semantic blend,
- LambdaRank/full rerank,
- hard user router,
- generic #5/#6 swap,
- direct template->label lookup,
- positive-count 4/5/6 predictor,
- broad hyperparameter search di fold lama.
