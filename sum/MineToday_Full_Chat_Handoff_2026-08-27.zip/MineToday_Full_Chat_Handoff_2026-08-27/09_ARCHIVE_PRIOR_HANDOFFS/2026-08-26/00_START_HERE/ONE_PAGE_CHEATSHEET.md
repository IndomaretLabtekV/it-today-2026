# One-Page Cheatsheet

## Best scores

- V1: 0.63629
- V2: 0.64413
- V3.1 sparse: 0.65036
- cal035: 0.65540
- Borda: 0.65489
- cal045: 0.65639
- V8 repeated: 0.65577
- V8 foldbag: 0.65140
- V9.1: 0.65432
- V12 Leader6: 0.65792
- V12.2 Consensus3: 0.65856
- V13.1: 0.65754
- V18: 0.65829
- V19: 0.65791
- V21: 0.65786
- V21.1: 0.65869
- V21.2: 0.65776
- V22.1 firstshot: 0.65846
- V22.2 4-change: 0.65878
- **V22.3 2-change: 0.65912**

## Data

- Train 4000; test 1000; 17 modules.
- Chat 14,573 rows / 4,940 users.
- 117 train no-chat; 33 test no-chat.
- ~69.9% test chat rows exact-normalized match train.
- ~95.8% test users with chat punya >=1 message seen in train.
- Tapi template->target tidak deterministic.
- Set positive per train user selalu 4/5/6.
- Target bands rigid: 1.00, 0.80–0.90, 0.65–0.75, 0.50–0.60, 0.35–0.45, 0.20–0.30.
- ~3960 unique ordered positive sequences / 4000 users.

## Strongest proven ideas

- word + char TF-IDF
- current/recent intent
- structured assessment/readiness
- binary relevance calibration
- tiny per-module smooth weights
- abstention / fail-closed
- surgical corrections only

## Strongest current finding

~95.6% missed positive-module events dari Consensus3 adalah **unmentioned modules**. Explicit current-topic modules sudah sangat mudah untuk Consensus3 (sering >95% Top-5 recall). Therefore remaining headroom mostly **latent curriculum / prerequisite / next-step inference**, bukan semantic text understanding.

## Current winning archetype

- U_4047: asks prereq ML; readiness EDA/stat/ML belum tinggi -> EDA > ML.
- U_4953: asks prereq MLOps; Python/ML rendah -> Version Control > MLOps.

## Next action

1. U_4047-only public probe.
2. U_4953-only public probe.
3. Based on winner, mine similar prerequisite-first cases. Do not build a full reranker.
