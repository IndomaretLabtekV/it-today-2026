# Next Chat Bootstrap

Upload ZIP handoff ini ke chat baru lalu instruksikan assistant membaca `00_START_HERE/README.md`, `CURRENT_STATUS.md`, dan `08_HANDOFF_REFERENCE/MASTER_HANDOFF.md` terlebih dahulu.

Tujuan sekarang:

> Melanjutkan MineToday IT Today 2026 dari PB public **0.65912**, mengejar Top-1 **0.66083**, tanpa mengulang eksperimen yang sudah terbukti gagal. Fokus utama adalah mengisolasi dan menggeneralisasi **prerequisite-first / destination-vs-next-step corrections** dari U_4047 dan U_4953, tetap memakai Consensus3 sebagai anchor.

Hal yang assistant baru jangan lakukan tanpa evidence baru:

- reset modeling dari nol,
- menganggap V21 semantic branch sebagai champion,
- menganggap V21 LOCK positive sebagai validation terpercaya,
- memperbesar semantic blend,
- full LambdaRank,
- generic boundary swaps,
- hard module trust berdasarkan tiny positive probe,
- mengklaim 0.65912 pasti private-better; public 31% bisa noisy.

Baca juga `08_HANDOFF_REFERENCE/DO_NOT_REPEAT.md` dan `07_NEXT_STEPS/NEXT_DAY_3_SUBMISSION_PLAN.md`.
