# MineToday IT Today 2026 — Full Chat Handoff

**Snapshot date:** 26 Agustus 2026, setelah seluruh rangkaian eksperimen V1–V22.3 yang dibahas di chat ini.

Dokumen ini dibuat untuk memindahkan konteks proyek ke chat baru tanpa harus mengulang analisis dari nol. Ini **bukan export verbatim seluruh pesan**; ini adalah rekonstruksi/sintesis teknis yang sangat lengkap dari seluruh progress, keputusan, angka penting, hipotesis, kegagalan, research, dan next steps yang muncul di percakapan.

## Kondisi terbaru yang wajib dibaca dulu

- Kompetisi: **Mine Today — Data Mining Competition IT Today 2026**.
- Task: rekomendasi/ranking **Top-5 learning modules** untuk setiap user.
- Metric: **user-level NDCG@5**.
- Train: **4,000 users**.
- Test: **1,000 users**.
- Modules: **17**.
- Daily Kaggle limit: **3 submissions/day**.
- Public leaderboard kira-kira **31%** test; private sekitar **69%**.
- Current public PB tim: **0.65912**.
- Current Top-1 yang terakhir disebut user: **0.66083**.
- Current Top-2 yang terakhir disebut user: **0.66082**.
- Gap PB -> Top-1: **0.00171**.
- Gap PB -> Top-2: **0.00170**.
- Tiga slot 26 Agustus sudah dipakai: **0.65846 -> 0.65878 -> 0.65912**.

## Current operational truth

1. **Consensus3 / V12.2 (0.65856)** tetap baseline model paling public-proven dan paling stabil.
2. **V21.1 attack1 (0.65869)** adalah semantic-derived candidate pertama yang public-positive, tetapi gain-nya ternyata berasal dari sangat sedikit perubahan dan tidak stabil secara global.
3. **V22.3 two-change (U_4047 + U_4953) = 0.65912** sekarang PB dan menjadi clue terkuat.
4. Current best hypothesis bukan lagi “semantic model lebih besar” atau “full reranker”, melainkan **destination-vs-next-step / prerequisite-first correction** pada sangat sedikit user yang punya advanced destination tetapi readiness-nya belum memenuhi prerequisite.
5. Jangan menganggap PB 0.65912 sebagai bukti bahwa seluruh semantic family bagus. Justru hampir semua semantic/reranking intervention yang lebih luas menurunkan public score.

## Folder map

- `01_COMPETITION_AND_RULES/` — task, metric, rules, module catalog.
- `02_DATASET_AUDIT/` — seluruh temuan data, target structure, template, readiness, learnability ceiling.
- `03_EXPERIMENT_HISTORY/` — timeline V1 sampai V22.3 dan public/offline outcomes.
- `04_RESEARCH_AND_PAPERS/` — paper yang dicari/dibaca dan apakah ide paper survive di data ini.
- `05_DIAGNOSIS_AND_LESSONS/` — apa yang menaikkan, apa yang menurunkan, kenapa validation sering misleading.
- `06_CURRENT_STATE/` — exact keadaan sekarang, decomposition public, U_4047/U_4953.
- `07_NEXT_STEPS/` — eksperimen berikut, strategi 3 submissions, arah model selanjutnya.
- `08_HANDOFF_REFERENCE/` — master handoff, decision log, glossary, artifact catalog, prompt siap paste ke chat baru.
- `09_ARCHIVE_PRIOR_HANDOFFS/` — snapshot handoff lama 23/24 Agustus sebagai historical record. **Kalau ada konflik, dokumen current 26 Agustus menang.**

## Yang sengaja tidak dimasukkan

Sesuai permintaan user, ZIP ini **tidak memasukkan notebook, raw results ZIP, submission CSV, raw dataset, atau model cache**. Nama artifact penting tetap dicatat agar bisa di-upload ulang jika chat baru membutuhkan detail exact.
