# Explicit Intent vs Latent Curriculum — Most Important Dataset Finding

A deep audit mapped chat topics to modules and compared true positive modules that Consensus3 missed.

## Missed relevance mass

Roughly **95.6%** of missed positive-module events / relevance mass came from modules **not explicitly mentioned** in chat.

That is the central reason semantic models plateau.

## When module is explicitly mentioned, Consensus3 is already very strong

Representative Top-5 recall by true rank:

### True rank #1

- unmentioned: roughly 59–62%
- mentioned: ~99%
- current mention: ~99.9%

### True rank #3

- unmentioned: ~40%
- mentioned: ~92%
- current mention: ~98–99%

### True rank #5

- unmentioned: ~20–30%
- mentioned: ~83–96% depending recency slice

Interpretation:

> Expensive language models spend capacity on “what did the user say?” while the remaining error is mainly “what should the user learn next even though they did not say it?”

This re-frames the task as **latent curriculum / next-step recommendation**, not generic semantic similarity.
