# Target Structure

## Positive count

Every train user has exactly **4, 5, or 6 positive modules**:

- K=4: 1,362 users
- K=5: 1,285 users
- K=6: 1,353 users

A quick multiclass model trying to predict K from assessment + chat/topic summaries achieved roughly chance-level accuracy (~33.35% vs ~34.05% majority). Therefore K likely contains substantial latent/stochastic information and should **not** be core modeling target.

## Relevance bands

Positive relevance values occupy rigid rank bands:

- #1: exactly 1.00
- #2: 0.80–0.90
- #3: 0.65–0.75
- #4: 0.50–0.60
- #5: 0.35–0.45
- #6: 0.20–0.30

Only ~57 unique target values.

Within-band values appear quantized/noisy; endpoint frequency patterns are consistent with a continuous draw then round-to-0.01-like generator. This is inference, not organizer-confirmed.

## Sequence uniqueness

- ~3,960 unique ordered positive sequences among 4,000 users.
- ~3,146 unique positive sets.

Therefore full sequence memorization is not realistic despite repeated chat templates.

## Modeling implication

Focus on:

1. which modules belong in relevant set,
2. broad order,
3. not exact 0.83 vs 0.87 regression.
