# Chat Template / Synthetic Structure Findings

## Strong duplication

- ~7,067 exact unique raw texts among 14,573 chat rows.
- ~51.5% exact duplicate beyond first copy.
- ~56.4% normalized duplicates in one audit.
- ~69.9% test chat rows exact-normalized match a train message.
- ~95.8% test users with chat have >=1 message seen in train.

This initially suggested direct template memory could be powerful.

## But target is not deterministic from template

Repeated message/template -> target purity is weak:

- average top-1 template purity around ~0.54 for repeated templates in one audit,
- positive-set Jaccard around ~0.23,
- cross-fitted exact-message target prior had high coverage but poor standalone ranking (~0.498 OOF),
- tiny direct blend into Consensus3 degraded score.

Conclusion:

> Template identity is useful as lexical/context feature, **not** as direct label lookup.

## Recency is real

Current/latest intent repeatedly outperformed indiscriminate all-history aggregation. The same user can ask about several different courses over time. Successful sparse models include current/recent/older signals explicitly.

This is why “just embed all chat into one vector” often washes out the most useful organizer signal.
