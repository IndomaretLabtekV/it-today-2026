# Assessment, Readiness, and Prerequisite Findings

Assessment is one of the few signals orthogonal to chat semantics.

## Examples observed from train

### M001 Excel

As learner readiness rises, Excel relevance falls sharply. Example pattern from audit:

- Python score 0 -> P(M001 positive) around 50%
- Python score 4 -> around 8%

Interpretation: fundamentals for beginners.

### M016 MLOps

Opposite direction:

- ML score 0 -> P(M016) around 17%
- ML score 3 -> around 51%
- ML score 4–5 -> around 65%

This is strong prerequisite/readiness behavior.

## Module interactions

Pairwise positive correlations among modules are mostly not strong enough to justify a graph recommender as main direction. Stronger signal appears to be **stage competition**:

- beginner modules vs advanced modules,
- prerequisite vs destination,
- readiness gating.

## Critical new insight

Existing relevance models already consume raw assessment features, so simply adding “ML score” again is unlikely to break ceiling.

Potential new value comes from **explicit inductive bias**:

- prerequisite gap,
- readiness compatibility,
- destination module minus required skills,
- next-step/foundation preference when destination is premature.
