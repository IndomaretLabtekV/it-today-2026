# Dataset Schema and Counts

## Core shapes

- `train_relevance.csv`: **4000 × 18** (`user_id` + 17 targets)
- `test.csv`: **1000 × 1**
- `sample_submission.csv`: **1000 × 18**
- `user_assessments.csv`: **5000 × 2**, assessment JSON with 10 questions
- `chat_history.csv`: **14,573 rows**, **4,940 users**
- `modules_catalog.csv`: **17 modules**

Train/test IDs:

- train: approximately U_0001–U_4000
- test: U_4001–U_5000
- organizer also contains 90 unlabeled chat IDs U_5001–U_5090

Missing chat:

- 117 train users no chat
- 33 test users no chat

## Assessment dimensions

Ten self-assessment concepts:

1. Python
2. SQL
3. Statistics / probability
4. Data cleaning / EDA
5. Machine Learning
6. ML evaluation / metric selection
7. Deep Learning
8. Generative AI / LLM
9. Translating business problem -> DS/AI problem
10. Independent DS/AI research/troubleshooting

Values mostly 0–5 but dirty forms occur: integer, numeric strings, Indonesian number words, invalid/outlier values.

~251 anomalous assessment cells were observed. Robust pipeline keeps invalid flags and imputes rather than silently trusting raw values.
