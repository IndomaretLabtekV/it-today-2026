# Train/Test Shift and Stationarity

## Broad covariate shift

Adversarial train-vs-test classifiers repeatedly landed around AUC ~0.49–0.53.

V20's explicit adversarial AUC was about **0.5099**, so no meaningful broad observable shift was detected. Importance weighting was disabled.

## Module-level stationarity

Module positive prevalence was relatively stable across contiguous user blocks; median maximum deviation around ~1.2 percentage points in older audit.

This supports why **global/module calibration** transfers relatively well.

## Conditional action utility can still shift

Despite stable marginals, interventions such as:

- route user to another expert,
- swap #5/#6,
- semantic correction on a subset,

were much less stationary. This is the source of many OOF-positive/public-negative failures.

## ID leakage hypothesis

No strong evidence that user-ID blocks correspond to generator epochs. Consensus3 performance and prevalence looked reasonably stable across blocks. Do not spend effort on ID-based exploitation without new evidence.
