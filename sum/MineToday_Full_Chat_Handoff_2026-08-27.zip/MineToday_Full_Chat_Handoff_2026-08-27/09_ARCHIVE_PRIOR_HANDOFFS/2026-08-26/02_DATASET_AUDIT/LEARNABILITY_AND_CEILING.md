# Learnability, Oracle Ceiling, and Irreducible-Looking Noise

## Oracle headroom

Historical diagnostics:

- Consensus3 OOF ~0.66437 in one common ordinary OOF representation.
- Perfect ordering while keeping champion Top-5 set: roughly **0.738–0.739**.
- Perfect choose/reorder within champion Top-6: roughly **0.785**.
- Top-7 oracle roughly **0.824**.
- Correct membership has much larger theoretical headroom than order only.

But this is **oracle**, not learnable headroom.

## Why oracle is misleading

Some module targets appear weakly predictable from released features:

Approximate Consensus3 binary AUCs noted in audit:

- M004 Web Scrapping ~0.558
- M013 Prompt Engineering ~0.578
- M011 NLP ~0.634
- M008 Dashboard ~0.639
- M014 Automation ~0.657
- stronger modules: M012 ~0.817, M009 ~0.829, M016 ~0.831

Some positive modules like M004/M011/M013 were rarely recovered into Top-5 despite nontrivial prevalence.

Combined with:

- unique target sequences,
- unpredictable K=4/5/6,
- template ambiguity,
- quantized within-band jitter,

there is likely a latent/stochastic component that no model can perfectly reconstruct from released features.

## Practical rule

Do not interpret a huge oracle gap as evidence that a smarter reranker should gain huge score. The learnable residual may be tiny and concentrated in specific prerequisite regimes.
