# What Hurt Score

## Broad / free reranking

- Borda 0.65489
- V14 negative nested
- V21.2 0.65776

Reason: destroys calibrated cross-module margins and changes correct high-rank decisions.

## Whole-user expert routing

V13.1 0.65754 despite excellent-looking local validation. Conditional utility unstable; second-level leakage/geometry mismatch.

## Repeated/fold averaging as default

V8 repeated 0.65577, foldbag 0.65140. Averaging is not harmless when score geometry changes.

## Generic semantic blending

- V18 0.65829
- V19 0.65791
- V21 0.65786

The stronger/more widespread semantic branch became, the more it tended to hurt.

## Larger intervention budgets

V19 changed ~26% order and lost public. V21.2 order-only changes ~13% and still lost.

## Hard module trust from tiny probe deltas

V21.1 module trust used effects around 1e-5–1e-4; fresh LOCK later reversed sign. This is winner's curse / multiple comparisons.

## Generic #5/#6 surgery

Pair reversal AUC ~0.52. Near random.

## Exact template label propagation

Template repeat is high, target repeat is not.

## Positive-count prediction

4/5/6 count model ~= chance.

## BGE as semantic auxiliary

In V20 BGE beneficial-correction evidence AUC was around chance and diluted Qwen.
