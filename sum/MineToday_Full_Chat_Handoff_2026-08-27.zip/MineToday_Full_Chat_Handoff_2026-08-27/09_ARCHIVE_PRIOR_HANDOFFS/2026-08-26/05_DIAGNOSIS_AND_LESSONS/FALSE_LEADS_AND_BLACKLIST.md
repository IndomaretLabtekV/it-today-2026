# False Leads / Default Blacklist

These are not theoretical bans forever; they are “do not spend next experiment here without new evidence.”

- full/whole-user expert routing
- forced route quotas
- generic Top-6 pairwise reranking
- universal #5/#6 swap models
- Borda/rank-only averaging
- repeated-seed/foldbag averaging as automatic boost
- direct exact-message target lookup
- raw relevance jitter regression
- 17 freely tuned weights / broad calibration search
- BGE / second semantic expert
- larger Qwen merely for parameter count
- full LambdaRank / neural NDCG as next primary
- positive-count predictor
- train/test importance weighting absent real shift
- global semantic alpha increases
- trusting large oracle gap as achievable
- using old V21 positive LOCK as deployment evidence
