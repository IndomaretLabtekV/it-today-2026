# Corrections to Prior Hypotheses

This file records where our own earlier reasoning was wrong or incomplete.

## “V21 LOCK +0.00137 means submit” — wrong

Public V21 = 0.65786. Later we found anchor-transport mismatch. The LOCK was not faithful enough to final deployment.

## “M014 is probably the V21.1 driver” — mostly wrong

Fresh V22 M014-only LOCK was -0.000312. Public FIRSTSHOT keeping M003+M014 scored 0.65846.

## “M003+M014 explains V21.1 gain” — wrong

Public exact decomposition disproved it. Four omitted changes scored 0.65878; M003+M014 bulk was aggregate-negative.

## “Maybe stop and save last slot” — overly conservative

User pushed to use the final free experimental slot. Two-change U4047+U4953 scored **0.65912**, a meaningful new PB. This proved clean public decomposition can have high information value when candidate modifications are disjoint and deterministic.

## “Semantic branch is useless” — too strong

Not completely. It surfaced rare useful corrections, but it is **not reliable enough as a broad decision mechanism**. Treat it as candidate generator / auxiliary sensor.

## “Bigger model will solve latent modules” — unsupported

Remaining misses are overwhelmingly unmentioned. Better semantics cannot directly reconstruct hidden curriculum logic.

## “Current PB is definitely private-best” — unknown

0.65912 changes only two test users. Public subset sensitivity is extreme. For private safety, generalizable modeling evidence still matters.
