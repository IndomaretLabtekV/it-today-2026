# Validation Failure Modes — Critical

## 1. Second-level non-nested leakage

V13.1 router training features indirectly depended on models trained with outer-validation labels. The held-out user did not enter directly, but outer labels affected first-stage features of router-train rows.

Fix: fully nested inner OOF inside each outer fold.

## 2. OOF geometry vs full-fit geometry mismatch

Meta/routing models learn tiny margin relationships. OOF features from 80%-trained models and test features from full-data models can differ enough to flip actions.

## 3. ADAPT-only anchor vs full Consensus3 deployment mismatch

V21/V21.2 exposed another version of this problem: residual behavior validated around weaker isolated anchor did not transfer when pasted onto full Consensus3.

Future non-negotiable rule:

> **Train/evaluate corrections on the exact same full-Consensus3 OOF decision surface that mirrors test deployment.**

## 4. Researcher overfitting

Even technically correct CV became a de-facto development set because the same 4000 labels/folds informed many versions and design choices.

Fresh seeds are not enough if all results are repeatedly inspected and architecture adapted.

## 5. Public subset noise

Tiny interventions may touch only a handful of public users. +0.00013 can come from very few rows. Manual public decomposition is useful but dangerous for private selection.

## 6. AUC vs NDCG mismatch

V21/V21.1 semantic/relevance AUC could be stable CAL->LOCK while NDCG correction sign reversed. Good classifier ordering across users is not the same as comparing 17 modules within the same user.

## 7. Mean delta vs stability

V21.1 stable050 had higher mean CAL but only 2/4 fold wins; stable035 had smaller mean but 3/4. Candidate selection must penalize fold variance before opening lock, not only veto afterward.
