# What Repeatedly Worked

## 1. Sparse lexical backbone

Word + char TF-IDF is exceptionally strong on templated organizer text. Explicit skill/course names matter.

## 2. Current/recent intent

Latest messages should have more influence than old history.

## 3. Structured readiness

Assessment contains genuine stage/prerequisite signal, especially beginner-vs-advanced transitions.

## 4. Binary relevance calibration

Strongest public-proven progression:

`V3.1 -> cal035 -> cal045 -> Leader6 -> Consensus3`.

## 5. Tiny module-specific smooth corrections

Consensus3's success came from minuscule weights, not a second recommender.

## 6. Fail-closed / abstention

V15's zero actions was better science than forced routes. V21/V21.1 notebooks also correctly refused promotion even when user later experimented manually.

## 7. Surgical public decomposition

V22.2/V22.3 showed that isolating exact changes can be much more informative than another full training run:

- M003+M014 bulk -> 0.65846
- four exact changes -> 0.65878
- U4047+U4953 -> 0.65912

## 8. Prerequisite-first corrections

Current best observed pattern:

- advanced destination explicitly requested,
- readiness weak,
- prerequisite already near destination in anchor,
- move prerequisite above destination with only one local swap.
