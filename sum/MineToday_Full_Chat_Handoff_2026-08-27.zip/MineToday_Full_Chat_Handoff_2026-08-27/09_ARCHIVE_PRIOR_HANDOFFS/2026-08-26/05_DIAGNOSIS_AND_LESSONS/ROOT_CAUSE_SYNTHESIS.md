# Root Cause Synthesis

Why has progress been so hard despite many advanced models?

## A. Strong anchor already solves explicit text intent

Consensus3 + TF-IDF + recency already captures stated topics nearly perfectly when current/recent.

## B. Remaining errors are mostly unspoken

~95.6% of missed positive modules are not explicitly mentioned. A better embedding cannot recover information that is not directly in text.

## C. Targets contain latent/stochastic behavior

- K=4/5/6 unpredictable,
- quantized within-band jitter,
- very high sequence uniqueness,
- weakly predictable modules.

Therefore some oracle headroom is not learnable.

## D. Ranking residual is lower signal than relevance

The further down ranking, pairwise learnability collapses. Conditional user-level corrections have much weaker stationarity than module prevalence/calibration.

## E. Semantic models are redundant with anchor

QLoRA improved semantic representation, but its incremental information relative to sparse anchor was small. Broad integration mostly duplicated or overrode correct decisions.

## F. The next learnable residual appears curriculum-shaped

Public PB 0.65912 is driven by two local corrections that both match organizer prerequisite logic:

- EDA before ML for an under-ready learner,
- Version Control before MLOps for an under-ready learner.

This is the first concrete evidence that **next-step prerequisite correction** may be the residual family worth scaling.
