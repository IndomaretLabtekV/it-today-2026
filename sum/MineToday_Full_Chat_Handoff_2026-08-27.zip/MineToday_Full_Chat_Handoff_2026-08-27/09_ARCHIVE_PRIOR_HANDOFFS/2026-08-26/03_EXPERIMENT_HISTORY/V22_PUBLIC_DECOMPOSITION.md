# V22 and Public Decomposition — How PB Reached 0.65912

## V22 initial surgical hypothesis

After V21.1, most changed test rankings appeared associated with M003/M014. V22 froze module choices and applied only M014 or M003+M014 corrections with Top1 lock.

Real validation:

### M014 3.5%

- CAL +0.000051, 2/4
- LOCK **-0.000312**
- CI [-0.000819, +0.000006]

### M003+M014 3.5%

- CAL -0.000019, 2/4
- LOCK **-0.000544**

### M003+M014 5%

- CAL +0.000095, 2/4
- LOCK **-0.000231**

This rejected M014-as-driver and weakened global M003/M014 hypothesis.

---

## V22.1 exact deterministic ablation

Instead of rerunning QLoRA, actual public-tested V21.1 submission was decomposed deterministically.

`FIRSTSHOT` kept M003+M014 behavior while removing M009/M016-related public changes.

Public: **0.65846**, worse than Consensus3 0.65856.

This showed M003/M014 bulk was **not** the source of V21.1's +0.00013 gain.

---

## V22.2 — 4 exact changes

The four V21.1 changes omitted by FIRSTSHOT were isolated against Consensus3. They were:

1. **U_4047:** M007 EDA moved above M009 ML.
2. **U_4498:** M001 Excel moved above M009 ML around rank 4/5.
3. **U_4876:** M009 ML replaced/moved above M014 AI Automation at Top-5 boundary.
4. **U_4953:** M005 Version Control moved above M016 MLOps.

Public: **0.65878**.

Approximate public contribution vs Consensus3: **+0.00022**.

---

## V22.3 — 2 exact changes U_4047 + U_4953

Keep only:

- U_4047 EDA > ML
- U_4953 Version Control > MLOps

Public: **0.65912**.

Approximate contribution vs Consensus3: **+0.00056**.

Therefore, by additive public-score arithmetic (up to leaderboard rounding), the other pair U_4498 + U_4876 contributed approximately **-0.00034 combined**.

This is the strongest current clue.

## Important uncertainty

We still do **not** know whether:

- both U_4047 and U_4953 are positive,
- only one is present in public subset / carries most gain,
- one is positive and one slightly negative.

Next day single-user decomposition is mandatory before broad generalization.
