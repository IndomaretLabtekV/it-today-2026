# V21 Family — QLoRA, Calibration, and Reranking

## V21 — QLoRA Semantic Relevance Calibration

Architecture:

- exact Consensus3 anchor,
- Qwen3-Embedding-8B 4-bit QLoRA,
- last 8 attention blocks,
- LoRA rank 8, alpha 16, dropout .05,
- 1 epoch, LR 5e-5,
- dims 512/1024/4096, 1024 primary,
- recent trajectory max 3 messages,
- relevance-first objective,
- module-wise semantic-aware binary relevance calibrators,
- residual alpha candidates .035/.055,
- fail-closed.

Original real result cal035:

- CAL +0.000201, 2/4
- CAL seen +0.001322
- CAL novel -0.000283
- untouched LOCK **+0.001374**
- LOCK CI **[+0.000061, +0.002788]**
- test membership 3.2%, order 8.5%, Top1 0.3%
- notebook did not promote due CAL gate
- public after experimental submission: **0.65786**

Interpretation after public:

The positive V21 LOCK was **not deployment-faithful enough**. Residual was validated around an ADAPT-only weaker anchor, then transported to full Consensus3 test. Public result overruled optimistic LOCK interpretation.

### PEFT implementation issue and fix

Initial Kaggle run errored because `layers_to_transform/layers_pattern` did not match Qwen bare AutoModel under PEFT despite q/k/v/o projections existing.

Fix:

- inspect `named_modules()` dynamically,
- detect last transformer block indices,
- pass exact full q_proj/k_proj/v_proj/o_proj module names as `target_modules`,
- remove brittle layer-filter arguments,
- verify every requested target injected.

This fixed real Kaggle training.

---

## V21.1 — Stable-Module Bagged Calibration

Motivation: V21 representation stable, but 17 separate calibrators on only 700 CAL users were noisy.

Changes:

- fresh split,
- more CAL data,
- lower-capacity 3-seed bagged module calibrators,
- module trust mask based on semantic AUC + realized module NDCG probe,
- smaller residual candidates.

Real diagnostics:

### stable035

- CAL **+0.000439**
- **3/4 folds**
- seen +0.000639
- novel +0.000389
- test membership **0.9%**
- order **3.2%**
- Top1 **0.1%**

### stable050

- CAL +0.000717
- only 2/4 folds
- fresh LOCK **-0.000531**
- CI [-0.001309, +0.000069]

`stable035` was later submitted experimentally and scored **0.65869**, first semantic-derived public-positive result.

Important: this gain was tiny and later decomposed into only a handful of impactful user changes.

---

## V21.2 — Anchor-Initialized Semantic LambdaRank

Goal: fix cross-module comparability by ranking 17 modules within user.

Architecture:

- Consensus3 as initial score,
- shared shallow LambdaRank/NDCG@5,
- semantic features, prior-normalized log odds,
- 5-seed bagging,
- trust-region projection,
- rank-safe and rank-boundary attacks.

Real CAL:

- rank_safe **-0.000323**, 2/4
- rank_boundary +0.000361, 2/4, stability score negative
- LOCK not opened by gate

Public rank-safe: **0.65776**.

Postmortem:

- raw LambdaRank much worse than full Consensus3,
- trust region merely prevented larger damage,
- a validation mismatch was found: part of candidate quality had been judged relative to weaker ADAPT-only anchor rather than exact deployment surface,
- when diagnostics were re-projected to full Consensus3, gains disappeared/reversed.

**Conclusion:** free/shared reranking is not current path.
