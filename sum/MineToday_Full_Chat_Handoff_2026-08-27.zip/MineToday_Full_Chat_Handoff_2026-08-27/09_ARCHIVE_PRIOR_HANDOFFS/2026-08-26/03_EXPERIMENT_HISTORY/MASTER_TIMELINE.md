# Master Experiment Timeline

## Early family

| Version | Core idea | Public / status |
|---|---|---|
| V1 | hybrid Qwen0.6B + reranker + TF-IDF + LambdaRank + template memory | 0.63629 |
| V2 | larger multilingual semantic encoder | 0.64413 |
| V3.1 | word+char TF-IDF + recency + structured features + sparse Ridge | 0.65036 |
| cal035 | binary relevance calibration blend | 0.65540 |
| Borda | rank fusion | 0.65489 |
| cal045 | stronger relevance calibration | 0.65639 |
| V8 repeated | repeated-seed calibration average | 0.65577 |
| V8 foldbag | foldbag averaging | 0.65140 |
| V9.1 | residual/adaptive correction | 0.65432 |
| V12 Leader6 | small module-specific calibration | 0.65792 |
| V12.2 Consensus3 | 3 tiny calibration tweaks | **0.65856** |

## Router/ranking family

| Version | Core idea | Outcome |
|---|---|---|
| V13.1 | selective dual expert router | public **0.65754**, despite strong local |
| V14 | fully nested Top-6 pairwise ranker | negative honestly nested |
| V15 | fully nested surgical utility router | 0 actions; correct abstention |

## Large semantic family

| Version | Core idea | Outcome |
|---|---|---|
| V16 | frozen Qwen3-Embedding-8B | no candidate passed gate |
| V17 | top5-aware module semantic | small unstable gain; no promotion |
| V18 | multi-intent prototype/metric semantic | public **0.65829** |
| V19 | ordinary-first stable semantic | public **0.65791** |
| V20 | contrastive late-interaction + BGE auxiliary | failed gate; BGE diluted Qwen |
| V21 | Qwen8B QLoRA relevance-first + calibration | public **0.65786** |
| V21.1 | stable-module bagged calibration | public **0.65869** |
| V21.2 | anchor-initialized semantic LambdaRank | public **0.65776** |

## V22 public decomposition family

| Candidate | Meaning | Public |
|---|---|---:|
| V22.1 FIRSTSHOT | exact V21.1 residual stripped to M003+M014 behavior | 0.65846 |
| V22.2 4 changes | Consensus3 + four exact changes isolated from public-positive branch | 0.65878 |
| V22.3 2 changes | Consensus3 + U4047 and U4953 only | **0.65912** |

Current thesis: **fewer, prerequisite-consistent changes improved score; broad semantic/ranking corrections did not.**
