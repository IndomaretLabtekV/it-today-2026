# Public Submission Scoreboard

Scores explicitly recorded in this project/chat:

| Candidate | Score | Note |
|---|---:|---|
| V1 | 0.63629 | early hybrid |
| V2 | 0.64413 | generic semantic encoder |
| V3.1 sparse | 0.65036 | sparse backbone |
| cal035 | 0.65540 | relevance calibration |
| Borda | 0.65489 | rank fusion failed |
| cal045 | 0.65639 | stronger calibration |
| V8 repeated | 0.65577 | averaging hurt |
| V8 foldbag | 0.65140 | averaging hurt badly |
| V9.1 | 0.65432 | residual model failed transfer |
| V12 Leader6 | 0.65792 | module calibration |
| V12.2 Consensus3 | 0.65856 | long-time champion |
| V13.1 | 0.65754 | router failed |
| V18 | 0.65829 | semantic prototype |
| V19 | 0.65791 | locally strong semantic, public down |
| V21 | 0.65786 | QLoRA residual too broad |
| V21.1 | 0.65869 | tiny semantic correction, first positive |
| V21.2 | 0.65776 | LambdaRank/rank-safe failed |
| V22.1 FIRSTSHOT | 0.65846 | M003+M014 decomposition negative |
| V22.2 4-change | 0.65878 | PB at that time |
| **V22.3 2-change** | **0.65912** | **current PB** |

Latest competitor scores reported:

- Top-1 **0.66083**
- Top-2 **0.66082**

## Public interpretation rule

Public moves on 2–30 changed users are highly informative for those exact public users but can badly overfit public subset. Do not automatically select final private submission solely from tiny user-ID probes.
