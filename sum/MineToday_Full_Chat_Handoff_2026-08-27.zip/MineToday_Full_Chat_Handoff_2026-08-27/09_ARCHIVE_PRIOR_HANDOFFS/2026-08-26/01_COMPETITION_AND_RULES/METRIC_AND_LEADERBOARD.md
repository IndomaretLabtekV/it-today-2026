# Metric and Leaderboard Interpretation

## Metric

User-level **NDCG@5**.

Konsekuensi:

- membership Top-5 penting,
- order dalam Top-5 penting,
- mistake rank #1 jauh lebih mahal daripada rank bawah,
- “AUC bagus” belum tentu berarti NDCG bagus,
- 17 independent probability models belum tentu punya cross-module score scale yang benar.

## Public/private

Working assumption dari competition discussion:

- public kira-kira 31% test,
- private kira-kira 69%.

Karena test hanya 1000 users, kandidat yang mengubah 2–30 users bisa bergerak cukup besar/aneh di public tergantung apakah user tersebut ada di public subset.

## Current leaderboard

- Current PB: **0.65912**.
- Top-2: **0.66082**.
- Top-1: **0.66083**.

Do not overfit interpretation: exact manual test-user probes sangat informatif untuk public subset, tapi belum otomatis private-safe.
