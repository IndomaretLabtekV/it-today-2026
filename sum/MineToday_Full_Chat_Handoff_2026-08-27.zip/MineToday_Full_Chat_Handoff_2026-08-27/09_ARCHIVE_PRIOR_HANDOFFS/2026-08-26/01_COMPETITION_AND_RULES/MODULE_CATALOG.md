# Exact 17-Module Catalog

| ID | Module | Organizer prerequisite summary |
|---|---|---|
| M_001 | Pengolahan data dengan Ms.Excel | Pemula, semua skor 0–1 |
| M_002 | Python programming | Pemula |
| M_003 | SQL | Pemula |
| M_004 | Web Scrapping | Menengah, butuh Python |
| M_005 | Version Control | Menengah |
| M_006 | Statistik | Menengah |
| M_007 | EDA (Exploratory Data Analysis) | Menengah, butuh Python & Stat |
| M_008 | Dashboard | Menengah, butuh SQL/Excel |
| M_009 | ML (Machine Learning) | Lanjutan, butuh EDA & Stat |
| M_010 | Computer Vision | Lanjutan, butuh ML/Deep Learning |
| M_011 | Natural Language Processing | Lanjutan, butuh ML |
| M_012 | Generative AI | Lanjutan, butuh NLP |
| M_013 | Prompt Engineering | Menengah |
| M_014 | AI Automation | Menengah |
| M_015 | Pemanfaatan AI (No Code) | Pemula |
| M_016 | MLOps | Ahli, butuh ML, Python, Version Control |
| M_017 | Pengembangan karir & portofolio | Semua level |

## Important modeling consequence

Catalog prerequisite text bukan dekorasi. Dataset train menunjukkan readiness transitions yang konsisten, misalnya:

- M001 cenderung lebih relevant saat skill rendah.
- M016 semakin relevant saat ML/Python readiness tinggi.
- M009 membutuhkan EDA/stat foundation.
- M016 punya explicit prerequisite Version Control.

Current best public corrections U_4047 dan U_4953 tepat mengikuti logic prerequisite ini.
