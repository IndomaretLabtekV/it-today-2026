# Competition Overview

## Problem framing

MineToday / IT Today 2026 meminta peserta membangun **AI Course Advisor** untuk ekosistem pembelajaran Intelligo. Setiap learner punya tingkat kemampuan, minat, goal, dan perjalanan belajar berbeda. Sistem harus merekomendasikan modul yang paling relevan untuk dipelajari berikutnya.

Task praktis di Kaggle:

- untuk setiap user test,
- berikan skor 17 module,
- ranking Top-5 berdasarkan skor,
- dievaluasi dengan **NDCG@5**.

Ini lebih tepat dipandang sebagai kombinasi:

- NLP intent understanding,
- structured readiness/skill-gap inference,
- multi-label relevance estimation,
- learning-path / curriculum recommendation,
- ranking.

## Organizer files

- `chat_history.csv`
- `modules_catalog.csv`
- `user_assessments.csv`
- `train_relevance.csv`
- `test.csv`
- `sample_submission.csv`

## Current modeling interpretation

Awalnya project banyak memperlakukan task sebagai semantic recommendation. Setelah audit panjang, framing yang lebih tepat adalah:

> **Explicit intent + current goal sudah relatif mudah. Remaining hard part adalah latent curriculum: course apa yang seharusnya dipelajari berikutnya walaupun tidak disebut user.**

Ini menjelaskan kenapa assessment/prerequisite dan tiny calibration lebih transferable daripada semantic reranking agresif.
