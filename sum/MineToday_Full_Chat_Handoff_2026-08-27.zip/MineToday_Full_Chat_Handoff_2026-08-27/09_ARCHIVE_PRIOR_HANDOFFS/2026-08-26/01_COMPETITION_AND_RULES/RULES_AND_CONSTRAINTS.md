# Rules and Constraints

Berdasarkan TM/rules yang dibahas di chat:

- maksimal **3 Kaggle submissions per day**;
- akun Kaggle/email/team harus sesuai registrasi;
- tidak boleh menggunakan **external competition data**;
- boleh menggunakan lebih dari satu model ML;
- Python/R/sejenis diperbolehkan;
- pretrained open-source model diperbolehkan dalam interpretasi yang dibahas;
- LLM/Generative AI tidak boleh digunakan dengan cara langsung meminta jawaban/label test;
- coding assistant diperbolehkan;
- notebook final harus reproducible, seed dicatat, dan output perlu bisa direproduksi dalam tolerance yang ditentukan panitia;
- tidak boleh kerja sama antar tim.

## Interpretasi yang dipakai untuk Qwen

Qwen3-Embedding-8B digunakan sebagai **representation/feature extractor** dan kemudian QLoRA fine-tuning hanya memakai organizer train labels. Tidak ada prompt “beri jawaban module test user ini”. Ini dianggap berbeda dari direct test-label generation.

## Research paper/web usage

Paper eksternal dipakai untuk **method research**, bukan sebagai data training. Ini tidak menambah external examples/labels ke competition dataset.
