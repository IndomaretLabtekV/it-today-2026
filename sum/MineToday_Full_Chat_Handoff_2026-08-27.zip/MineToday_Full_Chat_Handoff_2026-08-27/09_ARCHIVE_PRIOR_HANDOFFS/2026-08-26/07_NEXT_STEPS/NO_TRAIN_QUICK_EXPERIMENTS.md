# No-Training Experiments Available

If user does not want another long T4×2 run, several deterministic experiments remain.

## Highest priority

1. U4047-only
2. U4953-only

## Secondary

3. U4498-only
4. U4876-only

These four give exact public decomposition of the four-change branch.

## Analog-rule candidate generation

Using existing data only, no model training:

- find test users whose latest/recent text contains `prasyarat`, `persyaratan`, `req`, `requirement`, etc.;
- detect an advanced destination from module topic mapping;
- check organizer prerequisite catalog;
- compare learner assessment vs prerequisite level;
- require prerequisite module already within a small anchor margin of destination;
- make at most one adjacent swap.

Before submitting an analog batch, inspect each changed row manually and keep count extremely small.

## Why this can be valuable

The best current PB was produced by only two local swaps. Information gain per submission can be higher from exact decomposition than another multi-hour training run.

## Why this is risky

Public leaderboard probing can overfit the public subset. Use no-train probes to learn a general rule, not to create hundreds of user-ID-specific hacks for final private.
