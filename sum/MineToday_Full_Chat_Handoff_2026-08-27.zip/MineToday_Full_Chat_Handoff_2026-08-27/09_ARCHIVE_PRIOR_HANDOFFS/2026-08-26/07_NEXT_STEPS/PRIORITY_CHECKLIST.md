# Priority Checklist

## Immediate

- [ ] Wait for next daily reset.
- [ ] Build exact U4047-only CSV from Consensus3 + known correction.
- [ ] Build exact U4953-only CSV.
- [ ] Submit separately.
- [ ] Record scores before changing anything else.

## After scores

- [ ] Attribute approximate public contribution per user.
- [ ] Decide whether shared prerequisite archetype is real.
- [ ] Mine analogous train/test cases.
- [ ] Quantify full-Consensus3 OOF utility for prerequisite-vs-destination swaps.
- [ ] Do not use QLoRA as final scorer unless it adds measurable incremental utility.

## Only then

- [ ] Build V23 low-capacity selective prerequisite corrector if needed.
- [ ] Fresh validation + fail-closed.
- [ ] Compare against Consensus3 and public-probe PB separately.

## Hard stop conditions

If analog/prerequisite correction cannot achieve positive deployment-aligned OOF on fresh split, stop scaling it. Do not replace it with a larger reranker just because leaderboard gap remains.
