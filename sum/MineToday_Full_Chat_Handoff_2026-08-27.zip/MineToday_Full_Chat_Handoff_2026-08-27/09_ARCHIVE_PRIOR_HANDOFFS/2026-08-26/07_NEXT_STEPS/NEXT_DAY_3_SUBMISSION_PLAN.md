# Next-Day 3-Submission Plan

Tiga submissions adalah scarce but renewable information budget.

## Slot 1 — U_4047 only

Candidate:

- exact Consensus3 for 999 users,
- only U4047 correction EDA > ML.

Purpose:

- measure whether U4047 carries most of +0.00056 pair gain.

## Slot 2 — U_4953 only

Candidate:

- exact Consensus3 for 999 users,
- only U4953 correction Version Control > MLOps.

Purpose:

- isolate second winner.

## Interpret after first two

### Case A: one user gives almost all +0.00056

Search for **same archetype** among test using no-training rule mining; slot 3 expands only that archetype.

### Case B: both roughly positive/additive

Create a small analog expansion that requires the shared prerequisite-first conditions.

### Case C: one negative and the other > pair score

Keep only true winner as current public candidate; slot 3 can test one additional analog or U4498/U4876 decomposition.

### Case D: strange/non-additive public rounding

Do not force expansion. Use slot 3 for U4498-only or U4876-only to learn more.

## Goal of day

Not merely PB hunting. The goal is to identify a **repeatable correction rule** that can scale from 1–2 public winners to ~5–15 high-precision users without retraining a full recommender.
