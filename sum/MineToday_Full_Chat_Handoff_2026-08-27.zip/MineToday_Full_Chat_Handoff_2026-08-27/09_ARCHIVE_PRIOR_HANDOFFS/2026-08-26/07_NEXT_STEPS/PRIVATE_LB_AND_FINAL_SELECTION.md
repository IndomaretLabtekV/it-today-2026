# Private Leaderboard Risk and Final Submission Selection

## Public PB is not automatically private champion

0.65912 differs from Consensus3 on only two users. If one/both are public users, public score can improve substantially while private remains identical to Consensus3. If they are private, public should not move at all, so at least some interaction with public subset exists.

## Near deadline, maintain two concepts

### General-model champion

Consensus3 / possibly V21.1 only if further evidence supports it.

### Public-probe champion

V22.3 two-change 0.65912.

Do not conflate them.

## Final private strategy later

Prefer submission that combines:

- strong general OOF/fresh-lock evidence,
- tiny intervention,
- mechanism supported by organizer data,
- public non-negative confirmation,
- not solely hand-tuned to a handful of public IDs.

If a prerequisite-first corrector later validates on train OOF/fresh holdout and also reproduces public winners, that becomes a much stronger final candidate.
