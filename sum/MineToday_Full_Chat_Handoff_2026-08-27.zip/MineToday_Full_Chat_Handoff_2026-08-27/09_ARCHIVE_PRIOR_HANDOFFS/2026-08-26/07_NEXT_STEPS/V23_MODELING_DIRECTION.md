# V23 Modeling Direction — If We Train Again

Do not build V23 until single-user decomposition is understood.

## Proposed architecture: Consensus3 Prerequisite-First Selective Corrector

### Anchor

Exact full Consensus3 OOF/test.

### Candidate actions

Very small set of local pair swaps only, e.g.:

- prerequisite vs destination,
- ranks 1–7,
- max one action per user.

Do **not** let model rank all 17 modules.

### Feature hierarchy

1. **Anchor geometry**
   - ranks,
   - score margins,
   - binary relevance probabilities,
   - p(top5),
   - disagreement between sparse/calibrated components.

2. **Structured readiness**
   - 10 assessment scores,
   - invalid flags,
   - overall beginner/advanced indicators,
   - explicit prerequisite gap.

3. **Catalog graph**
   - prerequisite module(s) derived only from organizer module catalog,
   - destination level vs learner state.

4. **Current question type**
   - prerequisite/requirements wording,
   - schedule/availability vs actual learning intent,
   - current/recent/old mention.

5. **QLoRA auxiliary**
   - semantic destination score,
   - prerequisite score,
   - semantic difference.

### Target

Not “is module relevant?” and not free ranking.

Train directly on exact OOF action utility:

- `gain_if_swap > 0`, or
- expected delta NDCG of a specific prerequisite-vs-destination swap.

### Model type

Low-capacity:

- monotonic/logistic model,
- shallow LightGBM,
- calibrated probability + abstention.

Avoid deep trees and broad hyperparameter search.

### Validation

- correction target built from exact full Consensus3 OOF,
- fully nested if model-generated features are used,
- fresh frozen split not used for architecture iteration,
- evaluate changed-user utility and overall NDCG,
- require positive folds and small intervention rate,
- rank1 changes need much stricter threshold.

### Deployment budget

Start <1–2% users. If confidence does not clearly exceed threshold, abstain.
