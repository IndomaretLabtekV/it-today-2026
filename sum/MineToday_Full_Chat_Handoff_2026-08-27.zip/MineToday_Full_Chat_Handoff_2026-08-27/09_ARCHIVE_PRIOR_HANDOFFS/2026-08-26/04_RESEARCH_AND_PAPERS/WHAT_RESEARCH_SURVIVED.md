# What the Research Actually Changed

## Ideas supported by paper + data

- **Calibration matters**, especially near Top-k.
- **Ranking objective matters**, but only if ranking residual is learnable.
- **Pairwise utility should be evaluated on actual swap NDCG**, not classifier AUC alone.
- **Abstention/selective prediction** is critical when anchor is strong.
- **Common probability scale** across labels is nontrivial.

## Ideas paper-supported but empirically rejected here

### Full LambdaRank / LambdaMART

Theoretical objective alignment was not enough. V21.2 raw ranker remained worse than Consensus3; public fell to 0.65776.

### Generic calibrated label ranking

Pairwise lower-boundary decisions are near chance; V14 failed honestly nested.

### NeuralNDCG / SmoothI

Not tested because complexity/variance not justified by dataset size or existing evidence.

## Research direction after public decomposition

The next theoretical concept worth exploring is **selective / abstaining local correction** with structured prerequisite logic, not another general ranking loss.

Potential future reading (not yet implemented):

- selective classification / risk-coverage,
- conformal selective prediction,
- monotonic pairwise models,
- learning-to-defer / abstention,
- causal-ish rule mining for curriculum prerequisites.
