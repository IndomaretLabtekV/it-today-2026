# Qwen / PEFT Technical Notes

## Model

`Qwen/Qwen3-Embedding-8B`

Why selected:

- dedicated embedding model,
- multilingual,
- full hidden representation 4096D,
- stronger than early 0.6B semantic tests,
- compatible with feature-extraction framing.

## QLoRA recipe that successfully ran on Kaggle T4×2

- 4-bit NF4
- last 8 transformer blocks
- LoRA rank 8
- alpha 16
- dropout .05
- LR 5e-5
- weight decay .01
- 1 epoch
- batch 4
- grad clip 1.0
- 512 / 1024 / 4096 semantic dimensions
- 1024 primary

## Initial PEFT failure

`get_peft_model()` raised:

> target modules q_proj/k_proj/v_proj/o_proj not found under requested layer filtering

Root cause was not absence of projections; it was brittle `layers_to_transform` / `layers_pattern` matching for the bare AutoModel structure.

## Robust fix

- inspect `base.named_modules()`;
- parse actual transformer block indices dynamically;
- select last N real blocks;
- collect exact fully-qualified q/k/v/o projection module names;
- pass them directly as `target_modules`;
- remove layer-filter arguments;
- after PEFT injection, verify all requested targets are present.

This is the implementation to reuse if QLoRA is ever rerun.

## Current strategic status of QLoRA

QLoRA is **not current decision maker**. It may remain an auxiliary sensor. Public evidence says broader semantic corrections are harmful; the best current candidate uses only two exact corrections derived from that branch.
