# Papers / Technical References Reviewed

This file distinguishes **external method research** from organizer-data findings.

## 1. Dembczyński, Waegeman, Cheng, Hüllermeier (2012)

**On label dependence and loss minimization in multi-label classification.** Machine Learning 88, 5–45. DOI: `10.1007/s10994-012-5285-8`.

Relevance to project:

- multi-label losses have different Bayes-optimal decision structures;
- ranking by relevance probabilities can be theoretically justified for some ranking objectives;
- reinforced binary relevance calibration direction.

Project caveat:

17 independent per-module classifiers can have good within-module AUC yet probabilities may not be cross-module calibrated enough for NDCG ranking. V21.1 demonstrated exactly this mismatch.

## 2. Ullah, Schultheis, Zhang, Babbar (KDD 2025)

**How Well Calibrated are Extreme Multi-label Classifiers? An Empirical Analysis.** DOI: `10.1145/3690624.3709333`.

Relevance:

- evaluates calibration specifically in extreme multi-label settings,
- motivates calibration@k / calibration near decision top-k,
- post-hoc isotonic calibration can improve probabilistic quality.

Project conclusion:

Useful conceptual warning: global AUC/calibration is not enough; top-5/boundary calibration matters. But post-hoc calibration alone did not solve our strong-anchor residual problem.

## 3. Wang, Li, Golbandi, Bendersky, Najork (CIKM 2018)

**The LambdaLoss Framework for Ranking Metric Optimization.** DOI: `10.1145/3269206.3271784`.

Relevance:

- formalizes metric-driven ranking losses,
- gives theoretical view of LambdaRank and NDCG weighting.

Project test:

V21.2 implemented shallow anchor-initialized LambdaRank. It failed CAL stability and public score (0.65776). Conclusion: correct ranking objective does not overcome limited residual learnability when Consensus3 is already strong.

## 4. Burges (Microsoft Research, overview)

**From RankNet to LambdaRank to LambdaMART: An Overview.**

Relevance: practical learning-to-rank family, pairwise/listwise ranking.

Project result: V14 pairwise and V21.2 LambdaRank both showed that broad reranking is too high-variance here.

## 5. Fürnkranz, Hüllermeier, Loza Mencía, Brinker (2008)

**Multilabel Classification via Calibrated Label Ranking.** Machine Learning 73(2), 133–153. DOI: `10.1007/s10994-008-5064-8`.

Relevance:

- explicit pairwise label comparisons,
- calibration label as zero point for relevant/nonrelevant split.

Project conclusion:

Conceptually supports within-user label comparison, but generic pairwise rank correction was near-random at #5/#6 and failed V14. Do not copy CLR mechanically.

## 6. Gao & Zhou (2011/2013 line of work)

**On the Consistency of Multi-Label Learning.**

Relevance: surrogate loss consistency differs across Hamming/ranking losses; decompositions can be inconsistent for certain objectives.

Project interpretation: reinforces caution that good binary-classification metrics do not imply good NDCG ranking.

## 7. Pobrotyn & Białobrzeski (2021)

**NeuralNDCG: Direct Optimisation of a Ranking Metric via Differentiable Relaxation of Sorting.** arXiv:2102.07831.

Project decision: not pursued. Dataset is only 4000 users × 17 items with a very strong tree/sparse anchor; adding neural differentiable sorting likely increases variance unnecessarily.

## 8. Thonet et al. (2021)

**SmoothI: Smooth Rank Indicators for Differentiable IR Metrics.** arXiv:2105.00942.

Project decision: academically relevant but not primary direction for same reason as NeuralNDCG.

## 9. Qwen3-Embedding-8B / PEFT technical references

Official model config showed:

- ~36 transformer layers,
- hidden size 4096,
- q_proj/k_proj/v_proj/o_proj module names.

PEFT documentation/issue research motivated dynamic exact-target discovery rather than brittle `layers_to_transform` filters.
