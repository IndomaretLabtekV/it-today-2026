# Open Questions

1. Which individual user drives the +0.00056 pair gain: U4047, U4953, or both?
2. Can prerequisite-first corrections be identified automatically with high precision on train OOF?
3. How many analogous test users exist without creating broad false positives?
4. Does the public winner archetype survive a fresh train lockbox when action definitions are fixed beforehand?
5. Is U4498 actually positive and U4876 strongly negative, or vice versa?
6. Should current-question-type detection distinguish “prerequisite request” from “schedule/discount/support” before interpreting topic as recommendation intent?
7. Can catalog prerequisites be encoded into monotonic utility constraints without a new high-capacity model?
8. How much private risk should be assigned to exact public user edits?
9. Near final deadline, should final submission be robust Consensus3/prerequisite model vs public-probe PB 0.65912?
10. Can we gain ~0.0017 with only 5–15 extremely precise corrections, or is top leaderboard exploiting another latent generator pattern?
