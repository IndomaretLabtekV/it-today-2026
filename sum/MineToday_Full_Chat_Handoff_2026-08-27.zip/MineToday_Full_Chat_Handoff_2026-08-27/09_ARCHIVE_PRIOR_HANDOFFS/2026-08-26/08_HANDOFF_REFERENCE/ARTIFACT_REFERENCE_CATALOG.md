# Artifact Reference Catalog — Names Only, Files Not Included

Per user request, notebooks/results are intentionally excluded from this handoff ZIP. These names identify the artifacts discussed.

## Dataset/rules

- `mine-today-data-mining-competition-it-today-2026.zip`
- `TM MINETODAY.pdf`

## Notebooks

- `MineToday_V17_Top5Aware_ModuleSemantic.ipynb`
- `MineToday_V18_MultiIntent_PrototypeMetric.ipynb`
- `MineToday_V19_OrdinaryFirst_StableSemantic.ipynb`
- `MineToday_V20_DistributionMatched_ContrastiveLateInteraction.ipynb`
- `MineToday_V21_QLoRA_SemanticRelevanceCalibration.ipynb`
- `MineToday_V21_QLoRA_SemanticRelevanceCalibration_FIXED.ipynb`
- `MineToday_V21_1_StableModuleBaggedCalibration.ipynb`
- `MineToday_V21_2_AnchorInitialized_SemanticLambdaRank.ipynb`
- `MineToday_V22_Surgical_M003_M014_Residual.ipynb`

User-run notebooks were also uploaded under shorter names such as `v21.ipynb`, `v21_1.ipynb`, `v21_2.ipynb`, `v22.ipynb`.

## Important result bundles

- `results-v17.zip`
- `results-v18.zip`
- `results-v19.zip`
- `results-v20.zip`
- `results-v21.zip`
- `results-v21_1.zip`
- `results_v21_2.zip`
- `results-v22.zip`

## Important exact submission files created late-stage

- `submission_v22_1_FIRSTSHOT.csv` -> public 0.65846
- `submission_v22_2_PUBLIC_DECOMPOSED_4CHANGES.csv` -> public 0.65878
- `submission_v22_3_LASTSHOT_2CHANGE_U4047_U4953.csv` -> public 0.65912

If next chat needs to regenerate single-user candidates, it needs the real full Consensus3 reference and/or the 2-change file uploaded again. Do not confuse smoke-test submission files containing only ~100 users with real 1000-user Kaggle artifacts.
