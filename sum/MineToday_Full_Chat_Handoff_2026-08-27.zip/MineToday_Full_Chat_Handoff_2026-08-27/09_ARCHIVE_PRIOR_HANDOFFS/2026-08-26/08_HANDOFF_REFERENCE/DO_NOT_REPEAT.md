# DO NOT REPEAT — Time-Saving Guardrails

If a new chat proposes one of these as if it were unexplored, point them here.

- “Use a larger embedding model” — already tried 8B; not main bottleneck.
- “Use a reranker / LambdaRank” — V14/V21.2 negative.
- “Use BGE-M3 hybrid” — V20 showed it diluted Qwen.
- “Use exact duplicate template labels” — high coverage, low target determinism.
- “Use #5/#6 pairwise classifier” — AUC ~0.52.
- “Route users to expert models” — V13.1 public -0.00102 and validation flaws.
- “Bag many seeds/folds” — V8 public worse; score geometry matters.
- “Tune 17 module weights freely” — high overfit risk; only tiny constrained weights transferred.
- “Predict exact relevance jitter” — within-band noise likely stochastic.
- “Predict number of positives 4/5/6” — chance-level.
- “Trust V21 positive lockbox” — public contradicted due deployment mismatch.
- “M014-only is promising” — V22 fresh LOCK strongly negative.
- “M003+M014 drives V21.1” — exact public firstshot 0.65846 disproved it.
- “Use V21.2 rank-safe because no membership change” — still public 0.65776; ordering damage matters.
