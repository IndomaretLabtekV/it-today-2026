# MASTER HANDOFF — MineToday IT Today 2026

## Executive summary

Project started with broad hybrid semantic/ranking systems and gradually discovered that the organizer dataset is synthetic/template-heavy, but target generation is not a simple template lookup. The public-proven breakthrough came from a sparse lexical backbone plus structured assessment/readiness plus **binary relevance calibration**, culminating in V12.2 Consensus3 = **0.65856**.

A long sequence of smarter second-stage systems — residual learners, user routers, pairwise rerankers, semantic prototypes, Qwen8B frozen embeddings, contrastive adapters, QLoRA, and LambdaRank — mostly failed to transfer. The central reason is that Consensus3 already handles explicit/current text intent extremely well, while the remaining target errors are mostly **unmentioned curriculum modules** influenced by learner readiness/prerequisites and partly latent/stochastic structure.

V21.1 produced the first semantic-derived public improvement to **0.65869**, but detailed public decomposition later showed that its broad M003/M014 changes were actually harmful. An exact four-change subset scored **0.65878**, and then only two changes — U_4047 EDA>ML and U_4953 VersionControl>MLOps — scored **0.65912**, the current PB.

These two winning changes share a strong mechanism: user asks about an advanced destination/prerequisite, but assessment indicates missing foundation; organizer catalog says prerequisite module should precede destination. Current best hypothesis is therefore **destination-vs-next-step / prerequisite-first correction**, with Consensus3 remaining immutable default.

## Current numbers

- PB: **0.65912**
- Top-1: **0.66083**
- Top-2: **0.66082**
- gap: ~0.00171
- 3 submissions/day
- 26 Aug slots already exhausted in snapshot

## Data

- 4000 train / 1000 test / 17 modules
- chat 14,573 rows / 4,940 users
- 117 train + 33 test no chat
- ~69.9% test chat rows normalized-exact seen in train
- ~95.8% test users-with-chat have at least one seen message
- repeated templates do not imply repeated targets
- exactly 4/5/6 positive modules per user
- rigid rank-banded relevance values
- target sequences nearly unique

## Why progress is hard

1. explicit semantic intent already nearly solved;
2. ~95.6% missed positives are unmentioned;
3. part of target appears stochastic/latent;
4. lower-rank pairwise actions are barely learnable;
5. tiny validation gains are easy to overfit over repeated research cycles;
6. public subset is small, making manual few-user changes volatile.

## Experiment conclusions

### Keep

- TF-IDF sparse backbone
- recency/current intent
- assessment/readiness
- binary relevance calibration
- tiny smooth module weights
- abstention
- local prerequisite correction

### Do not repeat by default

- full LambdaRank
- generic pairwise Top6 / #5/#6 swaps
- hard expert routing
- forced route quotas
- Borda/rank averaging
- repeated/foldbag averaging
- exact template label lookup
- global semantic blending
- BGE second semantic family
- positive-count prediction
- large Qwen just for size

## Next experiments

First next-day two slots:

1. U4047-only
2. U4953-only

Third slot decided from those scores.

Longer-term V23 only if needed: low-capacity selective prerequisite-vs-destination error corrector trained/evaluated on exact full Consensus3 OOF surface, max one local swap, strong abstention.

## Most important warning to next assistant

Do not start from “build a better recommender.” Start from:

> **Where exactly does Consensus3 confuse desired destination with the learner's actual next prerequisite?**

Everything else is already heavily explored.
