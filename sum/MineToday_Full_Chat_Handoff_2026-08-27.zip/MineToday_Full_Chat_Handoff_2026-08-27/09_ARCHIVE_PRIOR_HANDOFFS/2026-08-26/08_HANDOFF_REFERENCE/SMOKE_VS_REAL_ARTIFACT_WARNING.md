# Warning: Smoke Artifacts vs Real Kaggle Artifacts

During notebook development, local smoke tests generated files with the same or similar names as real outputs. Some root `/mnt/data` diagnostics/submissions can therefore reflect smoke-mode values, shortened test sets, or permissive gates.

Examples encountered during reinspection:

- root `submission_v21_1_consensus3_reference.csv` had only ~100 smoke users,
- real V21.1 Kaggle artifacts were under extracted/user-run result directories and had 1000 users,
- root diagnostic CSV values sometimes disagreed with user-run result ZIP because they came from smoke runs.

**Rule for next chat:**

If exact metric/file comparison matters, use the user-uploaded real result ZIP / extracted 1000-row file, not a development smoke artifact sharing the same name.

The handoff numbers in current 26-Aug docs are based on the interpreted **real user-run results/public scores**, not smoke outputs.
