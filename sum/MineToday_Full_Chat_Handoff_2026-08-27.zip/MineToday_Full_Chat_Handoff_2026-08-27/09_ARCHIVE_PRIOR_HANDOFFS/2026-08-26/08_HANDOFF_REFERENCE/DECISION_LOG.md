# Decision Log

## Major strategic pivots

1. **V1/V2 -> V3:** semantic-heavy broad hybrid lost to sparse lexical + structure.
2. **V3 -> V12:** binary relevance calibration proved the public-transfer family.
3. **V13 failure:** stop trusting selective router OOF without fully nested meta-validation.
4. **V14/V15:** honest nesting showed generic pairwise/boundary correction mostly unlearnable; allow abstention.
5. **V16:** try genuinely new first-stage semantic information, not smarter post-processing.
6. **V18/V19 public failures:** semantic validation views can still researcher-overfit.
7. **V20:** BGE rejected; task-adapted Qwen better than frozen but still weak incremental correction predictor.
8. **V21:** QLoRA representation works technically; calibration/deployment surface mismatch remains.
9. **V21.1:** tiny semantic correction public +0.00013; broad interpretation withheld.
10. **V21.2:** cross-module LambdaRank rejected after CAL/public loss.
11. **Dataset re-audit:** explicit topic already solved; remaining errors ~95.6% unmentioned -> latent curriculum framing.
12. **V22:** M014/M003 hypothesis rejected by fresh lock and public firstshot.
13. **Public decomposition:** 4 changes -> 0.65878.
14. **Final free probe:** U4047+U4953 only -> **0.65912**.
15. **Current decision:** isolate each winning user next, then generalize prerequisite-first archetype; no full retraining until that mechanism is understood.
