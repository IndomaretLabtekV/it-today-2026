# Glossary

- **Anchor:** baseline scoring/ranking kept as default, usually Consensus3.
- **Consensus3:** V12.2 calibrated sparse champion, public 0.65856.
- **Membership change:** predicted Top-5 set changes vs anchor.
- **Order change:** Top-5 order changes, even if membership same.
- **Top1 change:** first-ranked module changes; highest-risk intervention.
- **CAL:** calibration/development split used to fit/choose correction.
- **LOCK / lockbox:** held-out split opened only after candidate frozen.
- **Ordinary CV:** standard fold-based OOF validation.
- **Matched audit:** alternate validation representation intended to mimic deployment geometry.
- **Chronological:** time-ordered holdout.
- **Researcher overfitting:** architecture/threshold choices adapt repeatedly to same validation labels even if each notebook is technically OOF.
- **QLoRA:** low-rank adaptation on quantized Qwen embedding model.
- **Semantic residual:** small score correction derived from semantic-aware relevance prediction.
- **Prerequisite-first:** promote foundation module above advanced destination when readiness is insufficient.
- **Destination-vs-next-step confusion:** anchor understands what user ultimately wants but may rank destination above the course learner should actually take next.
- **Fail-closed:** if evidence/gates fail, output exact anchor rather than force intervention.
- **Public decomposition:** deterministic submission experiments that isolate a few disjoint test-user changes to infer which changes affect public score.
