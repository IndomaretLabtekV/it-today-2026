# What Is Known vs What Is Still Uncertain

## High-confidence known

- Consensus3 is a strong, stable general anchor.
- Broad semantic/reranking changes usually lower public score.
- Exact template lookup is not enough.
- Assessment/prerequisite structure is real.
- Explicit current topic is already easy for Consensus3.
- Remaining errors are mostly unmentioned modules.
- V21 original positive LOCK did not transfer public.
- M014-only V22 fresh LOCK was negative.
- M003+M014 FIRSTSHOT public was below Consensus3.
- Four exact changes improved public to 0.65878.
- U4047+U4953 pair improved public to 0.65912.

## Uncertain

- individual public contribution of U4047 vs U4953;
- whether these two corrections improve private subset;
- whether prerequisite-first archetype generalizes to enough additional test users to gain +0.0017;
- whether U4498 is positive and U4876 strongly negative, or vice versa;
- how much of target generator is truly stochastic/unreleased;
- exact optimal balance between destination and prerequisite when multiple requirements are missing.

## Dangerous assumption to avoid

Do not treat public-tested user IDs as ground truth for private. Use them to discover **mechanism**, then validate mechanism on train OOF / fresh lock where possible.
