# U_4498 and U_4876 — Negative Pair, Still Unresolved Individually

## U_4498

Chat:

- asks SQL/query from zero for career,
- A/B testing,
- ML class discount,
- latest asks SQL JOIN class for portfolio.

Assessment is extremely beginner-ish:

- Python 1
- SQL 0
- Stat 2
- EDA 1
- ML 0
- ML eval 0
- DL 0
- GenAI 0
- business->DS 0
- research 0

4-change correction moved **M001 Excel above M009 ML** near #4/#5.

This actually looks plausible under prerequisite logic, so do not conclude U4498 is negative individually. It is only known that **U4498 + U4876 combined** is negative relative to U4047+U4953 decomposition arithmetic.

## U_4876

Chat:

- ML syllabus,
- deployment model,
- CI/CD requirements,
- data cleaning syllabus,
- latest unrelated payment issue.

Assessment mostly 5s, with GenAI `Tiga` and research field invalid `99`.

4-change correction moved **M009 ML above M014 AI Automation** at Top-5 boundary while MLOps already rank #1.

This user is advanced and current learning intent may be stale because latest message is support/payment. More likely to be risky.

## Future use

If single-user U4047/U4953 probes leave a spare slot, U4498-only vs U4876-only could further decompose the negative pair. But priority is first identifying which current winning user drives 0.65912.
