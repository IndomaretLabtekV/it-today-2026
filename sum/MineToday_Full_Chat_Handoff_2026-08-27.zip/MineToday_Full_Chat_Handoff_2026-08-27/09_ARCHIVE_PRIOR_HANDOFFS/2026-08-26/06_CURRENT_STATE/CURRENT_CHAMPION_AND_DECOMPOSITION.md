# Current Champion and Exact Public Decomposition

## Models / submissions to distinguish

### Stable model champion

**Consensus3 / V12.2 = 0.65856**

Most public-validated general model.

### Best public score

**V22.3 two-change = 0.65912**

Consensus3 everywhere except two test-user ordering changes.

## Score arithmetic

- Consensus3: 0.65856
- V21.1: 0.65869
- FIRSTSHOT M003+M014: 0.65846
- 4 exact changes: 0.65878
- U4047+U4953 only: 0.65912

Approximate additive public decomposition, subject to leaderboard rounding:

- M003/M014 bulk vs Consensus3: about **-0.00010**
- 4 isolated changes: about **+0.00022**
- U4047 + U4953 pair: about **+0.00056**
- therefore U4498 + U4876 pair: about **-0.00034 combined**

## Four isolated public-change users

### U_4047

Consensus3 Top:

`M009 > M007 > M006 > ...`

Winning correction:

`M007 > M009 > M006 > ...`

### U_4498

Consensus3 around boundary:

`... M009 > M001`

4-change correction:

`... M001 > M009`

### U_4876

Consensus3 boundary:

`... M014 > M009`

4-change correction:

`... M009 > M014`

### U_4953

Consensus3:

`... M016 > M005 ...`

Winning correction:

`... M005 > M016 ...`

Only U4047+U4953 pair is known strongly positive as a pair. U4498+U4876 is negative as a pair. Individual effects unknown.
