# Current Modeling Hypothesis — Destination vs Next Step

## Problem

Consensus3 is strong at identifying **destination topics** because chat explicitly mentions them.

But recommendation target may prefer a **learning path next step** rather than the final destination.

Examples:

- wants ML -> may need EDA/stat first;
- wants MLOps -> may need Version Control/Python/ML first;
- wants CV -> may need ML/DL first;
- wants GenAI -> may need NLP/ML first.

## Proposed residual logic

Only consider a correction when all are true:

1. destination course is advanced and explicitly mentioned current/recently;
2. wording indicates prerequisite/requirements or learner readiness question;
3. assessment shows missing required skill(s);
4. prerequisite module sits near destination in Consensus3 (small margin, ranks ~1–7);
5. correction requires max one local swap;
6. no strong contradictory current intent;
7. expected NDCG utility from train analogs is positive;
8. otherwise abstain.

## Role of QLoRA

Not final scorer. Possible auxiliary confirmation only:

- destination semantic evidence,
- prerequisite-vs-destination difference,
- candidate generation.

Primary driver should be organizer catalog + assessment + current question type + anchor geometry.
