# Failure Catalog — What Failed, Why, and What Would Change the Verdict

## Broad semantic systems

### Larger generic/multilingual embedding

V2 membaik dari V1 tetapi kalah jauh dari TF-IDF. Qwen8B, BGE, dan later semantic variants tidak mengalahkan anchor.

**Why:** explicit template semantics already solved; remaining labels latent.

**Revisit only if:** ada residual slice dengan missing semantic disambiguation yang benar-benar tertulis.

### Global semantic blend

V18 `0.65829`, V19 `0.65791`, V21 `0.65786`.

**Why:** duplicated signal and excessive ranking changes.

### BGE auxiliary

V20 evidence sekitar chance dan mendilusi Qwen.

**Verdict:** jangan tambah second encoder tanpa slice-specific proof.

## Ranking and routing

### Borda/rank fusion

`0.65489`, lebih buruk dari calibrated scores.

**Why:** membuang magnitude/calibration information.

### User expert router

V13.1 `0.65754` dengan local optimism.

**Why:** second-level leakage, OOF/full-fit geometry mismatch, unstable conditional utility.

### Generic Top-6/#5-#6 pairwise

V14 nested negative; pair reversal AUC sekitar 0.52.

**Why:** lower-boundary residual near chance.

### LambdaRank/rank-safe

V21.2 `0.65776` walaupun anchor-initialized dan constrained.

**Why:** objective alignment tidak menciptakan missing signal; ordering-only damage tetap damage.

## Averaging and capacity

### Repeated seed / foldbag

V8 repeated `0.65577`; foldbag `0.65140`.

**Why:** model outputs tidak berada pada identical score geometry; averaging bukan otomatis variance reduction untuk within-user ranking.

### More seeds / deeper trees / broad tuning

Repeated inspection meningkatkan winner's curse. Tiny local improvements sering tidak transfer.

## Template and target shortcuts

### Exact template-to-label lookup

High chat repeat tetapi low target determinism.

### Predict positive count 4/5/6

Mendekati chance.

### Predict exact relevance jitter

Within-band component terlalu noisy.

## Curriculum/prerequisite rules

### Broad prerequisite-first

Raw direct prerequisite actions di V23 rata-rata sekitar `-0.01090`; q10-margin slice sekitar `-0.00658`.

**Why:** user target relevance bukan chronological curriculum order; advanced destination dapat tetap paling relevant walaupun readiness rendah.

### M014/M003 residual hypothesis

V22 fresh LOCK negatif; public FIRSTSHOT `0.65846`.

**Verdict:** M003/M014 bulk bukan source V21.1 gain.

## V23 F2LLM direct action model

Semua policies gagal gate. Conservative global effect practically zero; balanced/confirmed negatif.

**Why:** branches tidak independent, pair utility weak, action confidence uncalibrated.

## Rejected V25 joint Calibration@5 spike

Sebelum public-action distillation, sempat dirancang cross-module calibration layer.

### Bug yang ditemukan

Initial spike membentuk target Top-5 dengan cara yang salah: untuk user yang hanya mempunyai 4 positive labels, satu arbitrary zero module ikut dianggap sebagai fifth relevant. Ini memberi false validation signal.

### Setelah target diperbaiki

Fixed `C=1`, alpha `0.04` dan family terkait tidak lolos untouched LOCK. Arah tersebut ditolak dan notebook/artifact percobaan dihapus.

**Lesson:** Top-5 target construction harus respect variable number of positive labels; jangan memaksa binary fifth positive.

## Family-wide exact-template near-tie corrector

Sempat positif di CAL tetapi negatif di untouched LOCK.

**Lesson:** exact template support bukan sufficient stability guarantee. V25 karena itu tidak mendeploy rule global; hanya distill exact prior public-tested actions.

## V24 U4498 probe

Public sama `0.65912`.

**Lesson:** clean action bisa tetap uninformative pada displayed precision.

## V25 aggressive-9

Public sama dengan core-6 `0.65919`.

**Lesson:** more filtered actions did not produce visible gain. Jangan terus memperluas action set dengan threshold lebih longgar.

