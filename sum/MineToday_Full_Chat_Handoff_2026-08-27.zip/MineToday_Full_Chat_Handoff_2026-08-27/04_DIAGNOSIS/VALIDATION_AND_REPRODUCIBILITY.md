# Validation and Reproducibility

## Failure modes yang sudah ditemukan

### Second-level non-nested leakage

V13.1 meta/router features untuk training rows dipengaruhi labels outer validation melalui first-stage model. Semua learned corrections dengan model-generated features harus fully nested.

### OOF vs full-fit geometry mismatch

Tiny score margins dapat flip ketika OOF model dilatih pada 80% data tetapi test model pada 100%. Action model yang belajar OOF ranks/margins bisa menerima distribution berbeda saat deployment.

### Weaker-anchor validation mismatch

V21/V21.2 residual pernah dievaluasi pada ADAPT-only/weaker anchor lalu dipasang ke full Consensus3. Untouched LOCK yang terlihat positif tidak deployment-faithful.

### Recycled lockbox

LOCK yang dibuka dan dipakai untuk redesign bukan lockbox lagi. Ganti nama menjadi development evidence dan buat freeze baru.

### AUC vs NDCG mismatch

Per-module or action classifier AUC tidak mengukur within-user module ranking. Exact NDCG delta harus menjadi final unit of evaluation.

### Fold wins vs mean delta

Tiny positive mean dengan unstable folds mudah merupakan winner's curse. Require positive worst slice/fold atau strong risk bound, bukan average saja.

## V25 environment drift yang ditemukan

Kaggle V24 recorded:

- NumPy `2.0.2`;
- pandas `2.3.3`;
- LightGBM `4.6.0`.

Local V25 verification environment sempat memakai:

- NumPy `2.5.2`;
- pandas `3.0.5`;
- LightGBM `4.7.0`, kemudian dipin kembali ke `4.6.0`.

Walaupun LightGBM sudah dipin, NumPy/scikit-learn differences mengubah sparse Ridge/base geometry. Pada local full run hanya 4 dari 6 core actions masih membutuhkan swap; frozen V24 margins bergeser.

## Mitigasi yang dilakukan

- LightGBM V25 dipin `4.6.0`.
- Promotion function dibuat idempotent: jika target module sudah di atas, jangan membaliknya kembali.
- Frozen full V24 margins dicatat sebagai selection evidence.
- Canonical submissions dibangun dari exact V24 Consensus3 reference.
- Contract memastikan canonical core mengubah tepat 8 users/16 cells dan aggressive mengubah 11/22.
- Local drift outputs dipisahkan dari canonical results.

## Mitigasi yang masih diperlukan sebelum notebook final submission

1. Catat `numpy`, `pandas`, `scipy`, `sklearn`, dan `lightgbm` versions di notebook.
2. Pin atau reproduce Kaggle image yang dipakai V24.
3. Jalankan notebook from scratch di Kaggle.
4. Compare output file hashes/rankings dengan submitted canonical CSV.
5. Jika tidak identical, pastikan leaderboard score difference tetap dalam toleransi panitia `0.001`, tetapi idealnya exact.
6. Simpan executed notebook yang menghasilkan file submission final.

## Minimal promotion protocol selanjutnya

- exact same anchor surface;
- untouched split not used in design;
- action budget fixed before opening lock;
- per-user exact delta audit;
- no novel Top-1 unless exceptional evidence;
- public submission answers one identifiable question;
- private candidate chosen for robustness, not public-only microfit.

