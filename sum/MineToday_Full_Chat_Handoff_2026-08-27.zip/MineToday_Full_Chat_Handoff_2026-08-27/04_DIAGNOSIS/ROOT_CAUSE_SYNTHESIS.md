# Root Cause Synthesis

## Mengapa gap terakhir sangat sulit

### 1. Anchor sudah menyelesaikan explicit intent

Word/char TF-IDF, recency tags, template tokens, dan assessment membuat Consensus3 sangat kuat pada apa yang benar-benar ditulis user.

### 2. Remaining targets mostly tidak disebut

Sekitar 95.6% missed-positive events adalah modul unmentioned. Semantic encoder lebih besar tidak menambah observable information yang tidak ada di text.

### 3. Target generator mempunyai latent/noisy component

- jumlah positives 4/5/6 sulit diprediksi;
- ordered relevance sequence hampir unik;
- relevance bands mempunyai jitter;
- same chat skeleton bisa menghasilkan label set berbeda.

### 4. Residual action utility jauh lebih lemah dari relevance

Model dapat belajar “apakah M009 sering relevan?” lebih mudah daripada “untuk user ini apakah M007 harus tepat satu posisi di atas M009 di Top-5?”. Yang kedua membutuhkan within-user cross-module calibration dan exact utility estimation.

### 5. Repeated research menyebabkan researcher overfit

Fold yang sama, OOF artifacts yang sama, dan public probes berulang membuat banyak design decisions secara tidak langsung menyesuaikan noise.

### 6. Public subset sangat sparse untuk few-user actions

Jika hanya 1–11 users berubah, displayed score bisa ditentukan oleh sangat sedikit public users. Gain public belum tentu private-transferable.

### 7. Broad models menghapus calibration yang sudah benar

Reranking, semantic blend, dan routing mengubah banyak correct decisions demi sedikit residual headroom. Damage sering lebih besar daripada potential gain.

## Mengapa V25 hanya naik 0.00007

Core-6 dipilih dengan evidence yang lebih kuat daripada remaining V21.1 actions, tetapi filter tersebut masih proxy:

- pair label difference pada train analogues bukan exact NDCG action utility;
- skeleton groups menghapus topic details;
- public membership tidak diketahui;
- positive action bisa mempunyai NDCG magnitude kecil;
- negative and positive users dapat saling cancel.

Hasil `0.65919` mendukung bahwa set tidak catastrophic dan mungkin memuat positive users, tetapi tidak membuktikan rule family sudah solved.

## Current bottleneck

Bottleneck bukan training capacity. Bottleneck adalah **identification**: menemukan beberapa test-user actions yang benar, dengan evidence yang tidak berasal dari recycled fold/public noise.

