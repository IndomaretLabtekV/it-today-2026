# Public vs Private Interpretation

## How Kaggle subset scoring changes inference

Public leaderboard uses an unknown subset of test rows. Private leaderboard uses the remaining hidden subset or a different partition. For a submission that changes only a few users, public movement depends entirely on whether those users are public and whether the swaps change their NDCG.

## V24 equality

`PB = 0.65912` dan `PB + U4498 = 0.65912`.

Possible explanations:

1. U4498 not in public subset.
2. M001 and M009 have equal relevance for U4498.
3. Swap produces exact zero NDCG change for another ranking reason.
4. Nonzero change rounds to the same five displayed decimals.

Karena hanya satu user berubah, cancellation dengan user lain tidak berlaku untuk incremental U4498 effect.

## V25 core gain

`PB + core6 = 0.65919`, displayed `+0.00007`.

Possible internal compositions:

- satu public core action positif dan lainnya private/zero;
- beberapa positives dan negatives yang net positive;
- multiple tiny positives;
- rounding around true score.

Tidak boleh menyebut keenam action “validated positive”. Yang tervalidasi hanya **combined displayed effect**.

## V25 relaxed equality

`core6 = 0.65919` dan `core6 + relaxed3 = 0.65919`.

Possible explanations:

- ketiganya private;
- public but zero relevance/tie;
- positive and negative effects cancel;
- net magnitude below display resolution.

## Private-selection implication

- Public-positive few-user actions mempunyai overfit risk tinggi.
- Public-zero actions bukan automatically private-positive.
- Untuk final private submission, PB/core family harus dibandingkan berdasarkan structural plausibility, honest OOF evidence, intervention size, dan reproducibility.
- Conservative core-6 is a more defensible final candidate than relaxed-9 because relaxed additions gave no visible evidence and use looser gates.

## Information gain strategy

Jika daily slots reset dan tujuan masih development:

- ablate core actions in balanced groups, bukan one-by-one tanpa plan;
- pilih groups yang membedakan template/pair hypotheses;
- jangan menghabiskan slot untuk submission yang secara algebra tidak bisa beat current PB kecuali informasi tersebut menentukan private choice.

