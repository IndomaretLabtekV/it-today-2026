# Embedding Research — What Was Tried and Why It Stalled

## Core question

Apakah embedding yang lebih baik dapat mengejar gap leaderboard?

Jawaban empiris sementara: **tidak sebagai global replacement/blend**. Consensus3 sudah menangkap explicit intent; remaining errors mostly unmentioned. Better text embedding tidak bisa mengobservasi latent target generator secara langsung.

## Experiment ledger

| Family | Usage | Outcome |
|---|---|---|
| Early Qwen 0.6B | hybrid semantic/rerank | V1 0.63629 |
| Larger multilingual encoder | broad semantic | V2 0.64413 |
| Qwen3-Embedding-8B frozen | first-stage semantic | V16 no candidate passed |
| Multi-intent prototype | local semantic metric | V18 0.65829 |
| Ordinary-first semantic | stable semantic branch | V19 0.65791 |
| BGE auxiliary | second encoder/contrastive | V20 failed; diluted Qwen |
| Qwen8B QLoRA | task-adapted relevance | V21 0.65786 |
| Stable Qwen calibration | tiny action family | V21.1 0.65869 |
| Semantic LambdaRank | cross-module ranking | V21.2 0.65776 |
| F2LLM-v2-4B | frozen direct action features | V23 all promotion gates failed |
| SEA-Embedding | researched, not deployed | no task-specific evidence |

## Repeating failure modes

1. **Redundancy:** word/char TF-IDF already handles templates, typos, and explicit course names.
2. **Long-history averaging:** old intents blur current request.
3. **Cross-module calibration:** cosine/retrieval scores are not automatically comparable as relevance scores among 17 modules.
4. **Residual signal scarcity:** semantic branch must improve only rows the strong anchor gets wrong.
5. **Unmentioned targets:** no encoder can recover hidden curriculum labels purely from absent text.
6. **Over-intervention:** semantic confidence often moves too many already-correct rankings.
7. **Validation mismatch:** good embedding diagnostics or AUC do not imply positive swap NDCG.

## What might still justify another embedding

Hanya lanjut jika ada concrete residual slice yang:

- anchor consistently salah;
- text actually contains missing disambiguating information;
- old embeddings fail on that slice;
- new encoder improves exact action utility on untouched/deployment-matched validation;
- final intervention remains tiny.

Tanpa lima syarat itu, embedding baru adalah repeated experiment, bukan fresh direction.

## Current recommendation

Jangan habiskan compute T4x2 untuk seed/model embedding lain. Gunakan compute hanya jika menghasilkan new observable signal: exact environment reproduction, independent validation split, action-level uncertainty, atau structural modeling yang tidak mengubah ranking luas.

