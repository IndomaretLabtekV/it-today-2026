# What Research Survived

## Tetap dipakai

- Per-module binary relevance calibration.
- Top-k/boundary-aware diagnostics.
- Actual swap NDCG as action target/evaluation.
- Selective prediction and abstention.
- Separate latest/recent/profile representations.
- Hard negative diagnostics.
- Catalog prerequisite graph as structured context.
- Constrained score geometry and exact score swaps.
- Public action decomposition.

## Rejected untuk current deployment

- Full LambdaRank/LambdaMART replacement.
- Generic calibrated label ranking.
- NeuralNDCG/SmoothI complexity.
- Second large embedding as global blend.
- Direct prerequisite enforcement.
- Whole-user semantic expert router.
- Forced action quotas.

## Belum selesai diteliti

- Risk-coverage calibration khusus action swaps.
- Conformal/selective action prediction.
- Monotonic model untuk narrow destination-vs-foundation pairs.
- Hierarchical Bayesian shrinkage untuk template/pair evidence.
- Public/private robust selection under few-user interventions.
- Exact environment pinning and score reproducibility.

## Most promising framing

Jangan belajar ranking baru. Belajar **kapan harus tidak menyentuh anchor**, lalu hanya mengoreksi local pair jika evidence dari score geometry, structured readiness, dan historical action family konsisten.

