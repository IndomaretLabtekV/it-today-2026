# Methods and Papers Reviewed

Dokumen ini memisahkan **research inspiration** dari **empirical evidence pada MineToday**. Paper yang mendukung suatu metode tidak berarti metode tersebut otomatis cocok untuk dataset ini.

## Multi-label relevance and calibration

### Dembczyński et al. (2012)

*On label dependence and loss minimization in multi-label classification*, Machine Learning 88. DOI `10.1007/s10994-012-5285-8`.

Kontribusi ke proyek: mendukung reasoning bahwa different multi-label losses mempunyai optimal decision structure berbeda, dan binary relevance probabilities bisa relevan untuk ranking. Empirical outcome: per-module binary calibration memang keluarga paling public-successful, tetapi cross-module comparability tetap sulit.

### Ullah et al. (KDD 2025)

*How Well Calibrated are Extreme Multi-label Classifiers? An Empirical Analysis.* DOI `10.1145/3690624.3709333`.

Kontribusi: calibration@k dan top-k decision region lebih penting daripada global AUC. Project outcome: global probability quality tidak cukup; tiny top-5 margins masih mudah berubah.

### Fürnkranz et al. (2008)

*Multilabel Classification via Calibrated Label Ranking.* DOI `10.1007/s10994-008-5064-8`.

Kontribusi: pairwise label comparison dan calibration label. Project outcome: generic pairwise lower-boundary model gagal pada V14, AUC sekitar 0.52.

### Gao and Zhou consistency line

Surrogate consistency berbeda untuk Hamming dan ranking losses. Project interpretation: module AUC yang baik tidak menjamin NDCG action utility yang baik.

## Learning to rank and NDCG

### Wang et al. (CIKM 2018)

*The LambdaLoss Framework for Ranking Metric Optimization.* DOI `10.1145/3269206.3271784`.

Project test: V21.2 shallow anchor-initialized LambdaRank. Gagal CAL stability dan public `0.65776`.

### Burges — RankNet to LambdaRank/LambdaMART

Memberi foundation untuk pairwise/listwise ranking. Project result: V14 dan V21.2 menunjukkan broad reranking terlalu high-variance di atas strong anchor.

### NeuralNDCG — Pobrotyn and Białobrzeski (2021)

arXiv `2102.07831`. Direct differentiable ranking metric optimization. Tidak diterapkan karena hanya 4,000 users × 17 items dan existing evidence menunjukkan variance, bukan lack of objective sophistication, sebagai bottleneck.

### SmoothI — Thonet et al. (2021)

arXiv `2105.00942`. Tidak diterapkan untuk alasan yang sama.

## Selective prediction

### SelectiveNet — Geifman and El-Yaniv (ICML 2019)

PMLR `v97/geifman19a`. Ide yang dipertahankan: model boleh abstain jika estimated action risk tinggi. V15 dan V23 fail-closed behavior konsisten dengan prinsip ini.

## Course recommendation and prerequisites

### MOOCCube course recommendation

arXiv `1812.10078`. Goal-aware/course relation modeling relevan secara konsep, tetapi MineToday broad course-graph promotion belum berhasil.

### Prerequisite relation learning

ACL Anthology `P17-1133`. Mendukung eksplorasi prerequisite structure. Project evidence: graph organizer useful sebagai feature/candidate generator, tetapi raw prerequisite-first swaps negatif.

## Embedding research

### Qwen3-Embedding-8B

Dicoba frozen dan QLoRA. Dynamic PEFT target discovery dibutuhkan karena brittle layer filters gagal pada bare AutoModel. Representation teknis berhasil, public residual integration tetap negatif/kecil.

### NV-Embed / ICLR 2025

Ide hard-negative emphasis dipakai dalam V23; bukan dipakai sebagai drop-in ranker.

### ColBERT-style late interaction

Menginspirasi separation latest/trajectory/readiness views, bukan single averaged history embedding.

### F2LLM-v2-4B

*Inclusive, Performant, and Efficient Embeddings for a Multilingual World*, arXiv `2603.19223`. Dipakai frozen di V23. Model open source dan bukan direct label generator. Action utility gate tetap gagal.

### SEA-Embedding

arXiv `2606.03027`, 600M encoder untuk Southeast Asian languages termasuk Indonesian. Ditinjau untuk V24, tetapi tidak diterapkan karena generic retrieval quality belum terbukti memberi incremental NDCG utility di atas Consensus3.

## Kesimpulan research

Research paling berguna bukan memberi “next bigger model”, tetapi membangun guardrails:

- optimize/evaluate exact action utility;
- calibrate near top-k;
- use fully deployment-matched surfaces;
- abstain aggressively;
- treat curriculum/prerequisite graph as conditional context;
- demand public/untouched evidence before broadening intervention.

